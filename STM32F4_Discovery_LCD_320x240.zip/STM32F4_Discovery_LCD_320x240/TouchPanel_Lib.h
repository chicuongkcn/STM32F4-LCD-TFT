#include <stm32f4xx.h>
#include <TouchPanel_Lib.c>

void LV_Transfer(u16 Value);

u32 SPI_Transmission(u8 data);

u32 TP_Read_X_Axis(void);

u32 TP_Read_Y_Axis(void);








