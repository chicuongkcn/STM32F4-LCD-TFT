#include <stm32f4xx.h>
#include <TouchPanel_Lib.h>
#include <TFT_LCD_3.2"_SSD1289.h>


/**********************************************************************************************************************/
EXTI_InitTypeDef				EXTI_InitStructure;
GPIO_InitTypeDef				GPIO_InitStructure;
SPI_InitTypeDef					SPI_InitStructure;
NVIC_InitTypeDef				NVIC_InitStructure;
FSMC_NORSRAMInitTypeDef  		FSMC_NORSRAMInitStructure;
FSMC_NORSRAMTimingInitTypeDef 	FSMC_NORSRAMTimingInitStructure;
TIM_TimeBaseInitTypeDef			TIM_TimeBaseStructure;
TIM_OCInitTypeDef				TIM_OCInitStructure;

u16 pen_Color = WHITE;
	u32 rgb;
/**********************************************************************************************************************/
void RCC_Configuration(void);
void NVIC_Configuration(void);

void LCD_print_Exit_Button(u32 Xpos, u16 Ypos, u16 Color)
{
	u32 x;
	LCD_setPosition(Xpos,Ypos-1);	x = 30;	while(x--)	LCD_RAM = Color;	Delay(100);
	LCD_setPosition(Xpos,Ypos+2);	x = 30;	while(x--)	LCD_RAM = Color;	Delay(100);
	LCD_setPosition(Xpos,Ypos+1);	x = 30;	while(x--)	LCD_RAM = Color;	Delay(100);
	LCD_setPosition(Xpos,Ypos+4);	x = 30;	while(x--)	LCD_RAM = Color;	Delay(100);
	LCD_setPosition(Xpos,Ypos+3);	x = 30;	while(x--)	LCD_RAM = Color;	Delay(100);
	LCD_setPosition(Xpos,Ypos+6);	x = 30;	while(x--)	LCD_RAM = Color;	Delay(100);
	LCD_setPosition(Xpos,Ypos+5);	x = 30;	while(x--)	LCD_RAM = Color;	Delay(100);
	LCD_setPosition(Xpos,Ypos+8);	x = 30;	while(x--)	LCD_RAM = Color;	Delay(100);
	LCD_setPosition(Xpos,Ypos+7);	x = 30;	while(x--)	LCD_RAM = Color;	Delay(100);
	LCD_setPosition(Xpos,Ypos+10);	x = 30;	while(x--)	LCD_RAM = Color;	Delay(100);
	LCD_setPosition(Xpos,Ypos+9);	x = 30;	while(x--)	LCD_RAM = Color;	Delay(100);
	LCD_setPosition(Xpos,Ypos+12);	x = 30;	while(x--)	LCD_RAM = Color;	Delay(100);
	LCD_setPosition(Xpos,Ypos+11);	x = 30;	while(x--)	LCD_RAM = Color;	Delay(100);
	LCD_setPosition(Xpos,Ypos+14);	x = 30;	while(x--)	LCD_RAM = Color;	Delay(100);
	LCD_setPosition(Xpos,Ypos+13);	x = 30;	while(x--)	LCD_RAM = Color;	Delay(100);
	LCD_setPosition(Xpos,Ypos+16);	x = 30;	while(x--)	LCD_RAM = Color;	Delay(100);
	LCD_setPosition(Xpos,Ypos+15);	x = 30;	while(x--)	LCD_RAM = Color;	Delay(100);
	LCD_setPosition(Xpos,Ypos+18);	x = 30;	while(x--)	LCD_RAM = Color;	Delay(100);
	LCD_setPosition(Xpos,Ypos+17);	x = 30;	while(x--)	LCD_RAM = Color;	Delay(100);
	LCD_setPosition(Xpos,Ypos+20);	x = 30;	while(x--)	LCD_RAM = Color;	Delay(100);
	LCD_setPosition(Xpos,Ypos+19);	x = 30;	while(x--)	LCD_RAM = Color;	Delay(100);
	LCD_setPosition(Xpos,Ypos+22);	x = 30;	while(x--)	LCD_RAM = Color;	Delay(100);
	LCD_setPosition(Xpos,Ypos+21);	x = 30;	while(x--)	LCD_RAM = Color;	Delay(100);
	LCD_setPosition(Xpos,Ypos+24);	x = 30;	while(x--)	LCD_RAM = Color;	Delay(100);
	LCD_setPosition(Xpos,Ypos+23);	x = 30;	while(x--)	LCD_RAM = Color;	Delay(100);
	LCD_setPosition(Xpos,Ypos+26);	x = 30;	while(x--)	LCD_RAM = Color;	Delay(100);
	LCD_setPosition(Xpos,Ypos+25);	x = 30;	while(x--)	LCD_RAM = Color;	Delay(100);
	LCD_setPosition(Xpos,Ypos+28);	x = 30;	while(x--)	LCD_RAM = Color;	Delay(100);
	LCD_setPosition(Xpos,Ypos+27);	x = 30;	while(x--)	LCD_RAM = Color;	Delay(100);
}

void LCD_print_Cir(u32 Xpos, u16 Ypos, u16 Color)
{
	u32 a;
	LCD_SetCursor(Xpos-1,Ypos-4);	Delay(100);	LCD_WriteRAM_Prepare;	Delay(100);	a = 3; while(a--)	LCD_RAM = Color;	Delay(2);
	LCD_SetCursor(Xpos-3,Ypos-3);	Delay(100);	LCD_WriteRAM_Prepare;	Delay(100);	a = 7; while(a--)	LCD_RAM = Color;	Delay(2);
	LCD_SetCursor(Xpos-3,Ypos-6);	Delay(100);	LCD_WriteRAM_Prepare;	Delay(100);	a = 7; while(a--)	LCD_RAM = Color;	Delay(2);
	LCD_SetCursor(Xpos-4,Ypos-5);	Delay(100);	LCD_WriteRAM_Prepare;	Delay(100);	a = 9; while(a--)	LCD_RAM = Color;	Delay(2);
	LCD_SetCursor(Xpos-4,Ypos-8);	Delay(100);	LCD_WriteRAM_Prepare;	Delay(100);	a = 9; while(a--)	LCD_RAM = Color;	Delay(2);
	LCD_SetCursor(Xpos-4,Ypos-7);	Delay(100);	LCD_WriteRAM_Prepare;	Delay(100);	a = 9; while(a--)	LCD_RAM = Color;	Delay(2);
	LCD_SetCursor(Xpos-3,Ypos-10);	Delay(100);	LCD_WriteRAM_Prepare;	Delay(100);	a = 7; while(a--)	LCD_RAM = Color;	Delay(2);
	LCD_SetCursor(Xpos-3,Ypos-9);	Delay(100);	LCD_WriteRAM_Prepare;	Delay(100);	a = 7; while(a--)	LCD_RAM = Color;	Delay(2);
	LCD_SetCursor(Xpos-1,Ypos-12);	Delay(100);	LCD_WriteRAM_Prepare;	Delay(100);	a = 3; while(a--)	LCD_RAM = Color;	Delay(2);
}
	
void LCD_print_Square(u32 Xpos, u16 Ypos, u16 Color)
{
	u32 x;
	LCD_setPosition(Xpos,Ypos);		x = 30;	while(x--)	LCD_RAM = Color;	Delay(10);
	LCD_setPosition(Xpos,Ypos+1);	x = 30;	while(x--)	LCD_RAM = Color;	Delay(10);
	LCD_setPosition(Xpos,Ypos+2);	x = 30;	while(x--)	LCD_RAM = Color;	Delay(10);
	LCD_setPosition(Xpos,Ypos+3);	x = 30;	while(x--)	LCD_RAM = Color;	Delay(10);
	LCD_setPosition(Xpos,Ypos+4);	x = 30;	while(x--)	LCD_RAM = Color;	Delay(10);
	LCD_setPosition(Xpos,Ypos+5);	x = 30;	while(x--)	LCD_RAM = Color;	Delay(10);
	LCD_setPosition(Xpos,Ypos+6);	x = 30;	while(x--)	LCD_RAM = Color;	Delay(10);
	LCD_setPosition(Xpos,Ypos+7);	x = 30;	while(x--)	LCD_RAM = Color;	Delay(10);
	LCD_setPosition(Xpos,Ypos+8);	x = 30;	while(x--)	LCD_RAM = Color;	Delay(10);
	LCD_setPosition(Xpos,Ypos+9);	x = 30;	while(x--)	LCD_RAM = Color;	Delay(10);
	LCD_setPosition(Xpos,Ypos+10);	x = 30;	while(x--)	LCD_RAM = Color;	Delay(10);
	LCD_setPosition(Xpos,Ypos+11);	x = 30;	while(x--)	LCD_RAM = Color;	Delay(10);
	LCD_setPosition(Xpos,Ypos+12);	x = 30;	while(x--)	LCD_RAM = Color;	Delay(10);
	LCD_setPosition(Xpos,Ypos+13);	x = 30;	while(x--)	LCD_RAM = Color;	Delay(10);
	LCD_setPosition(Xpos,Ypos+14);	x = 30;	while(x--)	LCD_RAM = Color;	Delay(10);
	LCD_setPosition(Xpos,Ypos+15);	x = 30;	while(x--)	LCD_RAM = Color;	Delay(10);
	LCD_setPosition(Xpos,Ypos+16);	x = 30;	while(x--)	LCD_RAM = Color;	Delay(10);
	LCD_setPosition(Xpos,Ypos+17);	x = 30;	while(x--)	LCD_RAM = Color;	Delay(10);
	LCD_setPosition(Xpos,Ypos+18);	x = 30;	while(x--)	LCD_RAM = Color;	Delay(10);
	LCD_setPosition(Xpos,Ypos+19);	x = 30;	while(x--)	LCD_RAM = Color;	Delay(10);
	LCD_setPosition(Xpos,Ypos+20);	x = 30;	while(x--)	LCD_RAM = Color;	Delay(10);
	LCD_setPosition(Xpos,Ypos+21);	x = 30;	while(x--)	LCD_RAM = Color;	Delay(10);
	LCD_setPosition(Xpos,Ypos+22);	x = 30;	while(x--)	LCD_RAM = Color;	Delay(10);
	LCD_setPosition(Xpos,Ypos+23);	x = 30;	while(x--)	LCD_RAM = Color;	Delay(10);
	LCD_setPosition(Xpos,Ypos+24);	x = 30;	while(x--)	LCD_RAM = Color;	Delay(10);
	LCD_setPosition(Xpos,Ypos+25);	x = 30;	while(x--)	LCD_RAM = Color;	Delay(10);
	LCD_setPosition(Xpos,Ypos+26);	x = 30;	while(x--)	LCD_RAM = Color;	Delay(10);
	LCD_setPosition(Xpos,Ypos+27);	x = 30;	while(x--)	LCD_RAM = Color;	Delay(10);
	LCD_setPosition(Xpos,Ypos+28);	x = 30;	while(x--)	LCD_RAM = Color;	Delay(10);
	LCD_setPosition(Xpos,Ypos+29);	x = 30;	while(x--)	LCD_RAM = Color;	Delay(10);
}

void Paint_Function(void)
{
	u16 X_Data;
	u16 Y_Data;
	u16 Touching = 0;
	u16 lock = 1;
	
	LCD_CLEAR(BLACK);
	LCD_print_Square(4,287,WHITE);
	LCD_print_Square(38,287,RED);
	LCD_print_Square(71,287,GREEN);
	LCD_print_Square(105,287,YELLOW);
	LCD_print_Square(138,287,BLUE);
	LCD_print_Square(172,287,BLACK);
	LCD_print_Square(206,287,pen_Color);
	Delay(20000000);
	
	while(lock)
	{
		if(!GPIO_ReadInputDataBit(GPIOA, GPIO_Pin_3))
		{
			if(!Touching)	Delay(2000000);
			Touching = 1;
			X_Data = TP_Read_X_Axis();
			Y_Data = TP_Read_Y_Axis();
			if(Y_Data > 320)
			{
				if((X_Data < 40)& (X_Data > 12))	lock = 0;
			}
			else if(Y_Data > 287)
			{
					 if(X_Data < 33)	pen_Color = WHITE;
				else if(X_Data < 66)	pen_Color = RED;
				else if(X_Data < 100)	pen_Color = GREEN;
				else if(X_Data < 134)	pen_Color = YELLOW;
				else if(X_Data < 168)	pen_Color = BLUE;
				else if(X_Data < 203)	pen_Color = BLACK;
				else if(X_Data < 236)
				{
					LCD_CLEAR(pen_Color);
					LCD_print_Square(4,287,WHITE);
					LCD_print_Square(38,287,RED);
					LCD_print_Square(71,287,GREEN);
					LCD_print_Square(105,287,YELLOW);
					LCD_print_Square(138,287,BLUE);
					LCD_print_Square(172,287,BLACK);
					Delay(10000000);
				} 
					LCD_print_Square(206,287,pen_Color);
			}
			else
			{
				LCD_setPosition(X_Data, Y_Data);	LCD_RAM = pen_Color;
			}
		}
		else 
		{
			Delay(1000000);
			Touching = 0;
		}
	}
}



void LCD_Home_Screen(void)
{
	u16 x;
	u16 y;
	LCD_CLEAR(1 * 0x0800 + 16 * 0x20 + 17);
	for(y=2;y<63;y++)	{	for(x=2;x<79;x++)	{	LCD_setPosition(x,y);	LCD_RAM = 0 * 0x0800 + (30+x/10) * 0x20 + 31;	}	}
	for(y=2;y<63;y++)	{	for(x=82;x<159;x++)	{	LCD_setPosition(x,y);	LCD_RAM = (2+x/12) * 0x0800 +  7 * 0x20 + 22;	}	}
	for(y=2;y<63;y++)	{	for(x=162;x<239;x++){	LCD_setPosition(x,y);	LCD_RAM = 0 * 0x0800 + (25+x/10) * 0x20 + 0;	}	}
	for(y=66;y<127;y++)	{	for(x=2;x<79;x++)	{	LCD_setPosition(x,y);	LCD_RAM = 31 *0x0800 + (23+x/16) * 0x20 + 10;	}	}
	for(y=66;y<127;y++)	{	for(x=82;x<159;x++)	{	LCD_setPosition(x,y);	LCD_RAM = 0 * 0x0800 + (30+x/10) * 0x20 + 31;	}	}
	for(y=66;y<127;y++)	{	for(x=162;x<239;x++){	LCD_setPosition(x,y);	LCD_RAM = (18+x/20) * 0x0800 + 6 * 0x20 + 8;	}	}
	for(y=130;y<191;y++){	for(x=2;x<79;x++)	{	LCD_setPosition(x,y);	LCD_RAM = (19+x/10) * 0x0800 + 1 * 0x20 + (20+x/10);	}	}
	for(y=130;y<191;y++){	for(x=82;x<159;x++)	{	LCD_setPosition(x,y);	LCD_RAM = 22 * 0x0800 + 48 * 0x20 + 24;	}	}
	for(y=130;y<191;y++){	for(x=162;x<239;x++){	LCD_setPosition(x,y);	LCD_RAM = 31 *0x0800 + (23+(x-80)/16) * 0x20 + 10;	}	}
	for(y=194;y<255;y++){	for(x=2;x<79;x++)	{	LCD_setPosition(x,y);	LCD_RAM = 0 * 0x0800 + (25+(x+80)/10) * 0x20 + 0;	}	}
	for(y=194;y<255;y++){	for(x=82;x<159;x++)	{	LCD_setPosition(x,y);	LCD_RAM = (2+x/12) * 0x0800 +  7 * 0x20 + 22;	}	}
	for(y=194;y<255;y++){	for(x=162;x<239;x++){	LCD_setPosition(x,y);	LCD_RAM = 22 * 0x0800 + 48 * 0x20 + 24;	}	}
	for(y=258;y<318;y++){	for(x=2;x<79;x++)	{	LCD_setPosition(x,y);	LCD_RAM = 0 * 0x0800 + (30+x/10) * 0x20 + 31;	}	}
	for(y=258;y<318;y++){	for(x=82;x<159;x++)	{	LCD_setPosition(x,y);	LCD_RAM = (18+(x+80)/20) * 0x0800 + 6 * 0x20 + 8;	}	}
	for(y=258;y<318;y++){	for(x=162;x<239;x++){	LCD_setPosition(x,y);	LCD_RAM = (19+(x-160)/10) * 0x0800 + 1 * 0x20 + (20+(x-160)/10);	}	}
	LCD_print_Char8x16(20,26,WHITE, 'P');
	LCD_print_Char8x16(28,26,WHITE, 'a');
	LCD_print_Char8x16(36,26,WHITE, 'i');
	LCD_print_Char8x16(44,26,WHITE, 'n');
	LCD_print_Char8x16(52,26,WHITE, 't');
}

void LCD_RGB(void)
{
	u8 r=31;
	u8 g=0;
	u8 b=0;
	LCD_SetCursor(0,0);
	LCD_WriteRAM_Prepare;
	rgb = 76800;
	while(rgb--)
	{
		if(g!=64)	{for(g=0;g<64;g++)	LCD_pColor(31,g,0);}
		if(r!=0)	{for(r=31;r!=0;r--)	LCD_pColor(r,63,0);}
		if(b!=32)	{for(b=0;b<32;b++)	LCD_pColor(0,63,b);}
		if(g!=0)	{for(g=63;g!=0;g--)	LCD_pColor(0,g,31);}
		if(r!=32)	{for(r=0;r<32;r++)	LCD_pColor(r,0,31);}
		if(b!=0)	{for(b=31;b!=0;b--)	LCD_pColor(31,0,b);}
	}
}
/**********************************************************************************************************************/


u16 x;
u16 y;
u16 z=1;
u16 bz;
u16 lock = 1;

/**********************************************************************************************************************/
int main(void)
{
	RCC_Configuration();
	NVIC_Configuration();
    GPIO_Configuration();
    SPI1_Configuration();
	TIM_Configuration();
	FSMC_Configuration();
//	EXTILine3_Configuration();
	My_UART_Configuration(USART1, 115200, USART_WordLength_8b,USART_StopBits_1, USART_Parity_No,
							USART_HardwareFlowControl_None, USART_Mode_Rx | USART_Mode_Tx);

	TFT_LCD_Init();
	LCD_CLEAR(BLACK);
	
	LCD_RGB();
	
	while(1)
	{	
		
		LCD_Home_Screen();
		lock = 1;
		Delay(40000000);
		while(lock)
		{
			if(!GPIO_ReadInputDataBit(GPIOA, GPIO_Pin_3))
			{
				Delay(1000000);
				if((TP_Read_X_Axis()<80)&(TP_Read_Y_Axis()<64))	lock = 0;
			}
		}
		Paint_Function();
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		for(z=1;z<100;z++)
		{
			for(y=0;y<320;y++)
			{
				for(x=0;x<240;x++)
				{
					LCD_setPosition(x,y);		LCD_RAM = ((y*240)+x)*10/z;
				}
			}
			if(!GPIO_ReadInputDataBit(GPIOA, GPIO_Pin_3))
			{
				Delay(1000000);
				z = TP_Read_X_Axis() * TP_Read_Y_Axis();
			}
		}
		
		

		LCD_setPosition(TP_Read_X_Axis(), TP_Read_Y_Axis());	LCD_RAM = GREEN;
		
	GPIO_WriteBit(GPIOD, GPIO_Pin_12, (BitAction) GPIO_ReadInputDataBit(GPIOA, GPIO_Pin_3));
		
		U_Wst(USART1, "X: ");
		U_WU10(USART1, TP_Read_X_Axis());
	U_Wst(USART1, " - Y: ");
	U_WU10ln(USART1, TP_Read_Y_Axis());
		
	Delay(1000000);
	}
}
/**********************************************************************************************************************/
/**********************************************************************************************************************/
/**********************************************************************************************************************/
void RCC_Configuration(void)
{
	RCC_AHB3PeriphClockCmd(RCC_AHB3Periph_FSMC, ENABLE);
	RCC_APB2PeriphClockCmd(RCC_APB2Periph_USART1, ENABLE);
	RCC_APB2PeriphClockCmd(RCC_APB2Periph_SPI1, ENABLE);
	RCC_APB2PeriphClockCmd(RCC_APB2Periph_TIM1 , ENABLE);
	RCC_APB2PeriphClockCmd(RCC_APB2Periph_SYSCFG, ENABLE);
	RCC_AHB1PeriphClockCmd(RCC_AHB1Periph_GPIOA | RCC_AHB1Periph_GPIOB | RCC_AHB1Periph_GPIOC |
						   RCC_AHB1Periph_GPIOD | RCC_AHB1Periph_GPIOE | RCC_AHB1Periph_GPIOF, ENABLE);
}
/*--------------------------------------------------------------------------------------------------------------------*/
void NVIC_Configuration(void)
{
	NVIC_PriorityGroupConfig(NVIC_PriorityGroup_0);
	NVIC_InitStructure.NVIC_IRQChannel = USART1_IRQn;
	NVIC_InitStructure.NVIC_IRQChannelSubPriority = 0;
	NVIC_InitStructure.NVIC_IRQChannelCmd = ENABLE;
	NVIC_Init(&NVIC_InitStructure);
}
/*--------------------------------------------------------------------------------------------------------------------*/




