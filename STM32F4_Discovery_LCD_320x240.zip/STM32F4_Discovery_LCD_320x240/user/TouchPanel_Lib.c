#include "stm32f4xx.h"
#define TP_CS					GPIOA->BSRRH |= GPIO_Pin_4
#define TP_DCS					GPIOA->BSRRL |= GPIO_Pin_4


u32 SPI_Transmission(u8 data)
{
	SPI1->DR = data; 							// write data to be transmitted to the SPI data register
	while( !(SPI1->SR & SPI_I2S_FLAG_TXE) );	// wait until transmit complete
	while( !(SPI1->SR & SPI_I2S_FLAG_RXNE) );	// wait until receive complete
	while( SPI1->SR & SPI_I2S_FLAG_BSY );		// wait until SPI is not busy anymore
	return SPI1->DR;							// return received data from SPI data register
}

u32 TP_Read_X_Axis(void)
{ 
	u32 X_Axis = 0;
	u32 a = 150;
	u32 b = 0;
	TP_CS;
	SPI_Transmission(0xD4);
	while(a--)
	{
		b = 0;
		b |= SPI_Transmission(0) << 3;
		b |= SPI_Transmission(0xD4) >> 5;
		X_Axis += b;
	}
	TP_DCS;
	X_Axis /= 550;
	if(X_Axis)	X_Axis -= 19;
	return X_Axis;
}


u32 TP_Read_Y_Axis(void)
{
	u32 Y_Axis = 0;
	u32 a = 140;
	u32 b = 0;
	TP_CS;
	SPI_Transmission(0x94);
	while(a--)
	{
		b = 0;
		b |= SPI_Transmission(0) << 3;
		b |= SPI_Transmission(0x94) >> 5;
		b = 1020-b;
		Y_Axis += b;
	}
	TP_DCS;
	Y_Axis /= 375;
	if(Y_Axis)	Y_Axis -= 29;
	if(Y_Axis > 400)	Y_Axis = 0;
	return Y_Axis;
}





















