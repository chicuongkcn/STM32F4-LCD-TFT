#ifndef __MAIN_H
#define __MAIN_H

////////////////////////////////////////////
#define DOUBLECLICK_Z                    ((uint8_t)0x60)
#define SINGLECLICK_Z                    ((uint8_t)0x50)
#define ABS(x)                           (x < 0) ? (-x) : x
#define MAX(a,b)                         (a < b) ? (b) : a
#define TIM_ARR                          ((uint16_t)1900)
#define TIM_CCR                          ((uint16_t)1000)
///////////////////////HX711//////////////////////
#define 	Uee 		    3.93  // (volt)
#define 	Weight_Max	5000  // (gam)
#define 	Error 		  0.05  // (volt)
//#define 	Volt_N 		  5.0/9 // ti le giua Volt/Uee   (loai 3Kg)
#define 	Volt_N 		  1.0   // ti le giua Volt/Uee   (loai 5kg)
/////////////////ADC//////////////////////
#define ADC_CDR_ADDRESS    ((uint32_t)0x4001224C)
#include "stm32f4_discovery.h"
#include "stdlib.h"
#include "math.h"
#include "pwm.h"
#include "ts.h"
#include "stm32f4xx.h"
#include "stm32f4xx_it.h"
#include "stm32f4xx_rcc.h"
#include "stm32f4xx_syscfg.h"
#include "LCD_STM32F4.h"
#include "functions.h"
#include "stdio.h"
#include "stm32f4_discovery_lis302dl.h"
#include "delay.h"
#include "stm32f4xx_adc.h"
#include "stm32f4xx_dma.h"
#include "stm32f4xx_usart.h"
#include "MPU6050.h"
#include "HMC5883L.h"
#include "stm32f4xx_i2c.h"
#include "Uart_Config.h"
#include "stm32f4xx_spi.h"
void ADC_Config(void);
void GPIO_Configuration(void);
void EXTILine0_Config(void);
void EXTILine9_Config(void);
void Demo_MMIA(void);
void Random_Lines(void);
void Random_Rect(void);
void Random_Circle(void);
void maytinh(void);
void paint(void);
void maytinh1(void);
void updateXY(void);
void pheptinh(void);
void album(void);
void dieuchinhXY(void);
void tinhdientro(void);
void valuea(void);
void valueb(void);
void testtouch(void);
void option(void);
void brightness(void);
void Axis(void);
void calibration(void);
void start(void);
void icon(uint16_t ix1, uint16_t iy1, uint16_t ix2,uint16_t iy2, uint16_t icolor,uint8_t ic1,uint8_t click);
void oscillocope(void);
void set(void);
void updateaxit(uint16_t ax,uint16_t ay);
void PID(void);
void optionPID(void);
void setPID(void);
void TIMbase_Configuration(void);
void TIM2_Configuration(void);
void uart(void);
void setbaudrate(void);
void keypad(void);
void I2C_Configuration(void);
void setup_LIS302DL(void);
void scaleanalog(void);
void menu(void);
long map(long x, long in_min, long in_max, long out_min, long out_max);
void Display_Number(uint16_t x,uint16_t y, uint16_t data, uint16_t color);
uint32_t LIS302DL_TIMEOUT_UserCallback(void);
void gpio_scale(void);
uint32_t HX711_Read(void);
uint32_t Get_ZeroWeight(void);
void Delay_us(uint16_t dly1);
float Get_Weight(uint32_t Weight_ZeroPoint);
#endif 
