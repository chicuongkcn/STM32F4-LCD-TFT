#ifndef __PWM_H
#define __PWM_H

/* Includes ******************************************************************/

#include <stm32f4xx.h>
/* Function Prototypes *******************************************************/

void pwm_init(void);

#endif /* __MAIN_H */
