#ifndef __FUNCTIONS_H
#define __FUNCTIONS_H

/* Includes ******************************************************************/

#include <stdlib.h>
#include "stm32f4xx.h"

/* Function Prototypes *******************************************************/

void uint16tostr(char buf[], uint32_t, uint8_t);

#endif /* __FUNCTIONS_H */
