#include "ADC_DMA.h"
__IO uint32_t ADCValue[9];
#define ADC_CDR_ADDRESS    ((uint32_t)0x4001224C)
void ADC_Config(void)
{
	
      GPIO_InitTypeDef      GPIO_AdcInit;
      ADC_InitTypeDef       ADC_InitStructure;
      ADC_CommonInitTypeDef ADC_CommonInitStructure;
 
      /* Deinitializes the ADC peripheral registers */
      ADC_DeInit();
 
      /* Enable the GPIOC Clock & ADC1 Periph Clock */
      RCC_AHB1PeriphClockCmd(RCC_AHB1Periph_DMA2 | RCC_AHB1Periph_GPIOA | RCC_AHB1Periph_GPIOB | RCC_AHB1Periph_GPIOC, ENABLE);
      RCC_APB2PeriphClockCmd(RCC_APB2Periph_ADC1 | RCC_APB2Periph_ADC2 | RCC_APB2Periph_ADC3, ENABLE);
 
      /* Configure the  PA0 pin (ADC123_IN0)
       *                PA1 pin (ADC123_IN1)
       *                PA2 pin (ADC123_IN2)
       *                PA3 pin (ADC123_IN3)
       *                PA4 pin (ADC12_IN4) */
      GPIO_AdcInit.GPIO_Pin = GPIO_Pin_0 | GPIO_Pin_1 | GPIO_Pin_2 | GPIO_Pin_3 | GPIO_Pin_4;
      GPIO_AdcInit.GPIO_Mode = GPIO_Mode_AN;
      GPIO_AdcInit.GPIO_PuPd = GPIO_PuPd_NOPULL;
      GPIO_Init(GPIOA, &GPIO_AdcInit);
 
      /* Configure the  PB0 pin (ADC12_IN8)
       *                PB1 pin (ADC12_IN9) */
      GPIO_AdcInit.GPIO_Pin = GPIO_Pin_0 | GPIO_Pin_1;
      GPIO_AdcInit.GPIO_Mode = GPIO_Mode_AN;
      GPIO_AdcInit.GPIO_PuPd = GPIO_PuPd_NOPULL;
      GPIO_Init(GPIOB, &GPIO_AdcInit);
 
      /* Configure the  PC0 pin (ADC123_IN10)
       *                PC2 pin (ADC123_IN12) */
      GPIO_AdcInit.GPIO_Pin = GPIO_Pin_0  |  GPIO_Pin_2;
      GPIO_AdcInit.GPIO_Mode = GPIO_Mode_AN;
      GPIO_AdcInit.GPIO_PuPd = GPIO_PuPd_NOPULL;
      GPIO_Init(GPIOC, &GPIO_AdcInit);
 
      /* ADC Common configuration -- ADC_CCR Register */
      ADC_CommonInitStructure.ADC_Mode = ADC_TripleMode_RegSimult ;
      ADC_CommonInitStructure.ADC_TwoSamplingDelay = ADC_TwoSamplingDelay_10Cycles;
      ADC_CommonInitStructure.ADC_DMAAccessMode = ADC_DMAAccessMode_1  ;
      ADC_CommonInitStructure.ADC_Prescaler = ADC_Prescaler_Div2;
      ADC_CommonInit(&ADC_CommonInitStructure);
 
      /* ADC1 regular channel 6 configuration -- ADC_CR1, ADC_CR2, ADC_SQR1 Register */
      ADC_InitStructure.ADC_Resolution = ADC_Resolution_12b;
      ADC_InitStructure.ADC_ScanConvMode = ENABLE;
      ADC_InitStructure.ADC_ContinuousConvMode = ENABLE;
      ADC_InitStructure.ADC_ExternalTrigConvEdge = ADC_ExternalTrigConvEdge_None;
      ADC_InitStructure.ADC_ExternalTrigConv = 0;
      ADC_InitStructure.ADC_DataAlign = ADC_DataAlign_Right;
      ADC_InitStructure.ADC_NbrOfConversion = 3;
      ADC_Init(ADC1, &ADC_InitStructure);
      ADC_Init(ADC2, &ADC_InitStructure);
      ADC_Init(ADC3, &ADC_InitStructure);
 
      /* ADC1 regular channel6 configuration -- ADCx->SMPR1,SMPR2 et ADCx->SQR1,SQR2,SQR3
       *              channel8 */
      ADC_RegularChannelConfig(ADC1, ADC_Channel_2, 1, ADC_SampleTime_15Cycles );
      ADC_RegularChannelConfig(ADC1, ADC_Channel_8, 2, ADC_SampleTime_15Cycles );
      ADC_RegularChannelConfig(ADC1, ADC_Channel_9, 3, ADC_SampleTime_15Cycles );
 
      /* ADC2 regular channel12 configuration -- ADCx->SMPR1,SMPR2 et ADCx->SQR1,SQR2,SQR3  */
      ADC_RegularChannelConfig(ADC2, ADC_Channel_12, 1, ADC_SampleTime_15Cycles );
      ADC_RegularChannelConfig(ADC2, ADC_Channel_4, 2, ADC_SampleTime_15Cycles );
      ADC_RegularChannelConfig(ADC2, ADC_Channel_1, 3, ADC_SampleTime_15Cycles );
 
      /* ADC3 regular channel12 configuration -- ADCx->SMPR1,SMPR2 et ADCx->SQR1,SQR2,SQR3  */
      ADC_RegularChannelConfig(ADC3, ADC_Channel_0, 1, ADC_SampleTime_15Cycles );
      ADC_RegularChannelConfig(ADC3, ADC_Channel_3, 2, ADC_SampleTime_15Cycles );
      ADC_RegularChannelConfig(ADC3, ADC_Channel_10, 3, ADC_SampleTime_15Cycles );
 
      /* DMA2 Stream0 channel0 configuration */
      DMA_ADC_Config();
 
      /* Enable DMA request after last transfer (Multi-ADC mode)  */
      ADC_MultiModeDMARequestAfterLastTransferCmd(ENABLE);
 
      /* Enable ADC1 -- ADC_CR2_ADON */
      ADC_Cmd(ADC1, ENABLE);
 
      /* Enable ADC2 */
      ADC_Cmd(ADC2, ENABLE);
 
      /* Enable ADC3 */
      ADC_Cmd(ADC3, ENABLE);
 
      /* Enable ADC1 DMA since ADC1 is the Master*/
      ADC_DMACmd(ADC1, ENABLE);
}
 
 
/**
  * @brief  Configuration of the DMA for the ADC
  * @param  None
  * @retval None
  */
void DMA_ADC_Config(void)
{
  DMA_InitTypeDef DMA_InitStructure;
 
  DMA_InitStructure.DMA_Channel = DMA_Channel_0;                           
  DMA_InitStructure.DMA_Memory0BaseAddr = (uint32_t)&ADCValue;             
  DMA_InitStructure.DMA_PeripheralBaseAddr = (uint32_t)ADC_CDR_ADDRESS;    
  DMA_InitStructure.DMA_DIR = DMA_DIR_PeripheralToMemory;                  
  DMA_InitStructure.DMA_BufferSize = 9;                                 
  DMA_InitStructure.DMA_PeripheralInc = DMA_PeripheralInc_Disable;      
  DMA_InitStructure.DMA_MemoryInc = DMA_MemoryInc_Enable;               
  DMA_InitStructure.DMA_PeripheralDataSize = DMA_PeripheralDataSize_Word;
  DMA_InitStructure.DMA_MemoryDataSize = DMA_MemoryDataSize_Word;       
  DMA_InitStructure.DMA_Mode = DMA_Mode_Circular;                       
  DMA_InitStructure.DMA_Priority = DMA_Priority_High;                   
  DMA_InitStructure.DMA_FIFOMode = DMA_FIFOMode_Enable;                 
  DMA_InitStructure.DMA_FIFOThreshold = DMA_FIFOThreshold_1QuarterFull; 
  DMA_InitStructure.DMA_MemoryBurst = DMA_MemoryBurst_Single;           
  DMA_InitStructure.DMA_PeripheralBurst = DMA_PeripheralBurst_Single;   
  DMA_Init(DMA2_Stream0, &DMA_InitStructure);                           
 
  DMA_Cmd(DMA2_Stream0, ENABLE);
}