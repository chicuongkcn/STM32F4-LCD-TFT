#include "main.h"
uint8_t Buffer[6];
__IO int8_t XOffset;
__IO int8_t YOffset;
__IO uint8_t SingleClickDetect = 0x00;
__IO uint16_t dataline5=0;
__IO uint16_t dataline6=0;
__IO float datapwm=0;
extern __IO float dataVc,datavs;
extern __IO float P,I,D, sume,dbien,e0,e1;
//////////////////MP3///////////////////////
/*#if defined MEDIA_USB_KEY
 USB_OTG_CORE_HANDLE          USB_OTG_Core;
 USBH_HOST                    USB_Host;
#endif
*/
RCC_ClocksTypeDef RCC_Clocks;
__IO uint8_t RepeatState = 0;
__IO uint16_t CCR_Val = 16826;
extern __IO uint8_t LED_Toggle;

/* Private function prototypes -----------------------------------------------*/
static void TIM_LED_Config(void);
/* Private functions ---------------------------------------------------------*/


/////////////////////////////////////////
int16_t MPU6050data[7]; 
int16_t HMC5883Ldata[3];
int16_t imu1=0,imu2=0,imu3=0,imu4=0,imu5=0,imu6=0,imu7=0,imu8=0,imu9=0;
/////////////////////////////////////////////
volatile uint16_t ADCValue[3]={0};
extern uint8_t ClickReg;
/////////////////////////////
char uart3_getc;
char uart2_getc;
char uart_getc;
char uart_gets[10];
int valscale=0;
uint16_t kaka=0;
///////////////////////////////
const static uint16_t mx[50] = {20,21,23,27,32,39,47,56,66,77,89,101,113,126,139,151,163,174,184,193,201,208,213,217,219,220,219,217,213,208,201,193,184,174,163,151,139,126,114,101,89,77,66,56,47,39,32,27,23,21};
const static uint16_t my[50] = {160,147,135,123,112,101,92,83,76,70,65,62,60,60,62,65,70,76,83,92,101,112,123,135,147,160,173,185,197,208,219,228,237,244,250,255,258,260,260,258,255,250,244,237,228,219,208,197,185,173};
const static uint8_t cx[50] = {30,31,33,36,41,47,54,63,72,82,92,103,114,126,136,148,158,168,177,186,193,199,204,207,209,210,209,207,204,199,193,186,177,168,158,148,137,126,114,103,92,82,72,63,54,47,41,36,33,31};
const static uint8_t cy[50] = {160,149,138,127,117,107,98,91,84,79,74,72,70,70,72,74,79,84,91,98,107,117,127,138,149,160,171,182,193,203,215,222,229,236,241,246,248,250,250,248,246,241,236,229,222,213,203,193,182,171};
///////////////////////////////////
uint16_t CCR1_Val = 666;
uint16_t CCR2_Val = 0;
uint16_t CCR3_Val = 1000;
uint16_t CCR4_Val = 2500;
uint16_t b = 1;
uint16_t A = 310;
uint16_t x0=0, y0=0,x=0,y=0,k=0,k0=0,i=0;
uint16_t ondata=0;
uint16_t data1,data2,C=0;
uint16_t kt=0,h=1;
uint16_t cong =0,bang=0,nhan=0,tru=0,chia=0;
uint16_t ma[5] = {1,10,100,1000,10000};
uint16_t ma1[5];
uint16_t ma2[5];
uint64_t biena=0;
uint64_t bienb=0;
uint64_t bienc=0;
uint16_t X =0, X0=0, Y=0,Y0=0,t=0,XX=0,YY=0,AA=0,Z=0;
uint8_t a=0,doi=0;
uint8_t tn=0,ii=0;
uint8_t color =0,vv=0;
uint32_t macolor=0,color3=0,macolor1=0;
uint8_t color1=0,color2=0;
uint8_t opa0=0,opa1=0,opa2=0,opa3=0,opa4=0,opa5=0,opa6=0,opa7=0,opa8=0,opa9=0,opa11=0,opa12=0;
uint8_t pa1=0;
uint16_t pa3=0,pa4=0;
uint8_t br=0,br1=0;
uint8_t op1=0,op2=0,op3=0, op4=0,op5=0;
uint16_t cx1=0,cx2=0,cx3=0,cx4=0,cy1=0,cy2=0,cy3=0,cy4=0;
uint8_t cali=0,cl=0;
uint16_t calix1=0,caliy1=0,calix2=0,caliy2=0,calitbx=0,calitby=0;
uint16_t roll=0, roll1=0,roll2=0,roll3=0;
uint8_t cc=0;
uint8_t ic=1;
uint8_t icr1=0, icr2=0,icr3=0,icr4=0,icr5=0,icr6=0, icr7=0,icr8=0,icr9=0,icr10=0,icr11=0, icr12=0,icr13=0,icr14=0,icr15=0;
uint8_t icr16=0, icr17=0,icr18=0,icr19=0,icr20=0,icr21=0, icr22=0,icr23=0,icr24=0,icr25=0,icr26=0, icr27=0,icr28=0,icr29=0,icr30=0,icr31=0, icr32=0,icr33=0,icr34=0,icr35=0;
uint8_t icr36=0, icr37=0,icr38=0,icr39=0,icr40=0,icr41=0, icr42=0,icr43=0,icr44=0,icr45=0,icr46=0, icr47=0,icr48=0,icr49=0,icr50=0;
uint8_t st=1,ax=0;
uint16_t XA=0, YA=0, XAO=0,YAO=0;
uint8_t paa=0,re=0,ca=0,pi=0;
uint8_t Pp=0,Pi=0,Pd=0,Vs=0;
uint8_t datap=0,datai=0,datad=0;
uint16_t dataVs=0,datax=0,datay=0;
uint16_t py2=0,px1=0,px2=0,py1=0,px3=0,px4=0,px5=0,px6=0,px7=0;
uint16_t tt=0;
uint32_t adc1=0,adc2=0,adc3=0;
uint16_t adcx1 =0,adcx2 =0,adcy1=0,adcy2=0;
uint32_t adc4=0,adc5=0,adc6=0;
uint16_t osc1[30000] = {0};
uint16_t osc2[30000] = {0};
uint16_t Hz1=0,Hz2=0,Hz3=0;
uint8_t  adcch1=0, adcch2=0;
uint16_t setmv0=300,setmv1=0,setmv2=0;
uint8_t z1=0,z2=0,z3=0,z4=0,z5=0,z6=0;
uint8_t ua1=0,ua2=0,ua3=0,ua4=0,ua5=0,ua6=0,ua7=0,ua9=0;
uint16_t ua8=0;
uint8_t ky1=0,ky2=0,ky3=0,ky4=0,ky5=0;
uint8_t sm1=0,sm2=0,sm3=0,sm4=0,sm5=0;// Scale
uint32_t Zero_ADC,dddd=0;
uint16_t ddddd=0,ddd=0;
char* data[30]={0};
char ss;
uint8_t plus_uart=0;
int main (void)
{
  Init_SysTick();
  Init_GPIO();
  Init_FSMC();
  Init_LCD();
  pwm_init();
  touch_init();
	Read_Ads7846();
  ADC_Config();
	GPIO_Configuration();
	gpio_scale();
	TIMbase_Configuration();
	I2C_Configuration();
	TIM2_Configuration();
	//HMC5883L_Initialize();
	//MPU6050_Initialize();
	//EXTILine0_Config();
  EXTILine9_Config();
	setup_LIS302DL();
  TIM4->CCR1 = CCR1_Val;
  TIM4->CCR2 = CCR2_Val;
	TIM8->CCR3 = CCR3_Val;
  TIM8->CCR4 = CCR4_Val;
	////////////////////MP3////////////////////////////////
	/*RCC_GetClocksFreq(&RCC_Clocks);
  SysTick_Config(RCC_Clocks.HCLK_Frequency / 100);
	#if defined MEDIA_IntFLASH
  WavePlayBack(I2S_AudioFreq_48k); 
  while (1);
	#elif defined MEDIA_USB_KEY
	USBH_Init(&USB_OTG_Core, USB_OTG_FS_CORE_ID, &USB_Host, &USBH_MSC_cb, &USR_Callbacks);*/
	///////////////////////////////////////
	Clear_Screen(0x0000);	
	Draw_Full_Rect(0, 0 ,240 ,320 , LCD_BLACK);
	Delay_ms(10);
	cc=1;
	Uart_Config(E_USART5,9600, 1,ENABLE,0, 0 );
	Uart_Config(E_USART2,9600, 1,ENABLE,0, 0 );
	Uart_Config(E_USART3,9600, 1,ENABLE,0, 0 );
	uart_getc=0;
 while(1)
  {		
		//USBH_Process(&USB_OTG_Core, &USB_Host);
		//option();
		menu();
		/*Draw_Circle(120,160,100,LCD_WHITE);
		Draw_Line(120,160,20,160,LCD_WHITE);
		Draw_Line(120,160,21,148,LCD_WHITE);
		Draw_Line(120,160,24,136,LCD_WHITE);*/
		/*HMC5883L_GetHeading(HMC5883Ldata);       
		MPU6050_GetRawAccelTempGyro(MPU6050data);	
		imu1=MPU6050data[0];
		imu2=MPU6050data[1];
		imu3=MPU6050data[2];
		imu4=MPU6050data[4];
		imu5=MPU6050data[5];
		imu6=MPU6050data[6];
		imu7=HMC5883Ldata[0];
		imu8=HMC5883Ldata[1];
		imu9=HMC5883Ldata[2];*/
	}
}
void Display_Number(uint16_t x,uint16_t y, uint16_t data, uint16_t color)
{
	char number[10];
	uint16tostr(number, data, 10);
	Display_String(x,y,number, color);
}
void gpio_scale(void)
{
	GPIO_InitTypeDef GPIO_InitStructure;
	RCC_AHB1PeriphClockCmd(RCC_AHB1Periph_GPIOB, ENABLE);
	GPIO_InitStructure.GPIO_Pin = GPIO_Pin_0 ;
  GPIO_InitStructure.GPIO_Mode = GPIO_Mode_OUT;
  GPIO_InitStructure.GPIO_Speed = GPIO_Speed_100MHz;
  GPIO_InitStructure.GPIO_OType = GPIO_OType_PP;
  GPIO_InitStructure.GPIO_PuPd = GPIO_PuPd_UP ;
  GPIO_Init(GPIOB, &GPIO_InitStructure);
	GPIO_InitStructure.GPIO_Pin = GPIO_Pin_1 ;
	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_IN;
  GPIO_InitStructure.GPIO_Speed = GPIO_Speed_100MHz;
  GPIO_InitStructure.GPIO_OType = GPIO_OType_PP;
  GPIO_InitStructure.GPIO_PuPd = GPIO_PuPd_UP ;
  GPIO_Init(GPIOB, &GPIO_InitStructure);
}
void Delay_us(uint16_t dly1)
{
        uint16_t i;
        for(i=dly1;i>0;i--);
}
uint32_t HX711_Read(void)
{
		uint32_t count;
		uint8_t is;
		//GPIO_SetBits(GPIOB ,GPIO_Pin_1);
		Delay_us(1);
  	GPIO_ResetBits(GPIOB ,GPIO_Pin_0);
  	count=0;
  	while(GPIO_ReadInputDataBit(GPIOB , GPIO_Pin_1));
		Delay_us(1);
  	for(is=0;is<24;is++)
		{
	  	GPIO_SetBits(GPIOB ,GPIO_Pin_0 );
	  	count=count<<1;
			Delay_us(1);
			GPIO_ResetBits(GPIOB ,GPIO_Pin_0 );
	  	if(GPIO_ReadInputDataBit(GPIOB , GPIO_Pin_1))
			{
				count++;
				Delay_us(1);
			}
		}
		GPIO_SetBits(GPIOB ,GPIO_Pin_0 );
		Delay_us(1);
		count=count^0x800000;
		GPIO_ResetBits(GPIOB ,GPIO_Pin_0 );
		Delay_us(1);

	return count;
}
float Get_Weight(uint32_t Weight_ZeroPoint)
{
	uint32_t Weight;
  float Gram;
	Weight = HX711_Read()/100;
	if(Weight > Weight_ZeroPoint)
	{
		Weight = Weight - Weight_ZeroPoint;
		Gram = Volt_N*Weight/Uee+Error;
	}
    return Gram;
}
uint32_t Get_ZeroWeight(void)
{
  uint32_t Weight_Zero;
	Weight_Zero = (uint32_t)HX711_Read()/100;
  return Weight_Zero;
}
void scaleanalog(void)
{
	char number[10];
	char number1[10];
	uint8_t ax=30,ay=160,t=0;
	uint16_t getval=0;
	uint16_t l=0,v1=40,v2=310,v11=310,v22=40;
	uint16_t val1=0,val2=0;
	Draw_Full_Rect(0, 0 ,240 ,320 , LCD_GREEN);
	Set_Font(&Font16x24);
	Display_String(5,309,"SCALE", LCD_WHITE);
	Display_String(5, 311,"SCALE", LCD_RED);
	Delay_ms(100);
	while(sm1)
	{
		for(l=0;l<50;l++)
		{
			if(l%5==0)
			{
				Draw_Full_Circle(mx[l],my[l],4,LCD_WHITE);
				if(l%10==0)
				{
					Draw_Full_Circle(mx[l],my[l],2,LCD_BLACK);
				}
			}
			else
			{
				Draw_Full_Circle(mx[l],my[l],2,LCD_PINK);
				Delay_ms(10);
			}
		}	
		Set_Font(&Font8x16);
		Display_String(0,165,"0", LCD_VIOLET);
		Display_String(80,57,"1", LCD_VIOLET);
		Display_String(208,99,"2", LCD_VIOLET);
		Display_String(208,230,"3", LCD_VIOLET);
		Display_String(80,275,"4", LCD_VIOLET);
		sm1=0;
	}
	while(sm2)
	{
		sm2=0;
	}
	sm3=1;
	ic=1;
	while(sm3)
	{
		icon(7,7,28,35,LCD_RED,ic,1);  //x
		icon(7,40,28,100,LCD_RED,ic,2); //menu
		Set_Font(&Font12x12);
		Display_String(12, 25,"X", LCD_WHITE);
		Display_String(12, 90,"Menu", LCD_WHITE);
		ic=0;
		if(icr1==1)
		{
			sm4=0;
			sm1=0;
			sm3=0;
			op3=0;
			icr1=0;
			op5=0;
		}
		if(icr2==1)
		{
			ic=1;
			sm5=1;
			while(sm5)
			{
				icon(33,7,54,100,LCD_RED,ic,3); //analog
				icon(61,7,82,100,LCD_RED,ic,4); //digital
				icon(89,7,110,100,LCD_RED,ic,5); // zero
				Set_Font(&Font12x12);
				Display_String(38, 95,"Analog", LCD_WHITE);
				Display_String(66, 95,"Digital", LCD_WHITE);
				Display_String(94, 95,"Zero", LCD_WHITE);
				ic=0;
				if(icr3==1)
				{
					sm4=1;
					sm3=0;
					sm1=1;
					sm5=0;
					icr3=0;
				}
				if(icr4==1)
				{
					sm4=2;
					sm2=1;
					sm3=0;
					sm5=0;
					icr4=0;
				}
				if(icr5==1)
				{
					icr5=0;
					USART_puts(UART5,"z");
					sm3=0;
					sm5=0;
					if(sm4==1)
					{
						sm3=0;
						sm1=1;
					}
					else
					{
						sm4=2;
						sm2=1;	
					}
					sm5=0;
				}
			}
			icr2=0;
		}
		/*ax = 120 - (100*cos((14.4/57)*val));
		ay = 160 - (100*sin((14.4/57)*val));*/
		switch(sm4)
			{
				case 0:
				{
					Set_Font(&Font8x16);
				/*	v1=(rand() % 200)+30; 
					v2=(rand() % 310)+10;
					v11=rand();
					Display_String(v1,v2,"F", v11<<3);
					Delay_ms(400);*/
					Display_String(40,310,"Do luong va dieu khien bang may tinh", LCD_RED);
					Display_String(60,275,"De tai: Thiet ke can dien tu", LCD_RED);
					Display_String(90,310,"GVHD: Nguyen Khac Nguyen", LCD_BLACK);
					Display_String(120,310,"SVTH:", LCD_BLACK);
					Display_String(140,310,"Tran Chi Cuong          1111564", LCD_BLACK);
					Display_String(160,310,"Nguyen Huynh            1111567", LCD_BLACK);
					Display_String(180,310,"Duong Nguyen Ngoc Thy   1117935", LCD_BLACK);
					Display_String(200,310,"Luu Thi Anh Tuyet       1117947", LCD_BLACK);
				}
				break;
				case 1:
				{
					    val1=valscale/100;
							uint16tostr(number, valscale, 10);
				    	
							if(t==10)
							{
								USART_puts(USART2,number);
								USART_puts(USART3,number);
								Delay_ms(100);
								USART_puts(USART3,"a");
								t=0;
							}
							t++;
							if((ax!=cx[val1])||(ay!=cy[val1]))
							{
								Delay_ms(10);
								Draw_Line(120,160,ax,ay,LCD_GREEN);
								Draw_Full_Circle(ax,ay,2,LCD_GREEN);
							}
							Draw_Full_Circle(120,160,10,LCD_YELLOW);
							Draw_Line(120,160,cx[val1],cy[val1],LCD_WHITE);
							Draw_Full_Circle(cx[val1],cy[val1],2,LCD_RED);
							ax=cx[val1];
							ay=cy[val1];
							Set_Font(&Font16x24);
							Display_String(160,178,"KG", LCD_WHITE);
							Delay_ms(30);
				}
				break;
				case 2:
				{
					val1=0;
					val1=valscale;
					uint16tostr(number, valscale, 10);
					if(t==10)
						{
							USART_puts(USART2,number);
							USART_puts(USART3,number);
							Delay_ms(100);
							USART_puts(USART3,"a");
							t=0;
						}
						t++;
					if(val1>5000)
					{
						val1=5000;
					}
					Set_Font(&Font32x50);
					uint16tostr(number, val1, 10);
					if(val2!=val1)
					{
						Draw_Full_Rect(100,100,150,260,LCD_GREEN);
					}
					Display_String_Big(100, 230,number,32, LCD_WHITE);
					Set_Font(&Font16x24);
					Display_String(130, 80,"Gram", LCD_WHITE);
					Delay_ms(100);
					val2=val1;
				}
				break;	
			}
	}
}
void keypad(void)
{
	ky1=1;
	while(ky1)
	{
		icon(115,8,140,34,LCD_RED,ic,18); //p
		icon(115,39,140,65,LCD_RED,ic,19); //o
		icon(115,70,140,96,LCD_RED,ic,20); //i
		icon(115,101,140,127,LCD_RED,ic,21); //u
		icon(115,132,140,158,LCD_RED,ic,22); //y
		icon(115,163,140,189,LCD_RED,ic,23); //t
		icon(115,194,140,220,LCD_RED,ic,24); //r
		icon(115,225,140,251,LCD_RED,ic,25); //e
		icon(115,256,140,282,LCD_RED,ic,26); //w
		icon(115,287,140,313,LCD_RED,ic,27); //q
		//------------------------------------------//
		icon(145,23,170,49,LCD_RED,ic,28); //l
		icon(145,54,170,80,LCD_RED,ic,29); //k
		icon(145,85,170,111,LCD_RED,ic,30); //j
		icon(145,116,170,142,LCD_RED,ic,31); //h
		icon(145,147,170,173,LCD_RED,ic,32); //g
		icon(145,178,170,204,LCD_RED,ic,33); //f
		icon(145,209,170,235,LCD_RED,ic,34); //d
		icon(145,240,170,266,LCD_RED,ic,35); //s
		icon(145,271,170,297,LCD_RED,ic,36); //a
		//--------------------------------------------------//
		icon(175,54,200,80,LCD_RED,ic,37); //m
		icon(175,85,200,111,LCD_RED,ic,38); //n
		icon(175,116,200,142,LCD_RED,ic,39); //b
		icon(175,147,200,173,LCD_RED,ic,40); //v
		icon(175,178,200,204,LCD_RED,ic,41); //c
		icon(175,209,200,235,LCD_RED,ic,42); //x
		icon(175,240,200,266,LCD_RED,ic,43); //z
		icon(175,8,200,49,LCD_RED,ic,44); // clear
		icon(175,271,200,313,LCD_RED,ic,45); // so
		//-----------------------------------------------------//
		icon(205,85,230,235,LCD_RED,ic,46);
		icon(205,54,230,80,LCD_RED,ic,47); //rong
		icon(205,240,230,266,LCD_RED,ic,48); //rong
		icon(205,8,230,49,LCD_RED,ic,49); // exit
		icon(205,271,230,313,LCD_RED,ic,50); // ok
		ic=0;
		Set_Font(&Font12x12);
		Display_String(121, 27,"P", LCD_WHITE);
		Display_String(121, 58,"O", LCD_WHITE);
		Display_String(121, 89,"I", LCD_WHITE);
		Display_String(121, 120,"U", LCD_WHITE);
		Display_String(121, 151,"Y", LCD_WHITE);
		Display_String(121, 182,"T", LCD_WHITE);
		Display_String(121, 213,"R", LCD_WHITE);
		Display_String(121, 244,"E", LCD_WHITE);
		Display_String(121, 275,"W", LCD_WHITE);
		Display_String(121, 306,"Q", LCD_WHITE);
		Display_String(151, 42,"L", LCD_WHITE);
		Display_String(151, 73,"K", LCD_WHITE);
		Display_String(151, 104,"J", LCD_WHITE);
		Display_String(151, 135,"H", LCD_WHITE);
		Display_String(151, 166,"G", LCD_WHITE);
		Display_String(151, 197,"F", LCD_WHITE);
		Display_String(151, 228,"D", LCD_WHITE);
		Display_String(151, 259,"S", LCD_WHITE);
		Display_String(151, 290,"A", LCD_WHITE);
		Display_String(181, 73,"M", LCD_WHITE);
		Display_String(181, 104,"N", LCD_WHITE);
		Display_String(181, 135,"B", LCD_WHITE);
		Display_String(181, 166,"V", LCD_WHITE);
		Display_String(181, 197,"C", LCD_WHITE);
		Display_String(181, 228,"X", LCD_WHITE);
		Display_String(181, 259,"Z", LCD_WHITE);
		Display_String(211, 190,"SPACE", LCD_WHITE);
		Display_String(211, 37,"Ok", LCD_WHITE);
		Display_String(211, 297,"/", LCD_WHITE);
		Display_String(181, 37,"<<", LCD_WHITE);
		Display_String(181, 307,"123", LCD_WHITE);
		Display_String(211, 256,",", LCD_WHITE);
		Display_String(211, 70,".", LCD_WHITE);
		ky1=0;
	}
}
void setbaudrate(void)
{
	Draw_Full_Rect(29,242,140,318,LCD_GREEN);
	ic=1;
	ua2=1;
	ua8=310;
	while(ua2)
	{
		icon(35,245,56,315,LCD_RED,ic,11);
		icon(61,245,82,315,LCD_RED,ic,12);
		icon(87,245,108,315,LCD_RED,ic,13);
		icon(113,245,134,315,LCD_RED,ic,14);
		ic=0;
		Set_Font(&Font12x12);
		Display_String(40, 313,"9600", LCD_WHITE);
		Display_String(66, 313,"19200", LCD_WHITE);
		Display_String(92, 313,"38400", LCD_WHITE);
		Display_String(118, 313,"11500", LCD_WHITE);
		if(icr11==1)
		{
			ua3=1;
			icr11=0;
			ua2=0;
			ic=1;
			Uart_Config(E_USART5, 9600, 1,ENABLE,0, 0 );
		}
		if(icr12==1)
		{
			ua4=1;
			icr12=0;
			ua2=0;
			ic=1;
			Uart_Config(E_USART5, 19200, 1,ENABLE,0, 0 );
		}
		if(icr13==1)
		{
			ua5=1;
			icr13=0;
			ua2=0;
			ic=1;
			Uart_Config(E_USART5, 38400, 1,ENABLE,0, 0 );
		}
		if(icr14==1)
		{
			ua6=1;
			icr14=0;
			ua2=0;
			ic=1;
			Uart_Config(E_USART5, 115200, 1,ENABLE,0, 0 );
		}
	}
	Draw_Full_Rect(0,0,240,320,LCD_GREEN);	
	Draw_Full_Rect(31,5,60,315,LCD_RED);
	Draw_Full_Rect(70,5,100,315,LCD_RED);
	Draw_Rect(31,5,60,315,LCD_BLACK);
	Draw_Rect(70,5,100,315,LCD_BLACK);
	Draw_Rect(30,4,61,316,LCD_WHITE);
	Draw_Rect(69,4,101,316,LCD_WHITE);
}
void uart(void)
{
	char StrNumber1[10];
	char data_uart=0;
	ua1=1;
	ua3=1;
	Draw_Full_Rect(0,0,240,320,LCD_GREEN);	
	Draw_Full_Rect(31,5,60,315,LCD_RED);
	Draw_Full_Rect(70,5,100,315,LCD_RED);
	Draw_Rect(31,5,60,315,LCD_BLACK);
	Draw_Rect(70,5,100,315,LCD_BLACK);
	Draw_Rect(30,4,61,316,LCD_WHITE);
	Draw_Rect(69,4,101,316,LCD_WHITE);
	ic=1;
	ua8=310;
	ua9=0;
	while(ua1)
	{
		icon(7,7,28,35,LCD_RED,ic,1);  //x
		icon(7,245,28,315,LCD_RED,ic,2); //baut
		icon(7,170,28,240,LCD_RED,ic,3); //clear
		icon(7,95,28,165,LCD_RED,ic,4); //sent
		Set_Font(&Font12x12);
		Display_String(12, 25,"X", LCD_WHITE);
		Display_String(12, 230,"Clean", LCD_WHITE);
		Display_String(12, 155,"Sent", LCD_WHITE);
		if(ua3==1)
		{
			Set_Font(&Font12x12);
			Draw_Full_Rect(9,248,26,312,LCD_RED);
			Display_String(12, 313,"9600", LCD_WHITE);
			ua3=0;
		}
		if(ua4==1)
		{
			Set_Font(&Font12x12);
			Draw_Full_Rect(9,248,26,312,LCD_RED);
			Display_String(12, 313,"19200", LCD_WHITE);
			ua4=0;
		}
		if(ua5==1)
		{
			Set_Font(&Font12x12);
			Draw_Full_Rect(9,248,26,312,LCD_RED);
			Display_String(12, 313,"38400", LCD_WHITE);
			ua5=0;
		}
		if(ua6==1)
		{
			Set_Font(&Font12x12);
			Draw_Full_Rect(9,248,26,312,LCD_RED);
			Display_String(12, 313,"115200", LCD_WHITE);
			ua6=0;
		}
		if(icr1==1)
		{
			ua1=0;
			icr1=0;
		}
		if(icr2==1)
		{
			setbaudrate();
			icon(7,7,28,35,LCD_RED,ic,1);  //x
			icon(7,245,28,315,LCD_RED,ic,2); //baut
			icon(7,170,28,240,LCD_RED,ic,3); //clear
			icon(7,95,28,165,LCD_RED,ic,4); //sent
			Set_Font(&Font12x12);
			Display_String(12, 25,"X", LCD_WHITE);
			Display_String(12, 230,"Clean", LCD_WHITE);
			Display_String(12, 155,"Sent", LCD_WHITE);
			icr2=0;
		}
		if(icr3==1)
		{
			Draw_Full_Rect(34,7,58,313,LCD_RED);
			Draw_Full_Rect(72,7,102,313,LCD_RED);
			for(i=0;i<30;i++)
			{
				data[i]=0;
			}
			ua9=0;
			ua8=310;
			icr3=0;
		}
		if(icr4==1)
		{
			Set_Font(&Font12x12);
			for(i=0;i<ua9;i++)
			{
			 //	Display_String(80, 310-(i*12),data[i], LCD_WHITE);
				USART_puts(UART5,data[i]);
			}
			icr4=0;
		}
		data_uart=0;
		data_uart =uart_getc;
		if(data_uart!=0)
		{
			Display_Char(80, 310-(plus_uart*12),data_uart, LCD_WHITE);
			plus_uart++;
			if(plus_uart>=25)
			{
				plus_uart=0;
				Draw_Full_Rect(72,7,102,313,LCD_RED);
			}
		}
		uart_getc=0;
		keypad();
		if(icr18==1)
		{
			Set_Font(&Font12x12);
			Display_String(40, ua8,"P", LCD_WHITE);
			data[ua9] ="P";
			ua9++;
			icr18=0;
			ua8=ua8-12;
		}
		if(icr19==1)
		{
			Set_Font(&Font12x12);
			Display_String(40, ua8,"O", LCD_WHITE);
			data[ua9] ="O";
			ua9++;
			icr19=0;
			ua8=ua8-12;
		}
		if(icr20==1)
		{
			Set_Font(&Font12x12);
			Display_String(40, ua8,"I", LCD_WHITE);
			data[ua9] ="I";
			ua9++;
			icr20=0;
			ua8=ua8-12;
		}
		if(icr21==1)
		{
			Set_Font(&Font12x12);
			Display_String(40, ua8,"U", LCD_WHITE);
			data[ua9] ="U";
			ua9++;
			icr21=0;
			ua8=ua8-12;
		}
		if(icr22==1)
		{
			Set_Font(&Font12x12);
			Display_String(40, ua8,"Y", LCD_WHITE);
			data[ua9] ="Y";
			ua9++;
			icr22=0;
			ua8=ua8-12;
		}
		
		if(icr23==1)
		{
			Set_Font(&Font12x12);
			Display_String(40, ua8,"T", LCD_WHITE);
			data[ua9] ="T";
			ua9++;
			icr23=0;
			ua8=ua8-12;
		}
		if(icr24==1)
		{
			Set_Font(&Font12x12);
			Display_String(40, ua8,"R", LCD_WHITE);
			data[ua9] ="R";
			ua9++;
			icr24=0;
			ua8=ua8-12;
		}
		if(icr25==1)
		{
			Set_Font(&Font12x12);
			Display_String(40, ua8,"E", LCD_WHITE);
			data[ua9] ="E";
			ua9++;
			icr25=0;
			ua8=ua8-12;
		}
		if(icr26==1)
		{
			Set_Font(&Font12x12);
			Display_String(40, ua8,"W", LCD_WHITE);
			data[ua9] ="W";
			ua9++;
			icr26=0;
			ua8=ua8-12;
		}
		if(icr27==1)
		{
			Set_Font(&Font12x12);
			Display_String(40, ua8,"Q", LCD_WHITE);
			data[ua9] ="Q";
			ua9++;
			icr27=0;
			ua8=ua8-12;
		}
		if(icr28==1)
		{
			Set_Font(&Font12x12);
			Display_String(40, ua8,"L", LCD_WHITE);
			data[ua9] ="L";
			ua9++;
			icr28=0;
			ua8=ua8-12;
		}
		if(icr29==1)
		{
			Set_Font(&Font12x12);
			Display_String(40, ua8,"K", LCD_WHITE);
			data[ua9] ="K";
			ua9++;
			icr29=0;
			ua8=ua8-12;
		}
		if(icr30==1)
		{
			Set_Font(&Font12x12);
			Display_String(40, ua8,"J", LCD_WHITE);
			data[ua9] ="J";
			ua9++;
			icr30=0;
			ua8=ua8-12;
		}
		if(icr31==1)
		{
			Set_Font(&Font12x12);
			Display_String(40, ua8,"H", LCD_WHITE);
			data[ua9] ="H";
			ua9++;
			icr31=0;
			ua8=ua8-12;
		}
		if(icr32==1)
		{
			Set_Font(&Font12x12);
			Display_String(40, ua8,"G", LCD_WHITE);
			data[ua9] ="G";
			ua9++;
			icr32=0;
			ua8=ua8-12;
		}
		if(icr33==1)
		{
			Set_Font(&Font12x12);
			Display_String(40, ua8,"F", LCD_WHITE);
			data[ua9] ="F";
			ua9++;
			icr33=0;
			ua8=ua8-12;
		}
		if(icr34==1)
		{
			Set_Font(&Font12x12);
			Display_String(40, ua8,"D", LCD_WHITE);
			data[ua9] ="D";
			ua9++;
			icr34=0;
			ua8=ua8-12;
		}
		if(icr35==1)
		{
			Set_Font(&Font12x12);
			Display_String(40, ua8,"S", LCD_WHITE);
			data[ua9] ="S";
			ua9++;
			icr35=0;
			ua8=ua8-12;
		}
		if(icr36==1)
		{
			Set_Font(&Font12x12);
			Display_String(40, ua8,"A", LCD_WHITE);
			data[ua9] ="A";
			ua9++;
			icr36=0;
			ua8=ua8-12;
		}
		if(icr37==1)
		{
			Set_Font(&Font12x12);
			Display_String(40, ua8,"M", LCD_WHITE);
			data[ua9] ="M";
			ua9++;
			icr37=0;
			ua8=ua8-12;
		}
		if(icr38==1)
		{
			Set_Font(&Font12x12);
			Display_String(40, ua8,"N", LCD_WHITE);
			data[ua9] ="N";
			ua9++;
			icr38=0;
			ua8=ua8-12;
		}
		if(icr39==1)
		{
			Set_Font(&Font12x12);
			Display_String(40, ua8,"B", LCD_WHITE);
			data[ua9] ="B";
			ua9++;
			icr39=0;
			ua8=ua8-12;
		}
		if(icr40==1)
		{
			Set_Font(&Font12x12);
			Display_String(40, ua8,"V", LCD_WHITE);
			data[ua9] ="V";
			ua9++;
			icr40=0;
			ua8=ua8-12;
		}
		if(icr41==1)
		{
			Set_Font(&Font12x12);
			Display_String(40, ua8,"C", LCD_WHITE);
			data[ua9] ="C";
			ua9++;
			icr41=0;
			ua8=ua8-12;
		}
		if(icr42==1)
		{
			Set_Font(&Font12x12);
			Display_String(40, ua8,"X", LCD_WHITE);
			data[ua9] ="X";
			ua9++;
			icr42=0;
			ua8=ua8-12;
		}
		if(icr43==1)
		{
			Set_Font(&Font12x12);
			Display_String(40, ua8,"Z", LCD_WHITE);
			data[ua9] ="Z";
			ua9++;
			icr43=0;
			ua8=ua8-12;
		}
		if(icr44==1)
		{
			if(ua8==310)
			{
				icr44=0;
			}
			else
			{
				ua8=ua8+12;
				Draw_Full_Rect(35,ua8-12,55,ua8,LCD_RED);
				icr44=0;
				ua9--;
				data[ua9] =0;
			}
		}
		if(icr45==1)
		{
			Set_Font(&Font12x12);
			Display_String(40, ua8,"P", LCD_WHITE);
			icr45=0;
			ua8=ua8-12;
		}
		if(icr46==1)
		{
			Set_Font(&Font12x12);
		//	Display_String(40, ua8,"P", LCD_WHITE);
			data[ua9] =0;
			ua9++;
			icr46=0;
			ua8=ua8-12;
		}
		if(icr50==1)
		{
			Set_Font(&Font12x12);
			Display_String(40, ua8,"-", LCD_WHITE);
			USART_puts(UART5,"\t");
			ua9++;
			icr50=0;
			ua8=ua8-12;
		}
		if(ua8<15)
		{
			Draw_Full_Rect(35,6,55,310,LCD_RED);
			ua8=310;
		}
		ic=0;
	}
}

void icon(uint16_t ix1, uint16_t iy1, uint16_t ix2,uint16_t iy2, uint16_t icolor,uint8_t ic1,uint8_t click)
{
	uint8_t st=0;
	dieuchinhXY();
	while(ic1)
	{
		Draw_Rect(ix1-2,iy1-1,ix2,iy2+1,LCD_BLACK);
		Draw_Full_Rect(ix1,iy1,ix2,iy2-1,icolor);
		Draw_Rect(ix1-1,iy1-2,ix2,iy2,LCD_WHITE);
		ic1=0;
	}
	if((X0>ix1+3&&X0<ix2-3)&&(Y0>iy1+3&&Y0<iy2-3))
	{
		Delay_ms(50);
		Draw_Rect(ix1-1,iy1,ix2-1,iy2,LCD_BLACK);
		Delay_ms(50);
		st=1;
		ic1=1;
	}
	if(st==1)
	{
		Draw_Rect(ix1-1,iy1-2,ix2,iy2,LCD_WHITE);
		st=0;
		if(click==1)
			icr1=1;
		if(click==2)
			icr2=1;
		if(click==3)
			icr3=1;
		if(click==4)
			icr4=1;
		if(click==5)
			icr5=1;
		if(click==6)
			icr6=1;
		if(click==7)
			icr7=1;
		if(click==8)
			icr8=1;
		if(click==9)
			icr9=1;
		if(click==10)
			icr10=1;
		if(click==11)
			icr11=1;
		if(click==12)
			icr12=1;
		if(click==13)
			icr13=1;
		if(click==14)
			icr14=1;
		if(click==15)
			icr15=1;
		if(click==16)
			icr16=1;
		if(click==17)
			icr17=1;
		if(click==18)
			icr18=1;
		if(click==19)
			icr19=1;
		if(click==20)
			icr20=1;
		if(click==21)
			icr21=1;
		if(click==22)
			icr22=1;
		if(click==23)
			icr23=1;
		if(click==24)
			icr24=1;
		if(click==25)
			icr25=1;
		if(click==26)
			icr26=1;
		if(click==27)
			icr27=1;
		if(click==28)
			icr28=1;
		if(click==29)
			icr29=1;
		if(click==30)
			icr30=1;
		if(click==31)
			icr31=1;
		if(click==32)
			icr32=1;
		if(click==33)
			icr33=1;
		if(click==34)
			icr34=1;
		if(click==35)
			icr35=1;
		if(click==36)
			icr36=1;
		if(click==37)
			icr37=1;
		if(click==38)
			icr38=1;
		if(click==39)
			icr39=1;
		if(click==40)
			icr40=1;
		if(click==41)
			icr41=1;
		if(click==42)
			icr42=1;
		if(click==43)
			icr43=1;
		if(click==44)
			icr44=1;
		if(click==45)
			icr45=1;
		if(click==46)
			icr46=1;
		if(click==47)
			icr47=1;
		if(click==48)
			icr48=1;
		if(click==49)
			icr49=1;
		if(click==50)
			icr50=1;
	}
	
}
void setPID(void)
{
	e1 = (datavs*3)-dataVc;
  P=datap*e1; 
  sume += e1;
  I=datai*sume; 
  dbien=e1-e0;
  e0=e1;
  D=datad*dbien;
  datapwm =D+I+P;
}
void optionPID(void)
{
	uint8_t pos=0,j=0;
	Draw_Full_Rect(29,35,140,125,LCD_GREEN);
	ic=1;
	z5=1;
	while(z5)
	{
		icon(35,39,56,120,LCD_RED,ic,3);
		icon(61,39,82,120,LCD_RED,ic,4);
		icon(87,39,108,120,LCD_RED,ic,5);
		icon(113,39,134,120,LCD_RED,ic,6);
		ic=0;
		Set_Font(&Font12x12);
		Display_String(40, 80,"P", LCD_WHITE);
		Display_String(66, 80,"I", LCD_WHITE);
		Display_String(92, 80,"D", LCD_WHITE);
		Display_String(118, 80,"V", LCD_WHITE);
		if(icr3==1)
		{
			z1=1;
			z2=0;
			z3=0;
			z4=0;
			z5=0;
			icr3=0;
			py2=310;
		}
		if(icr4==1)
		{
			z1=0;
			z2=1;
			z3=0;
			z4=0;
			z5=0;
			icr4=0;
			py2=310;
		}
		if(icr5==1)
		{
			z1=0;
			z2=0;
			z3=1;
			z4=0;
			z5=0;
			icr5=0;
			py2=310;
		}
		if(icr6==1)
		{
			z1=0;
			z2=0;
			z3=0;
			z4=1;
			z5=0;
			ic=1;
			py2=310;
		}
	}
	Draw_Full_Rect(30,5,190,315,LCD_BLACK);
	Draw_Rect(31,6,189,314,LCD_WHITE);
	Draw_Rect(30,5,190,315,LCD_WHITE);
	for( j=0;j<7;j++)
	{
		pos= j*20;
		if(j==3)
		{
			Draw_Rect(50+pos,5,50+pos,315,LCD_GREEN);
		}
		else
		{
			Draw_Rect(50+pos,5,50+pos,315,LCD_WHITE);
		}
		Delay_ms(10);
	}
}
void PID(void)
{
	uint8_t pos=0,j=0,next=0,add=1;
	char StrNumber1[10];
	char StrNumber2[10];
	char StrNumber3[10];
	char StrNumber4[10];
	char StrNumber5[10];
	Draw_Full_Rect(0,0,240,320,LCD_GREEN);
	Delay_ms(10);
	Draw_Full_Rect(30,5,190,315,LCD_BLACK);
	Draw_Rect(31,6,189,314,LCD_WHITE);
	Draw_Rect(30,5,190,315,LCD_WHITE);
	Set_Font(&Font16x24);
	Display_String(6, 310,"PID", LCD_BLACK);
	for( j=0;j<7;j++)
	{
		pos= j*20;
		if(j==3)
			Draw_Rect(50+pos,5,50+pos,315,LCD_GREEN);
		else
			Draw_Rect(50+pos,5,50+pos,315,LCD_WHITE);
		Delay_ms(10);
	}
	Draw_Full_Rect(217,5,235,80,LCD_LIGH_BLUE);
	Draw_Full_Rect(217,85,235,160,LCD_LIGH_BLUE);
	Draw_Full_Rect(217,170,235,215,LCD_LIGH_BLUE);
	Draw_Full_Rect(217,220,235,265,LCD_LIGH_BLUE);
	Draw_Full_Rect(217,270,235,315,LCD_LIGH_BLUE);
	Draw_Rect(216,4,236,81,LCD_WHITE);
	Draw_Rect(216,84,236,161,LCD_WHITE);
	Draw_Rect(216,169,236,216,LCD_WHITE);
	Draw_Rect(216,219,236,266,LCD_WHITE);
	Draw_Rect(216,269,236,316,LCD_WHITE);
	Draw_Rect(217,5,235,80,LCD_BLACK);
	Draw_Rect(217,85,235,160,LCD_BLACK);
	Draw_Rect(217,170,235,215,LCD_BLACK);
	Draw_Rect(217,220,235,265,LCD_BLACK);
	Draw_Rect(217,270,235,315,LCD_BLACK);
	Set_Font(&Font12x12);
	Display_String(220, 313,"P", LCD_RED);
	Display_String(220, 263,"I", LCD_RED);
	Display_String(220, 213,"D", LCD_RED);
	Display_String(220, 158,"S", LCD_RED);
	Display_String(220, 78,"C", LCD_RED);
	pi=1;
	ic=1;
	py1=0;
	py2=310;
	dataVs=0;
	datai=0;
	datap=0;
	datad=0;
	Pp=0;Pi=0;Pd=0;
	z1=0;z2=0;z3=0;z4=0;z5=0;z6=0;
	next=1;
	while(pi)
	{
		icon(7,7,28,35,LCD_RED,ic,1);  //x
		icon(7,39,28,120,LCD_RED,ic,2); //op
		icon(195,10,212,80,LCD_RED,ic,3);//star
		icon(195,85,212,155,LCD_RED,ic,4);//defaut
		icon(195,165,212,235,LCD_RED,ic,5);//down
		icon(195,240,212,310,LCD_RED,ic,6);//up
		icon(7,124,28,194,LCD_RED,ic,7); //clear
		icon(7,198,28,238,LCD_RED,ic,8); //next
		ic=0;
		Set_Font(&Font12x12);
	  Display_String(12, 110,"Option", LCD_WHITE);
		Display_String(12, 25,"X", LCD_WHITE);
		Display_String(197, 285,"Up", LCD_WHITE);
		Display_String(197, 222,"Down", LCD_WHITE);
		Display_String(197, 150,"Defaut", LCD_WHITE);
		Display_String(197, 68,"Star", LCD_WHITE);	
		Display_String(12, 185,"Clean", LCD_WHITE);
		if(next==1)
		{
				Display_String(12, 230,"X1", LCD_WHITE);
				add=1;
		}
		if(icr8==1)
		{
			next++;
			if(next==5) next=1;
			if(next==1)
			{
				Draw_Full_Rect(12,200,25,235,LCD_RED);
				Display_String(12, 230,"X1", LCD_WHITE);
				add=1;
			}
			if(next==2)
			{
				Draw_Full_Rect(12,200,25,235,LCD_RED);
				Display_String(12, 230,"X2", LCD_WHITE);
				add=2;
			}
			if(next==3)
			{
				Draw_Full_Rect(12,200,25,235,LCD_RED);
				Display_String(12, 230,"X3", LCD_WHITE);
				add=3;
			}
			if(next==4)
			{
				Draw_Full_Rect(12,200,25,235,LCD_RED);
				Display_String(12, 230,"X4", LCD_WHITE);
				add=4;
			}
				py2=310;
				py1=0;
				Draw_Full_Rect(30,5,190,315,LCD_BLACK);
				Draw_Rect(31,6,189,314,LCD_WHITE);
				Draw_Rect(30,5,190,315,LCD_WHITE);
				for( j=0;j<7;j++)
				{
					pos= j*20;
					if(j==3)
						Draw_Rect(50+pos,5,50+pos,315,LCD_GREEN);
					else
						Draw_Rect(50+pos,5,50+pos,315,LCD_WHITE);
						Delay_ms(10);
				}
			icr8=0;
		}
		if(icr4==1)
		{
			py1=0;
			py2=310;
			dataVs=0;
			datavs=0;
			datai=0;
			datap=0;
			datad=0;
			Pp=0;Pi=0;Pd=0;
			z1=0;z2=0;z3=0;z4=0;z5=0;z6=0;
			icr4=0;
			Draw_Full_Rect(30,5,190,315,LCD_BLACK);
			Draw_Rect(31,6,189,314,LCD_WHITE);
			Draw_Rect(30,5,190,315,LCD_WHITE);
			for( j=0;j<7;j++)
			{
				pos= j*20;
				if(j==3)
					Draw_Rect(50+pos,5,50+pos,315,LCD_GREEN);
				else
					Draw_Rect(50+pos,5,50+pos,315,LCD_WHITE);
					Delay_ms(10);
			}
		}
		if(icr7==1)
		{
				py2=310;
				py1=0;
				icr7=0;
				Draw_Full_Rect(30,5,190,315,LCD_BLACK);
				Draw_Rect(31,6,189,314,LCD_WHITE);
				Draw_Rect(30,5,190,315,LCD_WHITE);
				for( j=0;j<7;j++)
				{
					pos= j*20;
					if(j==3)
						Draw_Rect(50+pos,5,50+pos,315,LCD_GREEN);
					else
						Draw_Rect(50+pos,5,50+pos,315,LCD_WHITE);
						Delay_ms(10);
					}
		}
		if(icr1==1)
		{
			pi=0;
			icr1=0;
		}
		if(icr2==1)
		{
			optionPID();
			icr2=0;
		}
		if(icr3==1)
		{
			datap=Pp;
			datai=Pi;
			datad=Pd;
			datavs=dataVs;
			icr3=0;
		}
		if(icr4==1)
		{
			datap=0;
			datai=0;
			datad=0;
			datavs=0;
			icr4=0;
		}
		if(icr5==1)
		{
			if(z1==1)
			{
				Pp--;
				if(Pp==255)Pp=60;
			}
			if(z2==1)
			{
				Pi--;
				if(Pi==255)Pi=60;
			}
			if(z3==1)
			{
				Pd--;
				if(Pd==255)Pd=60;
			}
			if(z4==1)
			{
				dataVs=dataVs-100;
				if(dataVs<65535&&dataVs>3000)dataVs=3000;
			}
			icr5=0;
		}
		if(icr6==1)
		{
			if(z1==1)
			{
				Pp++;
				if(Pp>60)Pp=0;
			}
			if(z2==1)
			{
				Pi++;
				if(Pi>60)Pi=0;
			}
			if(z3==1)
			{
				Pd++;
				if(Pd>60)Pd=0;
			}
			if(z4==1)
			{
				dataVs=dataVs+100;
				if(dataVs>3000)dataVs=0;
			}
			icr6=0;
		}
		setPID();
		CCR3_Val=datapwm;
		TIM8->CCR3 = CCR3_Val;
		dataVc = (dataline5/4)/3.34;
		px1= (datavs*100)/3000;
		px2 = (150*px1)/100;
		px3= (dataVc*100)/3000;
		px4 = (150*px3)/100;
		Set_Font(&Font12x12);
		uint16tostr(StrNumber1, Pp, 10);
		uint16tostr(StrNumber2, Pi, 10);
		uint16tostr(StrNumber3, Pd, 10);
		uint16tostr(StrNumber4, dataVs, 10);
		uint16tostr(StrNumber5, dataVc, 10);
		Draw_Full_Rect(219,8,233,63,LCD_LIGH_BLUE);
		Draw_Full_Rect(219,87,233,143,LCD_LIGH_BLUE);
		Draw_Full_Rect(219,172,233,198,LCD_LIGH_BLUE);
		Draw_Full_Rect(219,222,233,248,LCD_LIGH_BLUE);
		Draw_Full_Rect(219,272,235,298,LCD_LIGH_BLUE);
		Display_String(220, 298,StrNumber1, LCD_RED);
		Display_String(220, 248,StrNumber2, LCD_RED);
		Display_String(220, 198,StrNumber3, LCD_RED);
		Display_String(220, 143,StrNumber4, LCD_RED);
		Display_String(220, 63 ,StrNumber5, LCD_RED);
		
		if(px6!=px2)
		{
			Draw_Line(185-px6, py2, 185-px2,py2, LCD_YELLOW);
		}
		else
		{
			Draw_Pixel((185-px2),py2,LCD_YELLOW);
		}
		if(px4!=px7)
		{
			Draw_Line(185-px7, py2, 185-px4,py2, LCD_RED);
		}
		else
		{
			Draw_Pixel((185-px4),py2,LCD_RED);
		}
		px6=px2;
		px7=px4;	
		py1++;
		if(py1==(10*add))
		{
				py2--;		
				if(py2==10)
				{
						py2=310;
						Draw_Full_Rect(30,5,190,315,LCD_BLACK);
						Draw_Rect(31,6,189,314,LCD_WHITE);
						Draw_Rect(30,5,190,315,LCD_WHITE);
						for( j=0;j<7;j++)
						{
							pos= j*20;
							if(j==3)
								Draw_Rect(50+pos,5,50+pos,315,LCD_GREEN);
							else
								Draw_Rect(50+pos,5,50+pos,315,LCD_WHITE);
							Delay_ms(10);
						}
				}
				py1=0;
			}
	}
	Clear_Screen(0x0000);
}
void set(void)
{
	icon(35,39,56,120,LCD_RED,ic,3);
	icon(61,39,82,120,LCD_RED,ic,4);
	icon(87,39,108,120,LCD_RED,ic,5);
	icon(113,39,134,120,LCD_RED,ic,6);
	ic=0;
	Set_Font(&Font12x12);
	Display_String(40, 100,"CH1", LCD_WHITE);
	Display_String(66, 100,"CH2", LCD_WHITE);
	Display_String(92, 119,"CH1&CH2", LCD_WHITE);
	Display_String(118, 115,"Setmv", LCD_WHITE);
	if(icr3==1)
	{
		st=0;
		icr3=0;
		Set_Font(&Font16x24);
		Draw_Full_Rect(2,125,29,250,LCD_LIGH_BLUE);
		Display_String(6, 245,"CH1", LCD_BLACK);
		adcch1=1;
		adcch2=0;
		setmv2=0;
	}
	if(icr4==1)
	{
		st=0;
		icr4=0;
		Set_Font(&Font16x24);
		Draw_Full_Rect(2,125,29,250,LCD_LIGH_BLUE);
		Display_String(6, 245,"CH2", LCD_BLACK);
		adcch1=0;
		adcch2=1;
		setmv2=0;
	}
	if(icr5==1)
	{
		st=0;
		icr5=0;
		Set_Font(&Font16x24);
		Draw_Full_Rect(2,125,29,250,LCD_LIGH_BLUE);
		Display_String(6, 245,"CH1&CH2", LCD_BLACK);
		adcch1=1;
		adcch2=1;
		setmv2=0;
	}
	if(icr6==1)
	{
		st=0;
		setmv2=1;
		icr6=0;
		ic=1;
	}
}
void oscillocope(void)
{
	uint8_t text=0;
	char StrNumber1[10];
	char StrNumber2[10];
	uint8_t os=0, i=0, exit=1,tt=0;
	uint16_t oss=0;
	Draw_Rect(31,6,189,314,LCD_WHITE);
	Draw_Rect(30,5,190,315,LCD_WHITE);
	Set_Font(&Font16x24);
	Display_String(6, 310,"OSC", LCD_BLACK);
	for( i=0;i<7;i++)
	{
		os= i*20;
		if(i==3)
			Draw_Rect(50+os,5,50+os,315,LCD_GREEN);
		else
			Draw_Rect(50+os,5,50+os,315,LCD_WHITE);
		Delay_ms(10);
	}
	ic=1;
	//exit=1;
	adcy2=310;
	setmv0=300;
	setmv1=1;
	while(exit)
	{
		icon(7,7,28,35,LCD_RED,ic,1);
		icon(7,39,28,120,LCD_RED,ic,2);
		icon(215,7,235,95,LCD_RED,ic,0);
		icon(195,10,212,80,LCD_RED,ic,0);
		icon(195,85,212,155,LCD_RED,ic,0);
		icon(195,165,212,235,LCD_RED,ic,0);
		icon(195,240,212,310,LCD_RED,ic,0);
		if(icr1==1)
		{
			exit=0;
		}
		if(icr2==1)
		{
			Draw_Full_Rect(29,35,115,125,LCD_LIGH_BLUE);
			ic=1;
			while(st)
			{
				set();
			}
			Draw_Full_Rect(29,5,190,315,LCD_BLACK);
			Draw_Rect(31,6,189,314,LCD_WHITE);
			Draw_Rect(30,5,190,315,LCD_WHITE);
			for( i=0;i<7;i++)
			{
				os= i*20;
				if(i==3)
					Draw_Rect(50+os,5,50+os,315,LCD_GREEN);
				else
					Draw_Rect(50+os,5,50+os,315,LCD_WHITE);
				Delay_ms(10);
			}
			icr2=0;
		}
		ic=0;
		st=1;
		Set_Font(&Font12x12);
	  Display_String(12, 110,"Option", LCD_WHITE);
		Display_String(12, 25,"X", LCD_WHITE);
		Display_String(220, 80,"Star", LCD_WHITE);
		Display_String(197, 285,"Up", LCD_WHITE);
		Display_String(197, 222,"Down", LCD_WHITE);
		Display_String(197, 142,"Left", LCD_WHITE);
		Display_String(197, 68,"Righ", LCD_WHITE);
		Display_String(220, 130,"mV", LCD_WHITE);
		Display_String(220, 230,"Hz", LCD_WHITE);	
		adcy1++;
		Hz1=0,Hz2=0;
		if(adcy1==10)
		{
			adcy2--;
			if(adcy2==10) adcy2=310;
		}
		if(adcy1==10) adcy1=0;
		for(oss=0;oss<30000;oss++)
		{
			adc1 = ADCValue[0];
			adc2=(adc1*100)/4096;
			adc3=(adc2*150)/100;
			osc1[oss]=adc3;
			
			adc4 = ADCValue[1];
			adc5=(adc4*100)/4096;
			adc6=(adc5*150)/100;
			osc2[oss]=adc6;
		}
		for(oss=0;oss<30000;oss++)
		{
			if(osc1[oss]>100&&Hz1==0)
			{
				Hz2++;
				Hz1=1;
			}
			if(osc1[oss]<100&&Hz1==1)
			{
			  Hz2++;
				Hz1=0;
			}
		}
		adcy2=310;
		tt=0;
		Hz2=Hz2*10;
		Set_Font(&Font12x12);
		uint16tostr(StrNumber1, Hz2, 10);
		Draw_Full_Rect(220,235,235,305,LCD_BLACK);
		Display_String(220,300,StrNumber1, LCD_WHITE);
		for(oss=0;oss<setmv0;oss++)
		{
			
				//////////////////////////////////////////////////////////////////
			icon(7,39,28,120,LCD_RED,ic,2);
			icon(7,7,28,35,LCD_RED,ic,1);
			if(icr1==1)
			{
				exit=0;
				oss=setmv0;
				icr1=0;
			}
			if(icr2==1)
			{
				Draw_Full_Rect(29,35,140,125,LCD_LIGH_BLUE);
				ic=1;
				while(st)
				{
					set();
				}
				Draw_Full_Rect(29,5,190,315,LCD_BLACK);
				Draw_Rect(31,6,189,314,LCD_WHITE);
				Draw_Rect(30,5,190,315,LCD_WHITE);
				for( i=0;i<7;i++)
				{
					os= i*20;
					if(i==3)
						Draw_Rect(50+os,5,50+os,315,LCD_GREEN);
					else
						Draw_Rect(50+os,5,50+os,315,LCD_WHITE);
					Delay_ms(10);
				}
				
				icr2=0;
				oss=setmv0;
				adcy2=310;
				st=1;
				setmv1=1;
				while(setmv2)
				{
					
					icon(215,7,235,95,LCD_RED,ic,11);//star
					icon(195,10,212,80,LCD_RED,ic,12);//right
					icon(195,85,212,155,LCD_RED,ic,13);//left
					icon(195,165,212,235,LCD_RED,ic,14);//down
					icon(195,240,212,310,LCD_RED,ic,15);//up
					Set_Font(&Font12x12);
					Display_String(220, 80,"Star", LCD_WHITE);
					Display_String(197, 285,"Up", LCD_WHITE);
					Display_String(197, 222,"Down", LCD_WHITE);
					Display_String(197, 142,"Left", LCD_WHITE);
					Display_String(197, 68,"Righ", LCD_WHITE);
					uint16tostr(StrNumber2, setmv1, 10);
					Draw_Full_Rect(220,120,235,190,LCD_BLACK);
					Display_String(220,180,StrNumber2, LCD_WHITE);
				
					ic=0;
					if(icr15==1)
					{
						setmv1++;
						if(setmv1>=30) setmv1=1;
						icr15=0;
						text=0;
					}
					if(icr14==1)
					{
						setmv1--;
						if(setmv1==0) setmv1=10;
						icr14=0;
						text=0;
					}
					if(icr11==1)
					{
						text++;
						if(text==2)
						{
							setmv2=0;
							setmv0=setmv1*300;
							if(setmv1==10) setmv1=1;
							icr11=0;		
							text=0;
							oss=setmv0;
							adcy2=310;
						}
					}
				}
			}
			//////////////////////////////////////////////////////////////////////
			Delay_ms(5);
			tt++;
			if(tt==(setmv0/300))
			{
				adcy2--;	
				tt=0;	
			}				
			if(adcy2==10)adcy2=310;
			adc3=osc1[oss];
			adc6=osc2[oss];
			if(adcch1==1)
			{
				if(osc1[oss-1]!=osc1[oss])
				{
					Draw_Line(185-osc1[oss-1], adcy2, 185-osc1[oss],adcy2, LCD_YELLOW);
				}
				else
				{
					Draw_Pixel((185-adc3),adcy2,LCD_YELLOW);
				}
			}
			if(adcch2==1)
			{
				if(osc2[oss-1]!=osc2[oss])
				{
					Draw_Line(185-osc2[oss-1], adcy2, 185-osc2[oss],adcy2, LCD_RED);
				}
				else
				{
					Draw_Pixel((185-adc6),adcy2,LCD_RED);
				}
			}
		}
		Draw_Full_Rect(29,5,190,315,LCD_BLACK);
		Draw_Rect(31,6,189,314,LCD_WHITE);
		Draw_Rect(30,5,190,315,LCD_WHITE);
		for( i=0;i<7;i++)
		{
			os= i*20;
			if(i==3)
				Draw_Rect(50+os,5,50+os,315,LCD_GREEN);
			else
				Draw_Rect(50+os,5,50+os,315,LCD_WHITE);
				Delay_ms(10);
		}
		op3=0;
		
	}
}

void Axis(void)
{
	char StrNumber1[10];
	uint8_t axplus=0;
	Draw_Full_Rect(0,0,240,320,LCD_GREEN);
	Draw_Full_Rect(50,70,230,250,LCD_RED);
	Draw_Rect(50,70,230,250,LCD_WHITE);
	Draw_Rect(51,71,229,249,LCD_BLACK);
	Draw_Rect(52,72,228,248,LCD_BLACK);
	Draw_Rect(140,72,140,248,LCD_GREEN);
	Draw_Rect(52,160,228,160,LCD_GREEN);
	
	Draw_Full_Circle(55,55,10,LCD_BLACK);
	Draw_Full_Circle(85,55,10,LCD_BLACK);
	Draw_Full_Circle(115,55,10,LCD_BLACK);
	Draw_Full_Circle(145,55,10,LCD_BLACK);
	Draw_Full_Circle(175,55,10,LCD_BLACK);
	
	Draw_Circle(55,55,11,LCD_WHITE);
	Draw_Circle(85,55,11,LCD_WHITE);
	Draw_Circle(115,55,11,LCD_WHITE);
	Draw_Circle(145,55,11,LCD_WHITE);
	Draw_Circle(175,55,11,LCD_WHITE);
	
	Draw_Circle(55,55,10,LCD_BLACK);
	Draw_Circle(85,55,10,LCD_BLACK);
	Draw_Circle(115,55,10,LCD_BLACK);
	Draw_Circle(145,55,10,LCD_BLACK);
	Draw_Circle(175,55,10,LCD_BLACK);
	Set_Font(&Font16x24);
	Display_String(10, 310,"X:", LCD_RED);
	Display_String(10, 170,"Y:", LCD_RED);
	Set_Font(&Font12x12);
	Display_String(50, 40,"2G", LCD_RED);
	Display_String(80, 40,"4G", LCD_RED);
	Display_String(110,40,"6G", LCD_RED);
	Display_String(140, 40,"8G", LCD_RED);
	Display_String(170,40,"16G", LCD_RED);
	ic=1;
	ax=1;
	Delay_ms(100);
	while(ax)
	{
		axplus++;
		dieuchinhXY();
		LIS302DL_Read(Buffer, LIS302DL_OUT_X_ADDR, 3);
		XA =Buffer[2];
		YA =Buffer[0];
		if(Buffer[2]<90)
		{
			XA=XA*2+140;
			Delay_ms(40);
			if(XA>=215)
				XA=215;
		}
		if(Buffer[2]>90)
		{
			XA=140-(255-XA)*2;
			Delay_ms(40);
			if(XA<=65)
				XA=65;
		}
		if(Buffer[0]<90)
		{
			YA=YA*2+160;
			Delay_ms(40);
			if(YA>=235)
				YA=235;
		}
		if((Buffer[0]>90))
		{
			YA=160-(255-YA)*2;
			Delay_ms(40);
			if(YA<=85)
				YA=85;
		}
		Set_Font(&Font16x24);
		uint16tostr(StrNumber1, Buffer[0], 10);
		Draw_Full_Rect(10,200,40,290,LCD_GREEN);
		Display_String(10,290,StrNumber1, LCD_RED);
		uint16tostr(StrNumber1, Buffer[2], 10);
		Draw_Full_Rect(10,145,40,80,LCD_GREEN);
		Display_String(10, 145,StrNumber1, LCD_RED);
		if(axplus>5)
		{
			if((XA!=XAO)||(YA!=YAO))
			{
				Draw_Rect(140,72,140,248,LCD_GREEN);
				Draw_Rect(52,160,228,160,LCD_GREEN);
				Draw_Full_Circle(XAO,YAO,10,LCD_RED);
				Draw_Full_Circle(XA,YA,10,LCD_YELLOW);
				if((XA==140)&&(YA==160))
				{
					Draw_Full_Circle(XA,YA,6,LCD_BLACK);
				}
			}
		}
		if((X0>45&&X0<65)&&(Y0>40&&Y0<70))
		{
			Draw_Full_Circle(55,55,5,LCD_RED);
			Draw_Full_Circle(85,55,5,LCD_BLACK);
			Draw_Full_Circle(115,55,5,LCD_BLACK);
			Draw_Full_Circle(1455,55,5,LCD_BLACK);
			Draw_Full_Circle(175,55,5,LCD_BLACK);
		}
		if((X0>75&&X0<96)&&(Y0>40&&Y0<70))
		{
			Draw_Full_Circle(85,55,5,LCD_RED);
			Draw_Full_Circle(55,55,5,LCD_BLACK);
			Draw_Full_Circle(115,55,5,LCD_BLACK);
			Draw_Full_Circle(145,55,5,LCD_BLACK);
			Draw_Full_Circle(175,55,5,LCD_BLACK);
		}
			if((X0>105&&X0<126)&&(Y0>40&&Y0<70))
		{
			Draw_Full_Circle(115,55,5,LCD_RED);
			Draw_Full_Circle(55,55,5,LCD_BLACK);
			Draw_Full_Circle(85,55,5,LCD_BLACK);
			Draw_Full_Circle(145,55,5,LCD_BLACK);
			Draw_Full_Circle(175,55,5,LCD_BLACK);
		}
			if((X0>135&&X0<156)&&(Y0>40&&Y0<70))
		{
			Draw_Full_Circle(145,55,5,LCD_RED);
			Draw_Full_Circle(55,55,5,LCD_BLACK);
			Draw_Full_Circle(115,55,5,LCD_BLACK);
			Draw_Full_Circle(85,55,5,LCD_BLACK);
			Draw_Full_Circle(175,55,5,LCD_BLACK);
		}
			if((X0>165&&X0<186)&&(Y0>40&&Y0<70))
		{
			Draw_Full_Circle(175,55,5,LCD_RED);
			Draw_Full_Circle(55,55,5,LCD_BLACK);
			Draw_Full_Circle(115,55,5,LCD_BLACK);
			Draw_Full_Circle(145,55,5,LCD_BLACK);
			Draw_Full_Circle(85,55,5,LCD_BLACK);
		}
		icon(7,7,28,35,LCD_RED,ic,1);
		ic=0;
		Set_Font(&Font12x12);
		Display_String(12, 25,"X", LCD_WHITE);
		if(icr1==1)
		{
			icr1=0;
			ax=0;
		}
		XAO=XA;
		YAO=YA;
		if(axplus>10)
		{
			axplus=10;
		}
	}
}
void updateaxit(uint16_t xa,uint16_t ya)
{
	XA=xa;
	YA=ya;
}
void calibration(void)
{
	Delay_ms(50);
	Draw_Full_Rect(0,240,0,320,LCD_BLACK);
	Delay_ms(50);
	cl=1;
	Draw_Full_Circle(30,290,2,LCD_WHITE);
	Draw_Circle(30, 290, 8, LCD_YELLOW);
	Draw_Circle(30, 290, 7, LCD_YELLOW);
	while(cl)
	{
		dieuchinhXY();
		if((X0<40&&X0>20)&&(Y0<300&&Y0>280)&&cali==0)
		{
			Delay_ms(100);
			Clear_Screen(0x0000);
			Draw_Full_Circle(210,290,2,LCD_WHITE);
			Draw_Circle(210, 290, 8, LCD_YELLOW);
			Draw_Circle(210, 290, 7, LCD_YELLOW);
			cx1=X0;
			cy1=Y0;
			cali =1;
		}
		if((X0<220&&X0>200)&&(Y0<300&&Y0>280)&&cali==1)
		{
			Delay_ms(100);
			Clear_Screen(0x0000);
			Draw_Full_Circle(210,30,2,LCD_WHITE);
			Draw_Circle(210, 30, 8, LCD_YELLOW);
			Draw_Circle(210, 30, 7, LCD_YELLOW);
			cx2=X0;
			cy2=Y0;
			cali =2;
		}
		if((X0<220&&X0>200)&&(Y0<40&&Y0>20)&&cali==2)
		{
			Delay_ms(100);
			Clear_Screen(0x0000);
			Draw_Full_Circle(30,30,2,LCD_WHITE);
			Draw_Circle(30, 30, 8, LCD_YELLOW);
			Draw_Circle(30, 30, 7, LCD_YELLOW);
			cx3=X0;
			cy3=Y0;
			cali =3;
		}
		if((X0<40&&X0>20)&&(Y0<40&&Y0>20)&&cali==3)
		{
			Clear_Screen(0x0000);
			Delay_ms(100);
			cx4=X0;
			cy4=Y0;
			cali =4;
		}
		if(cali==4)       //x=480 y=640
		{
			calitbx=cx1+cx2+cx3+cx4;
			calitby=cy1+cy2+cy3+cy4;
			if(calitbx>480||calitby>640)
			{
				//calix2=(calitbx-480)/4;
				//caliy2=(calitby-640)/4;
				//caliy2=5;
				//calix2=5;
				calix1=3;
				caliy1=3;
				calix2=0;
				caliy2=0;
			}
			if(calitbx<480||calitby<640)
			{
			//	calix2=((480-calitbx)/4)+5;
				//caliy2=((640-calitby)/4)+5;
				//calix1=0;
				//caliy1=0;
				calix1=3;
				caliy1=3;
				calix2=0;
				caliy2=0;
			}
			if(calitbx==480||calitby==640)
			{
				calix1=3;
				caliy1=3;
				calix2=0;
				caliy2=0;
				
			}
			cali=0;  
			cl=0;				
		}	
		
	}
}
void brightness(void)
{
	uint8_t Y01=0;
	char numbr[10];
	Draw_Full_Rect(0,0,240,320,LCD_LIGH_BLUE);
	Set_Font(&Font16x24);
	Display_String(10, 270,"Brightness", LCD_RED);
	Draw_Rect(100,30,130,290,LCD_YELLOW);
	br1=1;
	ic=1;
	while(br1)
	{	
		dieuchinhXY();
		if((100<X0&&X0<130)&&(35<Y0&&Y0<285))
		{
			Delay_ms(50);
			Y01 = 290-Y0;
			br= (Y01*100)/250;
			CCR1_Val = (br*666)/100;
			CCR3_Val = (br*665)/100;
			CCR4_Val = (br*665)/100;
			uint16tostr(numbr, br , 10);
			Set_Font(&Font16x24);
			TIM4->CCR1 = CCR1_Val; 
			TIM8->CCR3 = CCR3_Val; 
			TIM8->CCR4 = CCR4_Val; 
			Draw_Full_Rect(70,70,95,10,LCD_LIGH_BLUE);
			Display_String(75, 60,numbr, LCD_RED);
			Draw_Full_Rect(105,Y0+5,125,285,LCD_RED);
			Draw_Full_Rect(105,Y0+5,125,Y0,LCD_WHITE);
			
			Draw_Full_Rect(105,35,125,Y0,LCD_LIGH_BLUE);
		}
		icon(7,7,28,35,LCD_RED,ic,1);
		ic=0;
		Set_Font(&Font12x12);
		Display_String(12, 25,"X", LCD_WHITE);
		if(icr1==1)
		{
			Delay_ms(100);
			br1=0;
			Clear_Screen(0x0000);
			icr1=0;
		}
		op3=0;
		
	}
	
}
long map(long x, long in_min, long in_max, long out_min, long out_max)
{
  return (x - in_min) * (out_max - out_min) / (in_max - in_min) + out_min;
}
void option(void)
{
	dieuchinhXY();
	if((10<X0&&X0<39)&&(193<Y0&&Y0<300))
	{
		Delay_ms(50);
		op1=0;
		opa11=0;opa1=0;opa2=0;opa3=0;opa4=0;opa5=0;opa6=0;opa7=0;opa8=0;opa9=0;
		opa0++;
		if(opa0>=3) {op3=1;op4=1;}
		Draw_Rect(5+0,10,39+0,155,LCD_BLACK);
		Draw_Rect(5+40,10,39+40,155,LCD_BLACK);
		Draw_Rect(5+80,10,39+80,155,LCD_BLACK);
		Draw_Rect(5+120,10,39+120,155,LCD_BLACK);
		Draw_Rect(5+160,10,39+160,155,LCD_BLACK);
		Draw_Rect(5+40,185,39+40,315,LCD_BLACK);
		Draw_Rect(5+80,185,39+80,315,LCD_BLACK);
		Draw_Rect(5+120,185,39+120,315,LCD_BLACK);
		Draw_Rect(5+160,185,39+160,315,LCD_BLACK);
		Draw_Rect(5+200,185,39+200,315,LCD_BLACK);
		Draw_Rect(5+op1,185,39+op1,315,LCD_GREEN);
	}
	
	if((45<X0&&X0<75)&&(193<Y0&&Y0<300))
	{
		Delay_ms(50);
		op1=40;
		opa11=0;opa0=0;opa2=0;opa3=0;opa4=0;opa5=0;opa6=0;opa7=0;opa8=0;opa9=0;
		opa1++;
		if(opa1>=3) {op3=2;op4=1;}
		Draw_Rect(5+0,10,39+0,155,LCD_BLACK);
		Draw_Rect(5+40,10,39+40,155,LCD_BLACK);
		Draw_Rect(5+80,10,39+80,155,LCD_BLACK);
		Draw_Rect(5+120,10,39+120,155,LCD_BLACK);
		Draw_Rect(5+160,10,39+160,155,LCD_BLACK);
		Draw_Rect(5+0,185,39+0,315,LCD_BLACK);
		Draw_Rect(5+80,185,39+80,315,LCD_BLACK);
		Draw_Rect(5+120,185,39+120,315,LCD_BLACK);
		Draw_Rect(5+160,185,39+160,315,LCD_BLACK);
		Draw_Rect(5+200,185,39+200,315,LCD_BLACK);
		Draw_Rect(5+op1,185,39+op1,315,LCD_GREEN);
	}
	
	if((85<X0&&X0<115)&&(193<Y0&&Y0<300))
	{	
		Delay_ms(50);
		op1=80;
		opa11=0;opa1=0;opa0=0;opa3=0;opa4=0;opa5=0;opa6=0;opa7=0;opa8=0;opa9=0;
		opa2++;
		if(opa2>=3){ op3=3;op4=1;}
		Draw_Rect(5+0,10,39+0,155,LCD_BLACK);
		Draw_Rect(5+40,10,39+40,155,LCD_BLACK);
		Draw_Rect(5+80,10,39+80,155,LCD_BLACK);
		Draw_Rect(5+120,10,39+120,155,LCD_BLACK);
		Draw_Rect(5+160,10,39+160,155,LCD_BLACK);
		Draw_Rect(5+0,185,39+0,315,LCD_BLACK);
		Draw_Rect(5+40,185,39+40,315,LCD_BLACK);
		Draw_Rect(5+120,185,39+120,315,LCD_BLACK);
		Draw_Rect(5+160,185,39+160,315,LCD_BLACK);
		Draw_Rect(5+200,185,39+200,315,LCD_BLACK);
		Draw_Rect(5+op1,185,39+op1,315,LCD_GREEN);
	}
	
	if((125<X0&&X0<155)&&(193<Y0&&Y0<300))
	{
		Delay_ms(50);
		op1=120;
		opa11=0;opa1=0;opa2=0;opa0=0;opa4=0;opa5=0;opa6=0;opa7=0;opa8=0;opa9=0;
		opa3++;
		if(opa3>=3){ op3=4;op4=1;}
		Draw_Rect(5+0,10,39+0,155,LCD_BLACK);
		Draw_Rect(5+40,10,39+40,155,LCD_BLACK);
		Draw_Rect(5+80,10,39+80,155,LCD_BLACK);
		Draw_Rect(5+120,10,39+120,155,LCD_BLACK);
		Draw_Rect(5+160,10,39+160,155,LCD_BLACK);
		Draw_Rect(5+0,185,39+0,315,LCD_BLACK);
		Draw_Rect(5+40,185,39+40,315,LCD_BLACK);
		Draw_Rect(5+80,185,39+80,315,LCD_BLACK);
		Draw_Rect(5+160,185,39+160,315,LCD_BLACK);
		Draw_Rect(5+200,185,39+200,315,LCD_BLACK);
		Draw_Rect(5+op1,185,39+op1,315,LCD_GREEN);
	}
	if((165<X0&&X0<195)&&(193<Y0&&Y0<300))
	{
		Delay_ms(50);
		op1=160;
		opa11=0;opa1=0;opa2=0;opa3=0;opa0=0;opa5=0;opa6=0;opa7=0;opa8=0;opa9=0;
		opa4++;
		if(opa4>=3) {op3=5;op4=1;}
		Draw_Rect(5+0,10,39+0,155,LCD_BLACK);
		Draw_Rect(5+40,10,39+40,155,LCD_BLACK);
		Draw_Rect(5+80,10,39+80,155,LCD_BLACK);
		Draw_Rect(5+120,10,39+120,155,LCD_BLACK);
		Draw_Rect(5+160,10,39+160,155,LCD_BLACK);
		Draw_Rect(5+0,185,39+0,315,LCD_BLACK);
		Draw_Rect(5+40,185,39+40,315,LCD_BLACK);
		Draw_Rect(5+80,185,39+80,315,LCD_BLACK);
		Draw_Rect(5+120,185,39+120,315,LCD_BLACK);
		Draw_Rect(5+160,185,39+160,315,LCD_BLACK);
		Draw_Rect(5+200,185,39+200,315,LCD_BLACK);
		Draw_Rect(5+op1,185,39+op1,315,LCD_GREEN);
	}	
	
	if((205<X0&&X0<225)&&(193<Y0&&Y0<300))
	{
		Delay_ms(50);
		op1=200;
		opa1=0;opa2=0;opa3=0;opa0=0;opa5=0;opa6=0;opa7=0;opa8=0;opa9=0;
		opa11++;
		if(opa11>3) {op3=11;op4=1;}
		Draw_Rect(5+0,10,39+0,155,LCD_BLACK);
		Draw_Rect(5+40,10,39+40,155,LCD_BLACK);
		Draw_Rect(5+80,10,39+80,155,LCD_BLACK);
		Draw_Rect(5+120,10,39+120,155,LCD_BLACK);
		Draw_Rect(5+160,10,39+160,155,LCD_BLACK);
		Draw_Rect(5+0,185,39+0,315,LCD_BLACK);
		Draw_Rect(5+40,185,39+40,315,LCD_BLACK);
		Draw_Rect(5+80,185,39+80,315,LCD_BLACK);
		Draw_Rect(5+120,185,39+120,315,LCD_BLACK);
		Draw_Rect(5+160,185,39+160,315,LCD_BLACK);
		Draw_Rect(5+op1,185,39+op1,315,LCD_GREEN);
	}	
	
	
	//////////////////////////////////////////////
	if((10<X0&&X0<39)&&(20<Y0&&Y0<150))
	{
		Delay_ms(50);
		op1=0;
		opa11=0;opa1=0;opa2=0;opa3=0;opa4=0;opa0=0;opa6=0;opa7=0;opa8=0;opa9=0;
		opa5++;
		if(opa5>=3) {op3=6;op4=1;}
		Draw_Rect(5+0,185,39+0,315,LCD_BLACK);
		Draw_Rect(5+40,185,39+40,315,LCD_BLACK);
		Draw_Rect(5+80,185,39+80,315,LCD_BLACK);
		Draw_Rect(5+120,185,39+120,315,LCD_BLACK);
		Draw_Rect(5+160,185,39+160,315,LCD_BLACK);
		Draw_Rect(5+40,10,39+40,155,LCD_BLACK);
		Draw_Rect(5+80,10,39+80,155,LCD_BLACK);
		Draw_Rect(5+120,10,39+120,155,LCD_BLACK);
		Draw_Rect(5+160,10,39+160,155,LCD_BLACK);
		Draw_Rect(5+200,185,39+200,315,LCD_BLACK);
		Draw_Rect(5+op1,10,39+op1,155,LCD_GREEN);
	}
	
	if((45<X0&&X0<75)&&(20<Y0&&Y0<150))
	{
		Delay_ms(50);
		op1=40;
		opa11=0;opa1=0;opa2=0;opa3=0;opa4=0;opa5=0;opa0=0;opa7=0;opa8=0;opa9=0;
		opa6++;
		if(opa6>=3){ op3=7;op4=1;}
		Draw_Rect(5+0,185,39+0,315,LCD_BLACK);
		Draw_Rect(5+40,185,39+40,315,LCD_BLACK);
		Draw_Rect(5+80,185,39+80,315,LCD_BLACK);
		Draw_Rect(5+120,185,39+120,315,LCD_BLACK);
		Draw_Rect(5+160,185,39+160,315,LCD_BLACK);
		Draw_Rect(5+0,10,39+0,155,LCD_BLACK);
		Draw_Rect(5+80,10,39+80,155,LCD_BLACK);
		Draw_Rect(5+120,10,39+120,155,LCD_BLACK);
		Draw_Rect(5+160,10,39+160,155,LCD_BLACK);
		Draw_Rect(5+200,185,39+200,315,LCD_BLACK);
		Draw_Rect(5+op1,10,39+op1,155,LCD_GREEN);
	}
	
	if((85<X0&&X0<115)&&(20<Y0&&Y0<150))
	{	
		Delay_ms(50);
		op1=80;
		opa11=0;opa1=0;opa2=0;opa3=0;opa4=0;opa5=0;opa6=0;opa0=0;opa8=0;opa9=0;
		opa7++;
		if(opa7>=3){ op3=8;op4=1;}
		Draw_Rect(5+0,185,39+0,315,LCD_BLACK);
		Draw_Rect(5+40,185,39+40,315,LCD_BLACK);
		Draw_Rect(5+80,185,39+80,315,LCD_BLACK);
		Draw_Rect(5+120,185,39+120,315,LCD_BLACK);
		Draw_Rect(5+160,185,39+160,315,LCD_BLACK);
		Draw_Rect(5+0,10,39+0,155,LCD_BLACK);
		Draw_Rect(5+40,10,39+40,155,LCD_BLACK);
		Draw_Rect(5+120,10,39+120,155,LCD_BLACK);
		Draw_Rect(5+160,10,39+160,155,LCD_BLACK);
		Draw_Rect(5+200,185,39+200,315,LCD_BLACK);
		Draw_Rect(5+op1,10,39+op1,155,LCD_GREEN);
	}
	
	if((125<X0&&X0<155)&&(20<Y0&&Y0<150))
	{
		Delay_ms(50);
		op1=120;
		opa11=0;opa1=0;opa2=0;opa3=0;opa4=0;opa5=0;opa6=0;opa7=0;opa0=0;opa9=0;
		opa8++;
		if(opa8>=3) {op3=9;op4=1;}
		Draw_Rect(5+0,185,39+0,315,LCD_BLACK);
		Draw_Rect(5+40,185,39+40,315,LCD_BLACK);
		Draw_Rect(5+80,185,39+80,315,LCD_BLACK);
		Draw_Rect(5+120,185,39+120,315,LCD_BLACK);
		Draw_Rect(5+160,185,39+160,315,LCD_BLACK);
		Draw_Rect(5+0,10,39+0,155,LCD_BLACK);
		Draw_Rect(5+40,10,39+40,155,LCD_BLACK);
		Draw_Rect(5+80,10,39+80,155,LCD_BLACK);
		Draw_Rect(5+160,10,39+160,155,LCD_BLACK);
		Draw_Rect(5+200,185,39+200,315,LCD_BLACK);
		Draw_Rect(5+op1,10,39+op1,155,LCD_GREEN);
	}
	if((165<X0&&X0<195)&&(20<Y0&&Y0<150))
	{
		Delay_ms(50);
		op1=160;
		opa11=0;opa1=0;opa2=0;opa3=0;opa4=0;opa5=0;opa6=0;opa7=0;opa8=0;opa0=0;
		opa9++;
		if(opa9>=3){ op3=10;op4=1;}
		Draw_Rect(5+0,185,39+0,315,LCD_BLACK);
		Draw_Rect(5+40,185,39+40,315,LCD_BLACK);
		Draw_Rect(5+80,185,39+80,315,LCD_BLACK);
		Draw_Rect(5+120,185,39+120,315,LCD_BLACK);
		Draw_Rect(5+160,185,39+160,315,LCD_BLACK);
		Draw_Rect(5+0,10,39+0,155,LCD_BLACK);
		Draw_Rect(5+40,10,39+40,155,LCD_BLACK);
		Draw_Rect(5+80,10,39+80,155,LCD_BLACK);
		Draw_Rect(5+120,10,39+120,155,LCD_BLACK);
		Draw_Rect(5+200,185,39+200,315,LCD_BLACK);
		Draw_Rect(5+op1,10,39+op1,155,LCD_GREEN);
	}	
	Set_Font(&Font16x24);
	Display_String(10, 310,"Scale", LCD_WHITE);
	Display_String(50, 310,"Pain", LCD_WHITE);
	Display_String(90, 310,"Album", LCD_WHITE);
	Display_String(130, 310,"Demo", LCD_WHITE);
	Display_String(170, 310,"Cal", LCD_WHITE);
	Display_String(210, 310,"Uart", LCD_WHITE);
	
	Display_String(10, 150,"Bright", LCD_WHITE);
	Display_String(50, 150,"PID", LCD_WHITE);
	Display_String(90, 150,"3-Axis", LCD_WHITE);
	Display_String(130, 150,"CaliTouch", LCD_WHITE);
	Display_String(170, 150,"OSC", LCD_WHITE);
	while(op4)
	{
		switch(op3)
		{
			case 0:
			{
									icr1=0;icr2=0;icr3=0;icr4=0;icr5=0;
									dieuchinhXY();
									if((10<X0&&X0<39)&&(193<Y0&&Y0<300))
									{
										Delay_ms(50);
										op1=0;
										opa11=0;opa1=0;opa2=0;opa3=0;opa4=0;opa5=0;opa6=0;opa7=0;opa8=0;opa9=0;
										opa0++;
										if(opa0>=3) {op3=1;op4=1;}
										Draw_Rect(5+0,10,39+0,155,LCD_BLACK);
										Draw_Rect(5+40,10,39+40,155,LCD_BLACK);
										Draw_Rect(5+80,10,39+80,155,LCD_BLACK);
										Draw_Rect(5+120,10,39+120,155,LCD_BLACK);
										Draw_Rect(5+160,10,39+160,155,LCD_BLACK);
										Draw_Rect(5+40,185,39+40,315,LCD_BLACK);
										Draw_Rect(5+80,185,39+80,315,LCD_BLACK);
										Draw_Rect(5+120,185,39+120,315,LCD_BLACK);
										Draw_Rect(5+160,185,39+160,315,LCD_BLACK);
										Draw_Rect(5+200,185,39+200,315,LCD_BLACK);
										Draw_Rect(5+op1,185,39+op1,315,LCD_GREEN);
									}
									
									if((45<X0&&X0<75)&&(193<Y0&&Y0<300))
									{
										Delay_ms(50);
										op1=40;
										opa11=0;opa0=0;opa2=0;opa3=0;opa4=0;opa5=0;opa6=0;opa7=0;opa8=0;opa9=0;
										opa1++;
										if(opa1>=3) {op3=2;op4=1;}
										Draw_Rect(5+0,10,39+0,155,LCD_BLACK);
										Draw_Rect(5+40,10,39+40,155,LCD_BLACK);
										Draw_Rect(5+80,10,39+80,155,LCD_BLACK);
										Draw_Rect(5+120,10,39+120,155,LCD_BLACK);
										Draw_Rect(5+160,10,39+160,155,LCD_BLACK);
										Draw_Rect(5+0,185,39+0,315,LCD_BLACK);
										Draw_Rect(5+80,185,39+80,315,LCD_BLACK);
										Draw_Rect(5+120,185,39+120,315,LCD_BLACK);
										Draw_Rect(5+160,185,39+160,315,LCD_BLACK);
										Draw_Rect(5+200,185,39+200,315,LCD_BLACK);
										Draw_Rect(5+op1,185,39+op1,315,LCD_GREEN);
									}
									
									if((85<X0&&X0<115)&&(193<Y0&&Y0<300))
									{	
										Delay_ms(50);
										op1=80;
										opa11=0;opa1=0;opa0=0;opa3=0;opa4=0;opa5=0;opa6=0;opa7=0;opa8=0;opa9=0;
										opa2++;
										if(opa2>=3){ op3=3;op4=1;}
										Draw_Rect(5+0,10,39+0,155,LCD_BLACK);
										Draw_Rect(5+40,10,39+40,155,LCD_BLACK);
										Draw_Rect(5+80,10,39+80,155,LCD_BLACK);
										Draw_Rect(5+120,10,39+120,155,LCD_BLACK);
										Draw_Rect(5+160,10,39+160,155,LCD_BLACK);
										Draw_Rect(5+0,185,39+0,315,LCD_BLACK);
										Draw_Rect(5+40,185,39+40,315,LCD_BLACK);
										Draw_Rect(5+120,185,39+120,315,LCD_BLACK);
										Draw_Rect(5+160,185,39+160,315,LCD_BLACK);
										Draw_Rect(5+200,185,39+200,315,LCD_BLACK);
										Draw_Rect(5+op1,185,39+op1,315,LCD_GREEN);
									}
									
									if((125<X0&&X0<155)&&(193<Y0&&Y0<300))
									{
										Delay_ms(50);
										op1=120;
										opa11=0;opa1=0;opa2=0;opa0=0;opa4=0;opa5=0;opa6=0;opa7=0;opa8=0;opa9=0;
										opa3++;
										if(opa3>=3){ op3=4;op4=1;}
										Draw_Rect(5+0,10,39+0,155,LCD_BLACK);
										Draw_Rect(5+40,10,39+40,155,LCD_BLACK);
										Draw_Rect(5+80,10,39+80,155,LCD_BLACK);
										Draw_Rect(5+120,10,39+120,155,LCD_BLACK);
										Draw_Rect(5+160,10,39+160,155,LCD_BLACK);
										Draw_Rect(5+0,185,39+0,315,LCD_BLACK);
										Draw_Rect(5+40,185,39+40,315,LCD_BLACK);
										Draw_Rect(5+80,185,39+80,315,LCD_BLACK);
										Draw_Rect(5+160,185,39+160,315,LCD_BLACK);
										Draw_Rect(5+200,185,39+200,315,LCD_BLACK);
										Draw_Rect(5+op1,185,39+op1,315,LCD_GREEN);
									}
									if((165<X0&&X0<195)&&(193<Y0&&Y0<300))
									{
										Delay_ms(50);
										op1=160;
										opa11=0;opa1=0;opa2=0;opa3=0;opa0=0;opa5=0;opa6=0;opa7=0;opa8=0;opa9=0;
										opa4++;
										if(opa4>=3) {op3=5;op4=1;}
										Draw_Rect(5+0,10,39+0,155,LCD_BLACK);
										Draw_Rect(5+40,10,39+40,155,LCD_BLACK);
										Draw_Rect(5+80,10,39+80,155,LCD_BLACK);
										Draw_Rect(5+120,10,39+120,155,LCD_BLACK);
										Draw_Rect(5+160,10,39+160,155,LCD_BLACK);
										Draw_Rect(5+0,185,39+0,315,LCD_BLACK);
										Draw_Rect(5+40,185,39+40,315,LCD_BLACK);
										Draw_Rect(5+80,185,39+80,315,LCD_BLACK);
										Draw_Rect(5+120,185,39+120,315,LCD_BLACK);
										Draw_Rect(5+160,185,39+160,315,LCD_BLACK);
										Draw_Rect(5+200,185,39+200,315,LCD_BLACK);
										Draw_Rect(5+op1,185,39+op1,315,LCD_GREEN);
									}	
									
									if((205<X0&&X0<225)&&(193<Y0&&Y0<300))
									{
										Delay_ms(50);
										op1=200;
										opa1=0;opa2=0;opa3=0;opa0=0;opa5=0;opa6=0;opa7=0;opa8=0;opa9=0;
										opa11++;
										if(opa11>3) {op3=11;op4=1;}
										Draw_Rect(5+0,10,39+0,155,LCD_BLACK);
										Draw_Rect(5+40,10,39+40,155,LCD_BLACK);
										Draw_Rect(5+80,10,39+80,155,LCD_BLACK);
										Draw_Rect(5+120,10,39+120,155,LCD_BLACK);
										Draw_Rect(5+160,10,39+160,155,LCD_BLACK);
										Draw_Rect(5+0,185,39+0,315,LCD_BLACK);
										Draw_Rect(5+40,185,39+40,315,LCD_BLACK);
										Draw_Rect(5+80,185,39+80,315,LCD_BLACK);
										Draw_Rect(5+120,185,39+120,315,LCD_BLACK);
										Draw_Rect(5+160,185,39+160,315,LCD_BLACK);
										Draw_Rect(5+op1,185,39+op1,315,LCD_GREEN);
									}	
									
									
									//////////////////////////////////////////////
									if((10<X0&&X0<39)&&(20<Y0&&Y0<150))
									{
										Delay_ms(50);
										op1=0;
										opa11=0;opa1=0;opa2=0;opa3=0;opa4=0;opa0=0;opa6=0;opa7=0;opa8=0;opa9=0;
										opa5++;
										if(opa5>=3) {op3=6;op4=1;}
										Draw_Rect(5+0,185,39+0,315,LCD_BLACK);
										Draw_Rect(5+40,185,39+40,315,LCD_BLACK);
										Draw_Rect(5+80,185,39+80,315,LCD_BLACK);
										Draw_Rect(5+120,185,39+120,315,LCD_BLACK);
										Draw_Rect(5+160,185,39+160,315,LCD_BLACK);
										Draw_Rect(5+40,10,39+40,155,LCD_BLACK);
										Draw_Rect(5+80,10,39+80,155,LCD_BLACK);
										Draw_Rect(5+120,10,39+120,155,LCD_BLACK);
										Draw_Rect(5+160,10,39+160,155,LCD_BLACK);
										Draw_Rect(5+200,185,39+200,315,LCD_BLACK);
										Draw_Rect(5+op1,10,39+op1,155,LCD_GREEN);
									}
									
									if((45<X0&&X0<75)&&(20<Y0&&Y0<150))
									{
										Delay_ms(50);
										op1=40;
										opa11=0;opa1=0;opa2=0;opa3=0;opa4=0;opa5=0;opa0=0;opa7=0;opa8=0;opa9=0;
										opa6++;
										if(opa6>=3){ op3=7;op4=1;}
										Draw_Rect(5+0,185,39+0,315,LCD_BLACK);
										Draw_Rect(5+40,185,39+40,315,LCD_BLACK);
										Draw_Rect(5+80,185,39+80,315,LCD_BLACK);
										Draw_Rect(5+120,185,39+120,315,LCD_BLACK);
										Draw_Rect(5+160,185,39+160,315,LCD_BLACK);
										Draw_Rect(5+0,10,39+0,155,LCD_BLACK);
										Draw_Rect(5+80,10,39+80,155,LCD_BLACK);
										Draw_Rect(5+120,10,39+120,155,LCD_BLACK);
										Draw_Rect(5+160,10,39+160,155,LCD_BLACK);
										Draw_Rect(5+200,185,39+200,315,LCD_BLACK);
										Draw_Rect(5+op1,10,39+op1,155,LCD_GREEN);
									}
									
									if((85<X0&&X0<115)&&(20<Y0&&Y0<150))
									{	
										Delay_ms(50);
										op1=80;
										opa11=0;opa1=0;opa2=0;opa3=0;opa4=0;opa5=0;opa6=0;opa0=0;opa8=0;opa9=0;
										opa7++;
										if(opa7>=3){ op3=8;op4=1;}
										Draw_Rect(5+0,185,39+0,315,LCD_BLACK);
										Draw_Rect(5+40,185,39+40,315,LCD_BLACK);
										Draw_Rect(5+80,185,39+80,315,LCD_BLACK);
										Draw_Rect(5+120,185,39+120,315,LCD_BLACK);
										Draw_Rect(5+160,185,39+160,315,LCD_BLACK);
										Draw_Rect(5+0,10,39+0,155,LCD_BLACK);
										Draw_Rect(5+40,10,39+40,155,LCD_BLACK);
										Draw_Rect(5+120,10,39+120,155,LCD_BLACK);
										Draw_Rect(5+160,10,39+160,155,LCD_BLACK);
										Draw_Rect(5+200,185,39+200,315,LCD_BLACK);
										Draw_Rect(5+op1,10,39+op1,155,LCD_GREEN);
									}
									
									if((125<X0&&X0<155)&&(20<Y0&&Y0<150))
									{
										Delay_ms(50);
										op1=120;
										opa11=0;opa1=0;opa2=0;opa3=0;opa4=0;opa5=0;opa6=0;opa7=0;opa0=0;opa9=0;
										opa8++;
										if(opa8>=3) {op3=9;op4=1;}
										Draw_Rect(5+0,185,39+0,315,LCD_BLACK);
										Draw_Rect(5+40,185,39+40,315,LCD_BLACK);
										Draw_Rect(5+80,185,39+80,315,LCD_BLACK);
										Draw_Rect(5+120,185,39+120,315,LCD_BLACK);
										Draw_Rect(5+160,185,39+160,315,LCD_BLACK);
										Draw_Rect(5+0,10,39+0,155,LCD_BLACK);
										Draw_Rect(5+40,10,39+40,155,LCD_BLACK);
										Draw_Rect(5+80,10,39+80,155,LCD_BLACK);
										Draw_Rect(5+160,10,39+160,155,LCD_BLACK);
										Draw_Rect(5+200,185,39+200,315,LCD_BLACK);
										Draw_Rect(5+op1,10,39+op1,155,LCD_GREEN);
									}
									if((165<X0&&X0<195)&&(20<Y0&&Y0<150))
									{
										Delay_ms(50);
										op1=160;
										opa11=0;opa1=0;opa2=0;opa3=0;opa4=0;opa5=0;opa6=0;opa7=0;opa8=0;opa0=0;
										opa9++;
										if(opa9>=3){ op3=10;op4=1;}
										Draw_Rect(5+0,185,39+0,315,LCD_BLACK);
										Draw_Rect(5+40,185,39+40,315,LCD_BLACK);
										Draw_Rect(5+80,185,39+80,315,LCD_BLACK);
										Draw_Rect(5+120,185,39+120,315,LCD_BLACK);
										Draw_Rect(5+160,185,39+160,315,LCD_BLACK);
										Draw_Rect(5+0,10,39+0,155,LCD_BLACK);
										Draw_Rect(5+40,10,39+40,155,LCD_BLACK);
										Draw_Rect(5+80,10,39+80,155,LCD_BLACK);
										Draw_Rect(5+120,10,39+120,155,LCD_BLACK);
										Draw_Rect(5+200,185,39+200,315,LCD_BLACK);
										Draw_Rect(5+op1,10,39+op1,155,LCD_GREEN);
									}	
									Set_Font(&Font16x24);
									Display_String(10, 310,"Scale", LCD_WHITE);
									Display_String(50, 310,"Pain", LCD_WHITE);
									Display_String(90, 310,"Album", LCD_WHITE);
									Display_String(130, 310,"Demo", LCD_WHITE);
									Display_String(170, 310,"Cal", LCD_WHITE);
									Display_String(210, 310,"Uart", LCD_WHITE);
									
									Display_String(10, 150,"Bright", LCD_WHITE);
									Display_String(50, 150,"PID", LCD_WHITE);
									Display_String(90, 150,"3-Axis", LCD_WHITE);
									Display_String(130, 150,"CaliTouch", LCD_WHITE);
									Display_String(170, 150,"OSC", LCD_WHITE);
			}break;
			case 1:
			{
					Clear_Screen(0x0000);
				  scaleanalog();
					Clear_Screen(0x0000);
			}
			break;
			case 2:
			{
				Draw_Full_Rect(0, 0 ,240 ,320, LCD_PINK);
				Clear_Screen(0x0000);
				paa=1;
				while(paa)
				{
					paint();
				}
				op3=0;
				Clear_Screen(0x0000);
			}
			break;
			case 3:
			{
				updateXY();
				/*if((Pen_Point.X0 >50&&Pen_Point.X0 <200)&&(Pen_Point.Y0 >50&&Pen_Point.Y0 <280))
				{
					Delay_ms(80);
					doi++;
					if(doi>5) doi=0;
					Pen_Point.X=0;
					Pen_Point.Y=0;
				}*/
				album();
			}
			break;
			case 4:
			{
				Clear_Screen(0x0000);
				Random_Lines();
				Clear_Screen(0x0000);
				Random_Rect();
				Clear_Screen(0x0000);
				Random_Circle();
				Clear_Screen(0x0000);
			}
			break;
			case 5:
			{
				Clear_Screen(0x0000);
				Draw_Full_Rect(0, 0 ,240 ,320, LCD_LIGH_BLUE);
				maytinh();
				ca=1;
				ic=1;
				while(ca)
				{
					maytinh1();
				}
				op3=0;
				Clear_Screen(0x0000);
			}
			break;
			case 6:
			{
				Clear_Screen(0x0000);
				brightness();
			}
			break;
			case 7:
			{
				Clear_Screen(0x0000);
				PID();
				op3=0;
				Clear_Screen(0x0000);
			}
			break;
			case 8:
			{
				Clear_Screen(0x0000);
				ax=1;
				Axis();
				op3=0;
				Clear_Screen(0x0000);
			}
			break;
			case 9:
			{
				Clear_Screen(0x0000);
				calibration();
				op3=0;
			}
			break;
			case 10:
			{
				Clear_Screen(0x0000);
				Delay_ms(50);
				Draw_Rect(0,0,240,320,LCD_BLACK);
				Delay_ms(50);
				Draw_Full_Rect(2,5,29,315,LCD_LIGH_BLUE);
				Draw_Full_Rect(192,5,238,315,LCD_LIGH_BLUE);
				Draw_Full_Rect(215,210,235,310,LCD_BLACK);
				Draw_Full_Rect(215,105,235,205,LCD_BLACK);
				Delay_ms(50);
				Draw_Rect(215,210,235,310,LCD_WHITE);
				Draw_Rect(215,105,235,205,LCD_WHITE);
				Delay_ms(50);
				oscillocope();
				op3=0;
				Clear_Screen(0x0000);
			}
			break;
			case 11:
			{
				Clear_Screen(0x0000);
				uart();
				Clear_Screen(0x0000);
				op3=0;
			}
			break;
		}
	}
	
}

void menu(void)
{
	char numbr[10];
	uint8_t b0=0,b1=0,b2=0,tv=0,tv1=0;
	uint16_t color1,color2,color3,color4,color5,color6,ro=310;
	uint8_t se1=0,se2=0,se3=0,se4=0,se5=0,se6=0,se7=0,se8=0,se9=0,se10=0,se11=0;
	Draw_Full_Rect(0,0,240,320,LCD_GREEN);
	Draw_Full_Rect(30,30,230,310,LCD_RED);
	Draw_Rect(29,29,231,311,LCD_WHITE);
	Draw_Rect(30,30,230,310,LCD_BLACK);
	Draw_Full_Rect(50,5,210,25,LCD_RED);
	Draw_Rect(50,5,210,25,LCD_BLACK);
	Draw_Rect(49,4,211,26,LCD_WHITE);
	ic=1;
	b0=53;
	b2=0;
	tv=0;
	b1=35;
	op3=0;
	op4=1;
	while(op4)
	{
		Set_Font(&Font16x24);
		//Display_String(5, ro+1,"MENU", LCD_RED);
		Display_String(5, 200,"MENU", LCD_RED);
		
		Draw_Rect(29,29,231,311,LCD_WHITE);
		Draw_Rect(30,30,230,310,LCD_BLACK);
		//ro--;
	/*	if(ro==60)
		{
			Display_String(5, ro+1,"MENU", LCD_RED);
			ro=310;
		}*/
		dieuchinhXY();
		if((55<X0&&X0<195)&&(5<Y0&&Y0<30))
		{
			b0=X0;
			tv=map(b0,57,190,0,5);
			if(tv!=tv1)
			{
				Draw_Full_Rect(30,30,230,310,LCD_RED);
				b2=0;
				b1=35;
			}
		}
		if((35<X0&&X0<60)&&(50<Y0&&Y0<300))
		{
			b1=35;
			if(tv==0)
			{
				se1++;
				se2=0;se3=0;se4=0;se5=0;se6=0;se7=0;se8=0;se9=0;se10=0;se11=0;
				if(se1==3)
				{
					op3=1;
				}
			}
			if(tv==1)
			{
				se2++;
				se1=0;se3=0;se4=0;se5=0;se6=0;se7=0;se8=0;se9=0;se10=0;se11=0;
				if(se2==3)
				{
					op3=2;
				}
			}
			if(tv==2)
			{
				se3++;
				se1=0;se2=0;se4=0;se5=0;se6=0;se7=0;se8=0;se9=0;se10=0;se11=0;
				if(se3==3)
				{
					op3=3;
				}
			}
			if(tv==3)
			{
				se4++;
				se1=0;se2=0;se3=0;se5=0;se6=0;se7=0;se8=0;se9=0;se10=0;se11=0;
				if(se4==3)
				{
					op3=4;
				}
			}
			if(tv==4)
			{
				se5++;
				se1=0;se2=0;se3=0;se4=0;se6=0;se7=0;se8=0;se9=0;se10=0;se11=0;
				if(se5==3)
				{
					op3=5;
				}
			}
			if(tv==5)
			{
				se6++;
				se1=0;se2=0;se3=0;se4=0;se5=0;se7=0;se8=0;se9=0;se10=0;se11=0;
				if(se6==3)
				{
					op3=6;
				}
			}
		}
		if((65<X0&&X0<90)&&(50<Y0&&Y0<300))
		{
			b1=65;
			if(tv==0)
			{
				se2++;
				se1=0;se3=0;se4=0;se5=0;se6=0;se7=0;se8=0;se9=0;se10=0;se11=0;
				if(se2==3)
				{
					op3=2;
				}
			}
			if(tv==1)
			{
				se3++;
				se1=0;se2=0;se4=0;se5=0;se6=0;se7=0;se8=0;se9=0;se10=0;se11=0;
				if(se3==3)
				{
					op3=3;
				}
			}
			if(tv==2)
			{
				se4++;
				se1=0;se2=0;se3=0;se5=0;se6=0;se7=0;se8=0;se9=0;se10=0;se11=0;
				if(se4==3)
				{
					op3=4;
				}
			}
			if(tv==3)
			{
				se5++;
				se1=0;se2=0;se3=0;se4=0;se6=0;se7=0;se8=0;se9=0;se10=0;se11=0;
				if(se5==3)
				{
					op3=5;
				}
			}
			if(tv==4)
			{
				se6++;
				se1=0;se2=0;se3=0;se4=0;se5=0;se7=0;se8=0;se9=0;se10=0;se11=0;
				if(se6==3)
				{
					op3=6;
				}
			}
			if(tv==5)
			{
				se7++;
				se1=0;se2=0;se3=0;se4=0;se5=0;se6=0;se8=0;se9=0;se10=0;se11=0;
				if(se7==3)
				{
					op3=7;
				}
			}
		}
		if((95<X0&&X0<120)&&(50<Y0&&Y0<300))
		{
			b1=95;
			if(tv==0)
			{
				se3++;
				se1=0;se2=0;se4=0;se5=0;se6=0;se7=0;se8=0;se9=0;se10=0;se11=0;
				if(se3==3)
				{
					op3=3;
				}
			}
			if(tv==1)
			{
				se4++;
				se1=0;se2=0;se3=0;se5=0;se6=0;se7=0;se8=0;se9=0;se10=0;se11=0;
				if(se4==3)
				{
					op3=4;
				}
			}
			if(tv==2)
			{
				se5++;
				se1=0;se2=0;se3=0;se4=0;se6=0;se7=0;se8=0;se9=0;se10=0;se11=0;
				if(se5==3)
				{
					op3=5;
				}
			}
			if(tv==3)
			{
				se6++;
				se1=0;se2=0;se3=0;se4=0;se5=0;se7=0;se8=0;se9=0;se10=0;se11=0;
				if(se6==3)
				{
					op3=6;
				}
			}
			if(tv==4)
			{
				se7++;
				se1=0;se2=0;se3=0;se4=0;se5=0;se6=0;se8=0;se9=0;se10=0;se11=0;
				if(se7==3)
				{
					op3=7;
				}
			}
			if(tv==5)
			{
				se8++;
				se1=0;se2=0;se3=0;se4=0;se5=0;se6=0;se7=0;se9=0;se10=0;se11=0;
				if(se8==3)
				{
					op3=8;
				}
			}
		}
		if((125<X0&&X0<150)&&(50<Y0&&Y0<300))
		{
			b1=125;
			if(tv==0)
			{
				se4++;
				se1=0;se2=0;se3=0;se5=0;se6=0;se7=0;se8=0;se9=0;se10=0;se11=0;
				if(se4==3)
				{
					op3=4;
				}
			}
			if(tv==1)
			{
				se5++;
				se1=0;se2=0;se3=0;se4=0;se6=0;se7=0;se8=0;se9=0;se10=0;se11=0;
				if(se5==3)
				{
					op3=5;
				}
			}
			if(tv==2)
			{
				se6++;
				se1=0;se2=0;se3=0;se4=0;se5=0;se7=0;se8=0;se9=0;se10=0;se11=0;
				if(se6==3)
				{
					op3=6;
				}
			}
			if(tv==3)
			{
				se7++;
				se1=0;se2=0;se3=0;se4=0;se5=0;se6=0;se8=0;se9=0;se10=0;se11=0;
				if(se7==3)
				{
					op3=7;
				}
			}
			if(tv==4)
			{
				se8++;
				se1=0;se2=0;se3=0;se4=0;se5=0;se6=0;se7=0;se9=0;se10=0;se11=0;
				if(se8==3)
				{
					op3=8;
				}
			}
			if(tv==5)
			{
				se9++;
				se1=0;se2=0;se3=0;se4=0;se5=0;se6=0;se7=0;se8=0;se10=0;se11=0;
				if(se9==3)
				{
					op3=9;
				}
			}
		}
		if((155<X0&&X0<180)&&(50<Y0&&Y0<300))
		{
			b1=155;
			if(tv==0)
			{
				se5++;
				se1=0;se2=0;se3=0;se4=0;se6=0;se7=0;se8=0;se9=0;se10=0;se11=0;
				if(se5==3)
				{
					op3=5;
				}
			}
			if(tv==1)
			{
				se6++;
				se1=0;se2=0;se3=0;se4=0;se5=0;se7=0;se8=0;se9=0;se10=0;se11=0;
				if(se6==3)
				{
					op3=6;
				}
			}
			if(tv==2)
			{
				se7++;
				se1=0;se2=0;se3=0;se4=0;se5=0;se6=0;se8=0;se9=0;se10=0;se11=0;
				if(se7==3)
				{
					op3=7;
				}
			}
			if(tv==3)
			{
				se8++;
				se1=0;se2=0;se3=0;se4=0;se5=0;se6=0;se7=0;se9=0;se10=0;se11=0;
				if(se8==3)
				{
					op3=8;
				}
			}
			if(tv==4)
			{
				se9++;
				se1=0;se2=0;se3=0;se4=0;se5=0;se6=0;se7=0;se8=0;se10=0;se11=0;
				if(se9==3)
				{
					op3=9;
				}
			}
			if(tv==5)
			{
				se10++;
				se1=0;se2=0;se3=0;se4=0;se5=0;se6=0;se7=0;se8=0;se9=0;se11=0;
				if(se10==3)
				{
					op3=10;
				}
			}
		}
		if((185<X0&&X0<210)&&(50<Y0&&Y0<300))
		{
			b1=185;
			if(tv==0)
			{
				se6++;
				se1=0;se2=0;se3=0;se4=0;se5=0;se7=0;se8=0;se9=0;se10=0;se11=0;
				if(se6==3)
				{
					op3=6;
				}
			}
			if(tv==1)
			{
				se7++;
				se1=0;se2=0;se3=0;se4=0;se5=0;se6=0;se8=0;se9=0;se10=0;se11=0;
				if(se7==3)
				{
					op3=7;
				}
			}
			if(tv==2)
			{
				se8++;
				se1=0;se2=0;se3=0;se4=0;se5=0;se6=0;se7=0;se9=0;se10=0;se11=0;
				if(se8==3)
				{
					op3=8;
				}
			}
			if(tv==3)
			{
				se9++;
				se1=0;se2=0;se3=0;se4=0;se5=0;se6=0;se7=0;se8=0;se10=0;se11=0;
				if(se9==3)
				{
					op3=9;
				}
			}
			if(tv==4)
			{
				se10++;
				se1=0;se2=0;se3=0;se4=0;se5=0;se6=0;se7=0;se8=0;se9=0;se11=0;
				if(se10==3)
				{
					op3=10;
				}
			}
			if(tv==5)
			{
				se11++;
				se1=0;se2=0;se3=0;se4=0;se5=0;se6=0;se7=0;se8=0;se9=0;se10=0;
				if(se11==3)
				{
					op3=11;
				}
			}
			
		}
		
		icon(30,5,45,25,LCD_RED,ic,1); 
		icon(215,5,230,25,LCD_RED,ic,2); 
		Set_Font(&Font12x12);
		Display_String(32, 20,"+", LCD_WHITE);
		Display_String(215, 20,"-", LCD_WHITE);
		ic=0;
		tv1=tv;
		Draw_Full_Rect(b0,7,b0+15,23,LCD_GREEN);
		Draw_Full_Rect(52,7,b0-1,23,LCD_RED);
		Draw_Full_Rect(b0+16,7,209,23,LCD_RED);
		Set_Font(&Font16x24);
		if(b1==35)
		{	
			color1 = LCD_RED;
			color2 = LCD_GREEN;
			color3 = LCD_GREEN;
			color4 = LCD_GREEN;
			color5 = LCD_GREEN;
			color6 = LCD_GREEN;
			if(b2!=b1)
			{
				Draw_Full_Rect(b2-1,35,b2+22,305,LCD_RED);
				Draw_Full_Rect(b1-1,35,b1+22,305,LCD_GREEN);
			}
		}
		if(b1==65)
		{
			color1 = LCD_GREEN;
			color2 = LCD_RED;
			color3 = LCD_GREEN;
			color4 = LCD_GREEN;
			color5 = LCD_GREEN;
			color6 = LCD_GREEN;
			if(b2!=b1)
			{
				Draw_Full_Rect(b2-1,35,b2+22,305,LCD_RED);
				Draw_Full_Rect(b1-1,35,b1+22,305,LCD_GREEN);
			}
		}
		if(b1==95)
		{
			
			color1 = LCD_GREEN;
			color2 = LCD_GREEN;
			color3 = LCD_RED;
			color4 = LCD_GREEN;
			color5 = LCD_GREEN;
			color6 = LCD_GREEN;
			if(b2!=b1)
			{
				Draw_Full_Rect(b2-1,35,b2+22,305,LCD_RED);
				Draw_Full_Rect(b1-1,35,b1+22,305,LCD_GREEN);
			}
		}
		if(b1==125)
		{
			
			color1 = LCD_GREEN;
			color2 = LCD_GREEN;
			color3 = LCD_GREEN;
			color4 = LCD_RED;
			color5 = LCD_GREEN;
			color6 = LCD_GREEN;
			if(b2!=b1)
			{
				Draw_Full_Rect(b2-1,35,b2+22,305,LCD_RED);
				Draw_Full_Rect(b1-1,35,b1+22,305,LCD_GREEN);
			}
		}
		if(b1==155)
		{
			
			color1 = LCD_GREEN;
			color2 = LCD_GREEN;
			color3 = LCD_GREEN;
			color4 = LCD_GREEN;
			color5 = LCD_RED;
			color6 = LCD_GREEN;
			if(b2!=b1)
			{
				Draw_Full_Rect(b2-1,35,b2+22,305,LCD_RED);
				Draw_Full_Rect(b1-1,35,b1+22,305,LCD_GREEN);
			}
		}
		if(b1==185)
		{
			
			color1 = LCD_GREEN;
			color2 = LCD_GREEN;
			color3 = LCD_GREEN;
			color4 = LCD_GREEN;
			color5 = LCD_GREEN;
			color6 = LCD_RED;
			if(b2!=b1)
			{
				Draw_Full_Rect(b2-1,35,b2+22,305,LCD_RED);
				Draw_Full_Rect(b1-1,35,b1+22,305,LCD_GREEN);
			}
		}	
		if(tv==0)
		{
			Display_String(35,300,"Scale", color1);
			Display_String(65,300,"PID", color2);
			Display_String(95,300,"Oscillocope", color3);
			Display_String(125,300,"Paint", color4);
			Display_String(155,300,"Calculator", color5);
			Display_String(185,300,"Accelerometer", color6);
		}
		if(tv==1)
		{
			Display_String(35,300,"PID", color1);
			Display_String(65,300,"Oscillocope", color2);
			Display_String(95,300,"Paint", color3);
			Display_String(125,300,"Calculator", color4);
			Display_String(155,300,"Accelerometer", color5);
			Display_String(185,300,"Uart", color6);
		}
		if(tv==2)
		{
			Display_String(35,300,"Oscillocope", color1);
			Display_String(65,300,"Paint", color2);
			Display_String(95,300,"Calculator", color3);
			Display_String(125,300,"Accelerometer", color4);
			Display_String(155,300,"Uart", color5);
			Display_String(185,300,"Touch Screen", color6);
		}
		if(tv==3)
		{
			Display_String(35,300,"Paint", color1);
			Display_String(65,300,"Calculator", color2);
			Display_String(95,300,"Accelerometer", color3);
			Display_String(125,300,"Uart", color4);
			Display_String(155,300,"Touch Screen", color5);
			Display_String(185,300,"Brightness", color6);
		}
		if(tv==4)
		{
			Display_String(35,300,"Calculator", color1);
			Display_String(65,300,"Accelerometer", color2);
			Display_String(95,300,"Uart", color3);
			Display_String(125,300,"Touch Screen", color4);
			Display_String(155,300,"Brightness", color5);
			Display_String(185,300,"Test", color6);
		}
		if(tv==5)
		{
			Display_String(35,300,"Accelerometer", color1);
			Display_String(65,300,"Uart", color2);
			Display_String(95,300,"Touch Screen", color3);
			Display_String(125,300,"Brightness", color4);
			Display_String(155,300,"Test", color5);
			Display_String(185,300,"Display", color6);
		}
		b2=b1;
		switch(op3)
		{
			case 0:
			{
			}break;
			case 1:
			{
				op5=1;
				while(op5)
				{
					Clear_Screen(0x0000);
				  scaleanalog();
					Clear_Screen(0x0000);
				}
				op4=0;
			}break;
			case 2:
			{
				Clear_Screen(0x0000);
				PID();
				op3=0;
				op4=0;
				Clear_Screen(0x0000);
			}break;
			case 3:
			{
				Clear_Screen(0x0000);
				Delay_ms(50);
				Draw_Rect(0,0,240,320,LCD_BLACK);
				Delay_ms(50);
				Draw_Full_Rect(2,5,29,315,LCD_LIGH_BLUE);
				Draw_Full_Rect(192,5,238,315,LCD_LIGH_BLUE);
				Draw_Full_Rect(215,210,235,310,LCD_BLACK);
				Draw_Full_Rect(215,105,235,205,LCD_BLACK);
				Delay_ms(50);
				Draw_Rect(215,210,235,310,LCD_WHITE);
				Draw_Rect(215,105,235,205,LCD_WHITE);
				Delay_ms(50);
				oscillocope();
				op3=0;
				op4=0;
				Clear_Screen(0x0000);
			}break;
			case 4:
			{
				Draw_Full_Rect(0, 0 ,240 ,320, LCD_PINK);
				Clear_Screen(0x0000);
				paa=1;
				while(paa)
				{
					paint();
				}
				op3=0;
				op4=0;
				Clear_Screen(0x0000);
			}break;
			case 5:
			{
				Clear_Screen(0x0000);
				Draw_Full_Rect(0, 0 ,240 ,320, LCD_LIGH_BLUE);
				maytinh();
				ca=1;
				ic=1;
				while(ca)
				{
					maytinh1();
				}
				op3=0;
				op4=0;
				Clear_Screen(0x0000);
			}break;
			case 6:
			{
				Clear_Screen(0x0000);
				ax=1;
				Axis();
				op3=0;
				op4=0;
				Clear_Screen(0x0000);
			}break;
			case 7:
			{
				Clear_Screen(0x0000);
				uart();
				Clear_Screen(0x0000);
				op3=0;
				op4=0;
			}break;
			case 8:
			{
				Clear_Screen(0x0000);
				calibration();
				op3=0;
				op4=0;
			}break;
			case 9:
			{
				Clear_Screen(0x0000);
				brightness();
				op4=0;
			}break;
			case 10:
			{
				Clear_Screen(0x0000);
				Random_Lines();
				Clear_Screen(0x0000);
				Random_Rect();
				Clear_Screen(0x0000);
				Random_Circle();
				Clear_Screen(0x0000);
			}break;
			case 11:
			{
				updateXY();
				if((Pen_Point.X0 >50&&Pen_Point.X0 <200)&&(Pen_Point.Y0 >50&&Pen_Point.Y0 <280))
				{
					Delay_ms(80);
					doi++;
					if(doi>5) doi=0;
					Pen_Point.X=0;
					Pen_Point.Y=0;
				}
				while(1)
				{
					album();
				}
			//	op 4=0;
			}break;
		}
	}
}
void dieuchinhXY(void)
{
	int bu=0;
	/*updateXY();
	Y = (Pen_Point.X0*100)/240 ;
  Y0 = ((Y*320)/100);//+caliy1-calix2;
	X = (Pen_Point.Y0*100)/320 ;
	X0 = ((X*240)/100);//+calix1-calix2;
	if(X0>150) X0=X0+15;
	else X0=X0+5;
	Pen_Point.X=0;
	Pen_Point.Y=0*/
	updateXY();
	X0 = Pen_Point.X0;
	Y0 = 320-Pen_Point.Y0;
	if(Y0>100) {
		bu = Y0-100;
		Y0=Y0-(unsigned int)(bu/15);
	}
	Pen_Point.X=0;
	Pen_Point.Y=0;
}
void maytinh(void)
{
		Set_Font(&Font16x24);
		Display_String(200, 105, "0", LCD_WHITE);
		Display_String(88, 295, "1", LCD_WHITE);
		Display_String(88, 232, "2", LCD_WHITE);
		Display_String(88, 170, "3", LCD_WHITE);
		Display_String(143, 295, "4", LCD_WHITE);
		Display_String(143, 232, "5", LCD_WHITE);
		Display_String(143, 170, "6", LCD_WHITE);
		Display_String(200, 295, "7", LCD_WHITE);
		Display_String(200, 232, "8", LCD_WHITE);
		Display_String(200, 170, "9", LCD_WHITE);
		Display_String(88, 105, "+", LCD_WHITE);
		Display_String(88, 40, "-", LCD_WHITE);
		Display_String(143, 105, "*", LCD_WHITE);
		Display_String(143, 40, "/", LCD_WHITE);
		Display_String(200, 40, "=", LCD_WHITE);
		Display_String(22, 40, "X", LCD_WHITE);
}
void maytinh1(void)
{
		icon(185,5,235,63,LCD_RED,ic,1);
		icon(185,68,235,126,LCD_RED,ic,2);
		icon(185,131,235,189,LCD_RED,ic,3);
		icon(185,194,235,252,LCD_RED,ic,4);
		icon(185,257,235,315,LCD_RED,ic,5);
	
		icon(130,5,180,63,LCD_RED,ic,6);
		icon(130,68,180,126,LCD_RED,ic,7);
		icon(130,131,180,189,LCD_RED,ic,8);
		icon(130,194,180,252,LCD_RED,ic,9);
		icon(130,257,180,315,LCD_RED,ic,10);
	
		icon(75,5,125,63,LCD_RED,ic,11);
		icon(75,68,125,126,LCD_RED,ic,12);
		icon(75,131,125,189,LCD_RED,ic,13);
		icon(75,194,125,252,LCD_RED,ic,14);
		icon(75,257,125,315,LCD_RED,ic,15);
	
		icon(5,5,65,63,LCD_RED,ic,16);
		icon(5,68,65,315,LCD_RED,ic,17);
		ic=0;
		maytinh();
		dieuchinhXY();
		if(icr2==1)
		{
			Display_String(8, A, "0", LCD_WHITE);
			A=A-15;
			data1=0;
			C++;
			icr2=0;//icr1=0;icr2=0;icr3=0;icr4=0;icr5=0;icr6=0;icr7=0;icr8=0;icr9=0;icr10=0;icr11=0;icr12=0;icr13=0;icr14=0;icr15=0;icr16=0;icr17=0;
		}
		if(icr15==1)
		{
			Display_String(8, A, "1", LCD_WHITE);
			A=A-15;
			data1=1;
			C++;
			icr15=0;
		}
		if(icr14==1)
		{
			Display_String(8, A, "2", LCD_WHITE);
			A=A-15;
			data1=2;
			C++;
			icr14=0;
		}
		if(icr13==1)
		{
			Display_String(8, A, "3", LCD_WHITE);
			A=A-15;
			data1=3;
			C++;
			icr13=0;
		}
		if(icr10==1)
		{
			Display_String(8, A, "4", LCD_WHITE);
			A=A-15;
			data1=4;
			C++;
			icr10=0;
		}
		if(icr9==1)
		{
			Display_String(8, A, "5", LCD_WHITE);
			A=A-15;
			data1=5;
			C++;
			icr9=0;
		}
		if(icr8==1)
		{
			Display_String(8, A, "6", LCD_WHITE);
			A=A-15;
			data1=6;
			C++;
			icr8=0;
		}
		if(icr5==1)
		{
			Display_String(8, A, "7", LCD_WHITE);
			A=A-15;
			data1=7;
			C++;
			icr5=0;
		}
		if(icr4==1)
		{
			Display_String(8, A, "8", LCD_WHITE);
			A=A-15;
			data1=8;
			C++;
			icr4=0;
		}
		if(icr3==1)
		{
			Display_String(8, A, "9", LCD_WHITE);
			A=A-15;
			data1=9;
			C++;
			icr3=0;
		}
		if(icr1==1)
			{
				bang++;
				if(bang>1)bang=0;
				icr1=0;
			}
		if(icr12==1)
		{
			Display_String(8, A, "+", LCD_WHITE);
			A=A-15;
			cong=1;
			icr12=0;
		}
		if(icr11==1)
		{
			Display_String(8, A, "-", LCD_WHITE);
			A=A-15;
			tru=1;
			icr11=0;
		}
		if(icr7==1)
		{
			Display_String(8, A, "*", LCD_WHITE);
			A=A-15;
			nhan=1;
			icr7=0;
		}
		if(icr6==1)
		{
			Display_String(8, A, "/", LCD_WHITE);
			A=A-15;
			chia=1;
			icr6=0;
		}
		if(icr16==1)
		{
			Draw_Full_Rect(8, 70 ,60 ,312, LCD_RED );
			cong=0;
			nhan=0;
			tru=0;
			chia=0;
			bang=0;
			biena=0;
			bienb=0;
			bienc=0;
			C=0;
			A = 310;
			icr16=0;
		}
		if(icr17==1)
		{
			icr17=0;
			ca=0;
			A = 310;
		}
			if(A<95) A=310;
		  pheptinh();
}
void valuea(void)
{
	for(i=0;i<C;i++)
			{
				biena = biena + (ma1[C-(i+1)]*ma[i]);
			}
		for(i=0;i<5;i++)
			{
			ma1[i]=0;
			}
			C=0;
}
void valueb(void)
{	for(i=0;i<C;i++)
		{	
			bienb = bienb + (ma1[C-(i+1)]*ma[i]);
		}
		for(i=0;i<5;i++)
			{
			ma1[i]=0;
			}
			C=0;
}
void pheptinh(void)
{
	uint8_t i,j=0;
	char StrNumber[10];
	if(cong==0||cong==2||tru==0||tru==2||nhan==0||nhan==2||chia==0||chia==2)
	{
		ma1[C-1] =data1;
	}
	if(cong ==1)
	{
		valuea();
		cong=2;
	}
	if(tru==1)
	{
		valuea();
		tru=2;
	}
	if(nhan ==1)
	{
		valuea();
		nhan=2;
	}
	if(chia ==1)
	{
		valuea();
		chia=2;
	}
	if((bang==1&&cong==2)||(bang==1&&tru==2)||(bang==1&&nhan==2)||(bang==1&&chia==2))
	{
		Draw_Full_Rect(30, 70 ,65 ,312, LCD_RED );
		valueb();
		if(cong==2)
		{
			bienc=biena+bienb;
			cong=0;
		}
		if(tru==2)
		{
			bienc=biena-bienb;
			tru=0;
		}
		if(nhan==2)
		{
			bienc=biena*bienb;
			nhan=0;
		}
		if(chia==2)
		{
			bienc=biena/bienb;
			chia=0;
		}
		uint16tostr(StrNumber, bienc, 10);
		Display_String(40, 310,StrNumber, LCD_WHITE);
		bang =0;
	}
}
void tinhdientro(void)
{
	
	Draw_Full_Rect(0, 0 ,240 ,320 , LCD_BLACK );
	Draw_Full_Rect(5,5,65 ,315 , LCD_RED );
	Draw_Full_Rect(120, 0 ,230 ,320 , LCD_PINK );
	Draw_Rect(70,110,100,210,LCD_GREEN);
	Draw_Rect(129,9,170,311,LCD_GREEN); //vien mau 
	Draw_Rect(179,9,220,311,LCD_GREEN);//vien mau
	Draw_Full_Rect(70, 10 ,100 ,60 , LCD_GREEN );// clear
	Set_Font(&Font16x24);
	Display_String(75, 45, "X", LCD_WHITE);
	Draw_Full_Rect(71, 111 ,100 ,209 , LCD_LIGH_GREEN);
	
	
	Draw_Full_Rect(130, 250 ,170 ,310 , LCD_BLACK );
	Draw_Full_Rect(130, 190 ,170 ,250 , LCD_BROWN );
	Draw_Full_Rect(130, 130 ,170 ,190 , LCD_RED );
	Draw_Full_Rect(130, 70  ,170 ,130 , LCD_ORANGE );
	Draw_Full_Rect(130, 10  ,170 ,70  , LCD_YELLOW );
	Draw_Full_Rect(180, 250 ,220 ,310 , LCD_GREEN  );
	Draw_Full_Rect(180, 190 ,220 ,250 , LCD_BLUE );
	Draw_Full_Rect(180, 130 ,220 ,190 , LCD_VIOLET );
	Draw_Full_Rect(180, 70  ,220 ,130 , LCD_GRAY );
	Draw_Full_Rect(180, 10  ,220 ,70  , LCD_WHITE );
	re=1;
	while(re)
	{	
		dieuchinhXY();
		if((130<X0&&X0<170)&&(255<Y0&&Y0<305))
		{
			Delay_ms(110);
			ii++;
			tn = (ii-1)*20;
			if(ii==1)color1=0;
			if(ii==2)color2=0;
			if(ii==3)color3=1;
			if(ii>=3)color =1;
			Draw_Full_Rect(75, 205-tn ,95 ,195-tn , LCD_BLACK );
		}
		if((130<X0&&X0<170)&&(195<Y0&&Y0<245))
		{
			Delay_ms(110);
			ii++;
			tn = (ii-1)*20;
			if(ii==1)color1=1;
			if(ii==2)color2=1;
			if(ii==3)color3=10;
			if(ii>=3)color =1;
			Draw_Full_Rect(75, 205-tn ,95 ,195-tn , LCD_BROWN );
		}
		if((130<X0&&X0<170)&&(135<Y0&&Y0<185))
		{
			Delay_ms(110);
			ii++;
			tn = (ii-1)*20;
			if(ii==1)color1=2;
			if(ii==2)color2=2;
			if(ii==3)color3=100;
			if(ii>=3)color =1;
			Draw_Full_Rect(75, 205-tn ,95 ,195-tn, LCD_RED );
		}
		if((130<X0&&X0<170)&&(75<Y0&&Y0<125))
		{
			Delay_ms(110);
			ii++;
			tn = (ii-1)*20;
			if(ii==1)color1=3;
			if(ii==2)color2=3;
			if(ii==3)color3=1000;
			if(ii>=3)color =1;
			Draw_Full_Rect(75, 205-tn ,95 ,195-tn, LCD_ORANGE );
		}
		if((130<X0&&X0<170)&&(15<Y0&&Y0<65))
		{
			Delay_ms(110);
			ii++;
			tn = (ii-1)*20;
			if(ii==1)color1=4;
			if(ii==2)color2=4;
			if(ii==3)color3=10000;
			if(ii>=3)color =1;
			Draw_Full_Rect(75, 205-tn ,95 ,195-tn , LCD_YELLOW );
		}
		
		if((180<X0&&X0<205)&&(255<Y0&&Y0<300))
		{
			Delay_ms(110);
			ii++;
			tn = (ii-1)*20;
			if(ii==1)color1=5;
			if(ii==2)color2=5;
			if(ii==3)color3=100000;
			if(ii>=3)color =1;
			Draw_Full_Rect(75, 205-tn ,95 ,195-tn, LCD_GREEN );
		}
		if((180<X0&&X0<210)&&(195<Y0&&Y0<245))
		{
			Delay_ms(110);
			ii++;
			tn = (ii-1)*20;
			if(ii==1)color1=6;
			if(ii==2)color2=6;
			if(ii>=3)color =1;
			Draw_Full_Rect(75, 205-tn ,95 ,195-tn, LCD_BLUE );
		}
		if((180<X0&&X0<210)&&(135<Y0&&Y0<185))
		{
			Delay_ms(110);
			ii++;
			tn = (ii-1)*20;
			if(ii==1)color1=7;
			if(ii==2)color2=7;
			if(ii>=3)color =1;
			Draw_Full_Rect(75, 205-tn ,95 ,195-tn, LCD_VIOLET );
		}
		if((180<X0&&X0<210)&&(75<Y0&&Y0<125))
		{
			Delay_ms(110);
			ii++;
			tn = (ii-1)*20;
			if(ii==1)color1=8;
			if(ii==2)color2=8;
			if(ii>=3)color =1;
			Draw_Full_Rect(75, 205-tn ,95 ,195-tn, LCD_GRAY );
		}
		if((180<X0&&X0<210)&&(15<Y0&&Y0<65))
		{
			Delay_ms(110);
			ii++;
			tn = (ii-1)*20;
			if(ii==1)color1=9;
			if(ii==2)color2=9;
			if(ii>=3)color =1;
			Draw_Full_Rect(75, 205-tn ,95 ,195-tn, LCD_WHITE );
		}
		icon(7,7,28,35,LCD_RED,ic,1);
		ic=0;
		Set_Font(&Font12x12);
		Display_String(12, 25,"X", LCD_WHITE);
		if(icr1==1)
		{
			re=0;
			Clear_Screen(0x0000);
			icr1=0;
			op3=0;
		}
	
		while(color)
		{
			char StrNumber3[10];
			dieuchinhXY();
			macolor =((color1*10)+color2)*color3;
			if(macolor>999999)
			{
				Draw_Full_Rect(10,40,65 ,310 , LCD_RED );
				macolor1 = (((macolor/1000000)*10)+((macolor%1000000)/100000))/10;
				uint16tostr(StrNumber3, macolor1, 10);
				Set_Font(&Font16x24);
				Display_String(20, 310,StrNumber3, LCD_WHITE);	
				Display_String(20, 100,"M", LCD_WHITE);			
				vv=1;				
			}
			if(macolor>999&&macolor<1000000)
			{
				Draw_Full_Rect(10,40,65 ,310 , LCD_RED );
				macolor1 =(((macolor/1000)*10)+((macolor%1000)/100))/10;
				uint16tostr(StrNumber3, macolor1, 10);
				Set_Font(&Font16x24);
				Display_String(20, 310,StrNumber3, LCD_WHITE);	
				Display_String(20, 100,"K", LCD_WHITE);			
				vv=1;				
			}
			if(macolor<1000)
			{
				Draw_Full_Rect(10,40,65 ,310 , LCD_RED );
				uint16tostr(StrNumber3, macolor, 10);
				Set_Font(&Font16x24);
				Display_String(20, 310,StrNumber3, LCD_WHITE);		
				Display_String(20, 100,"ohm", LCD_WHITE);	
				vv=1;
			}
			ic=1;
			while(vv)
			{
				dieuchinhXY();
				if((70<X0&&X0<100)&&(15<Y0&&Y0<60))
				{
					Delay_ms(110);
					Draw_Full_Rect(71, 111 ,99 ,209 , LCD_LIGH_GREEN );
					Draw_Full_Rect(10,40,65 ,310 , LCD_RED );
					ii=0;
					color=0;
					vv=0;
				}
				icon(7,7,28,35,LCD_RED,ic,1);
				ic=0;
				Set_Font(&Font12x12);
				Display_String(12, 25,"X", LCD_WHITE);
				if(icr1==1)
				{
					re=0;
					Clear_Screen(0x0000);
					icr1=0;
					vv=0;
					op3=0;
					color=0;
				}
			}
		}
	}
}
void paint(void)
{
	uint8_t pa=0;
		if(pa1==0) 
		{
		pa3=LCD_WHITE;
		pa4=LCD_YELLOW;
		}	
		if(pa1==1) 
		{
			pa4=LCD_BLACK;
		}	
		if(pa1==2) 
		{
			pa4=LCD_RED;
		}	
		if(pa1==3) 
		{
			pa4=LCD_WHITE;
		}	
		Clear_Screen(0x0000);
		Delay_ms(50);
	Draw_Rect(14,294,115,316,LCD_PINK);   // vien
	Draw_Rect(124,294,225,316,LCD_PINK);
	Draw_Full_Rect(0,0,240,295,pa4);
	Draw_Full_Rect(15,295,45,315,LCD_BLACK);    // backgoud
	Draw_Full_Rect(50,295,80,315,LCD_RED);
	Draw_Full_Rect(85,295,115,315,LCD_WHITE);
	Draw_Full_Rect(125,295,155,315,LCD_GREEN);  // color
	Draw_Full_Rect(160,295,190,315,LCD_YELLOW);
	Draw_Full_Rect(195,295,225,315,LCD_VIOLET);
	pa=1;
	ic=1;
	while(pa)
	{
			dieuchinhXY();
			if((10<X0&&X0<230)&&(10<Y0&&Y0<290))
			{
					Draw_Full_Circle(X0,Y0,2,pa3);
			}
			if((15<X0&&X0<45)&&(295<Y0&&Y0<310))
			{
				Delay_ms(50);
				pa1=1;
				pa=0;
			}
			if((50<X0&&X0<80)&&(295<Y0&&Y0<310))
			{
				Delay_ms(50);
				pa1=2;
				pa=0;
			}
			if((85<X0&&X0<115)&&(295<Y0&&Y0<310))
			{
				Delay_ms(50);
				pa1=3;
				pa=0;
			}
			if((125<X0&&X0<155)&&(295<Y0&&Y0<310))
			{
				Delay_ms(50);
				pa3=LCD_GREEN;
			}
			if((160<X0&&X0<190)&&(295<Y0&&Y0<310))
			{
				Delay_ms(50);
				pa3=LCD_YELLOW;
			}
			if((195<X0&&X0<225)&&(295<Y0&&Y0<310))
			{
				Delay_ms(50);
					pa3=LCD_VIOLET;
			}
		icon(7,7,28,35,LCD_RED,ic,1);
		ic=0;
		Set_Font(&Font12x12);
		Display_String(12, 25,"X", LCD_WHITE);
		if(icr1==1)
		{
			icr1=0;
			pa=0;
			paa=0;
		}
			
	}
}
void updateXY(void)
{
		read_once();
	  Read_Ads7846();
		Pen_Point.X0=240-((int)((Pen_Point.X-103)/7.7));
	  Pen_Point.Y0=320-((int)((Pen_Point.Y-104)/5.56));
}
void album(void)
{
	
	if(doi==0)
	{
	//	Display_String(0, 16, "X", LCD_RED);
		
		Draw_Image(0, 0, 240, 320, img05);
		Delay_ms(100);
		Draw_Full_Circle(100,150,6,LCD_YELLOW);
		Delay_ms(500);
	}
	if(doi==1)
	{
		//Display_String(0, 16, "X", LCD_RED);
		//Draw_Image(0, 0, 240, 320, img01);
		
	}
	if(doi==2)
	{
	//	Display_String(0, 16, "X", LCD_RED);
	//	Draw_Image(0, 0, 240, 320, img02);
	
	}
	if(doi==3)
	{
		//Display_String(0, 16, "X", LCD_RED);
		//Draw_Image(0, 0, 240, 320, img04);
		
	}
	if(doi==4)
	{
		//Display_String(0, 16, "X", LCD_RED);
		//Draw_Image(0, 0, 240, 320, img05);
		
	}
	if(doi==5)
	{
		//Display_String(0, 16, "X", LCD_RED);
	 //   Draw_Image(0, 0, 240, 320, img05);
		
	}
}

void Demo_MMIA(void)
{
	TIM_TimeBaseInitTypeDef  TIM_TimeBaseStructure;
  TIM_OCInitTypeDef  TIM_OCInitStructure;
  uint16_t Number=0;
  int CharCount;
  char StrNumber[10];
  Clear_Screen(0x0000);
  Set_Font(&Font16x24);
  Display_String(14, 295, "Tran Chi Cuong", LCD_WHITE);
  uint16tostr(StrNumber, Number, 10);
  Display_String(43, 295, StrNumber, LCD_WHITE);
  CharCount = sprintf(StrNumber,"%d", Number);
  Display_String(43, 295, StrNumber, LCD_WHITE);
  Display_String(72, 287, "MSSV : 1111564", LCD_WHITE);
  Set_Font(&Font12x12);
  Display_String(97, 285, "STM32F4-Discovery", LCD_WHITE);
  //Draw_Image(120, 195, 70, 70, img00);
  Set_Font(&Font8x8);
  Display_String(215, 215, "Khoa Cong Nghe", LCD_WHITE);
  Display_String(225, 215, "----The end----", LCD_WHITE);

  Number = 100;
  Set_Font(&Font16x24);
	if(Pen_Point.Y0 ==1){
	Set_Font(&Font16x24);
  Display_String(14, 295, "Tran Chi Cuong", LCD_WHITE);
}
  while (Number != 0)
  {
	  Draw_Full_Rect(43, 295 ,61 ,25 , LCD_BLACK);
	  uint16tostr(StrNumber, Number, 10);
	  Display_String(43, 295, StrNumber, LCD_WHITE);
	  CharCount = sprintf(StrNumber,"%d", Number);
	  Display_String(43, 295, StrNumber, LCD_WHITE);
	    TIM_OCInitStructure.TIM_Pulse = Number;
	    TIM_OC2Init(TIM3, &TIM_OCInitStructure);
	    TIM_OC2PreloadConfig(TIM3, TIM_OCPreload_Enable);
	  Delay_ms(20);
	  Number--;
  }

  GPIO_ToggleBits(GPIOD, GPIO_Pin_13);
	
	Clear_Screen(0x0000);
	//Draw_Image(0, 319, 240, 320, img02);
	Delay_ms(1000);
}

void Random_Lines(void)
{
  uint16_t x1,y1,x2,y2;
  uint32_t i;
  uint16_t cr;

  for(i=0;i<100;i++)
  {
    x1=rand() % 240;  
    y1=rand() % 320;
    x2=rand() % 240;
    y2=rand() % 320;

    cr=rand();

    Draw_Line(x1, y1 ,x2 ,y2 , cr << 3);
    Delay_ms(100);
  }
}


void Random_Rect(void)
{
  uint16_t x1,y1,x2,y2,z;
  uint32_t i;
  uint16_t cr;

  for(i=0;i<100;i++)
  {
    x1=rand() % 240; 
    y1=rand() % 320;
    x2=rand() % 240;
    y2=rand() % 320;

    cr=rand();

    z=rand() % 10;

    if (z >= 5) Draw_Rect(x1, y1 ,x2 ,y2 , cr << 3);
    else Draw_Full_Rect(x1, y1 ,x2 ,y2 , cr << 3);
    Delay_ms(100);
  }
}



void Random_Circle(void)
{
  uint16_t x, y, r, z;
  uint32_t i;
  uint16_t cr;

  for(i=0;i<100;i++)
  {
    x=rand() % 140;  
    y=rand() % 220;
    r=(rand() % 50) + 1;

    cr=rand() << 3;

    z=rand() % 10;

    if (z >= 5) Draw_Circle(x+50, y+50, r, cr);
    else Draw_Full_Circle(x+50, y+50, r, cr);
    Delay_ms(100);
  }
}



void ADC_Config(void)
{
	DMA_InitTypeDef DMA_InitStructure;
 ADC_InitTypeDef ADC_InitStructure;
 ADC_CommonInitTypeDef ADC_CommonInitStructure;
 GPIO_InitTypeDef GPIO_InitStructure;
 RCC_AHB1PeriphClockCmd(RCC_AHB1Periph_DMA2, ENABLE);
 RCC_APB2PeriphClockCmd(RCC_APB2Periph_ADC1, ENABLE); 
 RCC_AHB1PeriphClockCmd(RCC_AHB1Periph_GPIOC, ENABLE);
 
 GPIO_InitStructure.GPIO_Pin = GPIO_Pin_0 | GPIO_Pin_1 | GPIO_Pin_2;
 GPIO_InitStructure.GPIO_Mode = GPIO_Mode_AN;
 GPIO_InitStructure.GPIO_PuPd = GPIO_PuPd_NOPULL ;
 GPIO_Init(GPIOC, &GPIO_InitStructure);
 
 DMA_InitStructure.DMA_Channel = DMA_Channel_0; 
 DMA_InitStructure.DMA_Memory0BaseAddr = (uint32_t)&ADCValue;
 DMA_InitStructure.DMA_PeripheralBaseAddr = (uint32_t)(&(ADC1->DR));
 DMA_InitStructure.DMA_DIR = DMA_DIR_PeripheralToMemory;
 DMA_InitStructure.DMA_BufferSize = 3;
 DMA_InitStructure.DMA_PeripheralInc = DMA_PeripheralInc_Disable;
 DMA_InitStructure.DMA_MemoryInc = DMA_MemoryInc_Enable;
 DMA_InitStructure.DMA_PeripheralDataSize = DMA_PeripheralDataSize_HalfWord;
 DMA_InitStructure.DMA_MemoryDataSize = DMA_MemoryDataSize_HalfWord;
 DMA_InitStructure.DMA_Mode = DMA_Mode_Circular;
 DMA_InitStructure.DMA_Priority = DMA_Priority_High;
 DMA_InitStructure.DMA_FIFOMode = DMA_FIFOMode_Enable; 
 DMA_InitStructure.DMA_FIFOThreshold = DMA_FIFOThreshold_HalfFull;
 DMA_InitStructure.DMA_MemoryBurst = DMA_MemoryBurst_Single;
 DMA_InitStructure.DMA_PeripheralBurst = DMA_PeripheralBurst_Single;
 DMA_Init(DMA2_Stream0, &DMA_InitStructure);
 
 /* DMA2_Stream0 enable */
 DMA_Cmd(DMA2_Stream0, ENABLE);
 
 
 /* ADC Common Init **********************************************************/
 ADC_CommonInitStructure.ADC_Mode = ADC_Mode_Independent;
 ADC_CommonInitStructure.ADC_Prescaler = ADC_Prescaler_Div2;
 ADC_CommonInitStructure.ADC_DMAAccessMode = ADC_DMAAccessMode_Disabled;
 ADC_CommonInitStructure.ADC_TwoSamplingDelay = ADC_TwoSamplingDelay_5Cycles;
 ADC_CommonInit(&ADC_CommonInitStructure);
 
 ADC_InitStructure.ADC_Resolution = ADC_Resolution_12b;
 ADC_InitStructure.ADC_ScanConvMode = ENABLE;
 ADC_InitStructure.ADC_ContinuousConvMode = ENABLE;
 ADC_InitStructure.ADC_ExternalTrigConvEdge = ADC_ExternalTrigConvEdge_None;
 ADC_InitStructure.ADC_DataAlign = ADC_DataAlign_Right;
 ADC_InitStructure.ADC_NbrOfConversion = 3;
 ADC_Init(ADC1, &ADC_InitStructure);
 
 /* ADC1 regular channels configuration */ 
 ADC_RegularChannelConfig(ADC1, ADC_Channel_10, 1, ADC_SampleTime_3Cycles);
 ADC_RegularChannelConfig(ADC1, ADC_Channel_11, 2, ADC_SampleTime_3Cycles);
 ADC_RegularChannelConfig(ADC1, ADC_Channel_12, 3, ADC_SampleTime_3Cycles);
 
 /* Enable ADC1 DMA */
 ADC_DMACmd(ADC1, ENABLE);
 
 /* Enable DMA request after last transfer (Single-ADC mode) */
 ADC_DMARequestAfterLastTransferCmd(ADC1, ENABLE);
 
 /* Enable ADC1 */
 ADC_Cmd(ADC1, ENABLE);
 
 /* Start ADC1 Software Conversion */
 ADC_SoftwareStartConv(ADC1);
 }

void GPIO_Configuration(void)
{
    GPIO_InitTypeDef GPIO_InitStructure;
    RCC_AHB1PeriphClockCmd(RCC_AHB1Periph_GPIOB, ENABLE);
    
    GPIO_InitStructure.GPIO_Pin = GPIO_Pin_1|GPIO_Pin_2|GPIO_Pin_3|GPIO_Pin_4;
    GPIO_InitStructure.GPIO_Mode = GPIO_Mode_OUT;
    GPIO_InitStructure.GPIO_OType = GPIO_OType_PP;
    GPIO_InitStructure.GPIO_Speed = GPIO_Speed_100MHz;
    GPIO_InitStructure.GPIO_PuPd = GPIO_PuPd_NOPULL;
    GPIO_Init(GPIOB, &GPIO_InitStructure);
}
  
void EXTILine0_Config(void)
{
	  GPIO_InitTypeDef  GPIO_InitStructure1;
		NVIC_InitTypeDef  NVIC_InitStructure2;
		EXTI_InitTypeDef  EXTI_InitStructure1;
    /* Enable GPIOB clock */
    RCC_AHB1PeriphClockCmd(RCC_AHB1Periph_GPIOB, ENABLE);
    /* Enable SYSCFG clock */
    RCC_APB2PeriphClockCmd(RCC_APB2Periph_SYSCFG, ENABLE);
    
    /* Configure PB0 pin as input floating */
    GPIO_InitStructure1.GPIO_Mode = GPIO_Mode_IN;
    GPIO_InitStructure1.GPIO_PuPd = GPIO_PuPd_UP;
    GPIO_InitStructure1.GPIO_Pin = GPIO_Pin_0;
    GPIO_Init(GPIOB, &GPIO_InitStructure1);
  
    /* Connect EXTI Line0 to PB0 pin */
    SYSCFG_EXTILineConfig(EXTI_PortSourceGPIOB, EXTI_PinSource0);
  
    /* Configure EXTI Line0 */
    EXTI_InitStructure1.EXTI_Line = EXTI_Line0;
    EXTI_InitStructure1.EXTI_Mode = EXTI_Mode_Interrupt;
    EXTI_InitStructure1.EXTI_Trigger = EXTI_Trigger_Falling;  
    EXTI_InitStructure1.EXTI_LineCmd = ENABLE;
    EXTI_Init(&EXTI_InitStructure1);
  
    /* Enable and set EXTI Line0 Interrupt to the lowest priority */
    NVIC_InitStructure2.NVIC_IRQChannel = EXTI0_IRQn;
    NVIC_InitStructure2.NVIC_IRQChannelPreemptionPriority = 0;
    NVIC_InitStructure2.NVIC_IRQChannelSubPriority = 0;
    NVIC_InitStructure2.NVIC_IRQChannelCmd = ENABLE;
    NVIC_Init(&NVIC_InitStructure2);
}
  
void EXTILine9_Config(void)
{
		GPIO_InitTypeDef  GPIO_InitStructure;
  	NVIC_InitTypeDef  NVIC_InitStructure;
		EXTI_InitTypeDef  EXTI_InitStructure;
    /* Enable GPIOB clock */
    RCC_AHB1PeriphClockCmd(RCC_AHB1Periph_GPIOB, ENABLE);
    /* Enable SYSCFG clock */
    RCC_APB2PeriphClockCmd(RCC_APB2Periph_SYSCFG, ENABLE);
    
    /* Configure PB5 PB6 pin as input floating */
    GPIO_InitStructure.GPIO_Mode = GPIO_Mode_IN;
    GPIO_InitStructure.GPIO_PuPd = GPIO_PuPd_UP;
    GPIO_InitStructure.GPIO_Pin = GPIO_Pin_5 | GPIO_Pin_6;
    GPIO_Init(GPIOB, &GPIO_InitStructure);
  
    /* Connect EXTI Line5, Line6 to PB5,PB6 pin */
    SYSCFG_EXTILineConfig(EXTI_PortSourceGPIOB, EXTI_PinSource5);
    SYSCFG_EXTILineConfig(EXTI_PortSourceGPIOB, EXTI_PinSource6);
  
    /* Configure EXTI Line5, Line6 */
    EXTI_InitStructure.EXTI_Line = EXTI_Line5 | EXTI_Line6;
    EXTI_InitStructure.EXTI_Mode = EXTI_Mode_Interrupt;
    EXTI_InitStructure.EXTI_Trigger = EXTI_Trigger_Rising_Falling;  
    EXTI_InitStructure.EXTI_LineCmd = ENABLE;
    EXTI_Init(&EXTI_InitStructure);
    /* Enable and set EXTI Line5, Line6 Interrupt to the lowest priority */
    NVIC_InitStructure.NVIC_IRQChannel = EXTI9_5_IRQn;
    NVIC_InitStructure.NVIC_IRQChannelPreemptionPriority = 0;
    NVIC_InitStructure.NVIC_IRQChannelSubPriority = 0;
    NVIC_InitStructure.NVIC_IRQChannelCmd = ENABLE;
    NVIC_Init(&NVIC_InitStructure);
}
 void TIMbase_Configuration(void)
  {
		GPIO_InitTypeDef GPIO_InitStructure;
    NVIC_InitTypeDef NVIC_InitStructure;
    TIM_TimeBaseInitTypeDef  TIM_TimeBaseStructure;
		
    RCC_APB1PeriphClockCmd(RCC_APB1Periph_TIM3, ENABLE);
		RCC_AHB1PeriphClockCmd(RCC_AHB1Periph_GPIOB, ENABLE);
		
    /* Configure PB0 PB1 in output pushpull mode */
    GPIO_InitStructure.GPIO_Pin = GPIO_Pin_0 | GPIO_Pin_1;
    GPIO_InitStructure.GPIO_Mode = GPIO_Mode_OUT;
    GPIO_InitStructure.GPIO_OType = GPIO_OType_PP;
    GPIO_InitStructure.GPIO_Speed = GPIO_Speed_100MHz;
    GPIO_InitStructure.GPIO_PuPd = GPIO_PuPd_NOPULL;
    GPIO_Init(GPIOB, &GPIO_InitStructure);
    
    /* Time base configuration */
    TIM_TimeBaseStructure.TIM_Prescaler = ((SystemCoreClock/2)/500000)-1;     // frequency = 2000000
    TIM_TimeBaseStructure.TIM_Period =1000 - 1;
    TIM_TimeBaseStructure.TIM_ClockDivision = 0;
    TIM_TimeBaseStructure.TIM_CounterMode = TIM_CounterMode_Up;
    TIM_TimeBaseInit(TIM3, &TIM_TimeBaseStructure);
    TIM_ITConfig(TIM3,TIM_IT_Update,ENABLE);
    TIM_Cmd(TIM3, ENABLE);
    
    NVIC_InitStructure.NVIC_IRQChannel = TIM3_IRQn;
    NVIC_InitStructure.NVIC_IRQChannelPreemptionPriority = 0;
    NVIC_InitStructure.NVIC_IRQChannelSubPriority = 1;
    NVIC_InitStructure.NVIC_IRQChannelCmd = ENABLE;
    NVIC_Init(&NVIC_InitStructure);   
  }
  
void TIM2_Configuration(void)
  {
		NVIC_InitTypeDef NVIC_InitStructure;
		GPIO_InitTypeDef GPIO_InitStructure;
    TIM_TimeBaseInitTypeDef  TIM_TimeBaseStructure;
		
    TIM_TimeBaseStructure.TIM_Prescaler = ((SystemCoreClock/2)/500000)-1;     // frequency = 2000000
    TIM_TimeBaseStructure.TIM_Period =1000 - 1;
    TIM_TimeBaseStructure.TIM_ClockDivision = 0;
    TIM_TimeBaseStructure.TIM_CounterMode = TIM_CounterMode_Up;
    TIM_TimeBaseInit(TIM2, &TIM_TimeBaseStructure);
    TIM_ITConfig(TIM2,TIM_IT_Update,ENABLE);
    TIM_Cmd(TIM2, ENABLE);
    
    NVIC_InitStructure.NVIC_IRQChannel = TIM2_IRQn;
    NVIC_InitStructure.NVIC_IRQChannelPreemptionPriority = 0;
    NVIC_InitStructure.NVIC_IRQChannelSubPriority = 1;
    NVIC_InitStructure.NVIC_IRQChannelCmd = ENABLE;
    NVIC_Init(&NVIC_InitStructure);    
}
void I2C_Configuration(void)
{
#ifdef FAST_I2C_MODE
 #define I2C_SPEED 400000
 #define I2C_DUTYCYCLE I2C_DutyCycle_16_9  
#else /* STANDARD_I2C_MODE*/
 #define I2C_SPEED 100000
 #define I2C_DUTYCYCLE I2C_DutyCycle_2
#endif /* FAST_I2C_MODE*/
	
  GPIO_InitTypeDef  GPIO_InitStructure;
  I2C_InitTypeDef   I2C_InitStructure;

  RCC_AHB1PeriphClockCmd(RCC_AHB1Periph_GPIOB, ENABLE);
  RCC_APB1PeriphClockCmd(RCC_APB1Periph_I2C1, ENABLE);
	
  GPIO_InitStructure.GPIO_Pin = GPIO_Pin_8 | GPIO_Pin_9;
  GPIO_InitStructure.GPIO_Mode = GPIO_Mode_AF;
  GPIO_InitStructure.GPIO_OType = GPIO_OType_OD;
  GPIO_InitStructure.GPIO_PuPd = GPIO_PuPd_UP;
  GPIO_InitStructure.GPIO_Speed = GPIO_Speed_100MHz;  
  GPIO_Init(GPIOB, &GPIO_InitStructure);
	
  GPIO_PinAFConfig(GPIOB,GPIO_PinSource8,GPIO_AF_I2C1);
  GPIO_PinAFConfig(GPIOB,GPIO_PinSource9,GPIO_AF_I2C1);	

  /* I2C De-initialize */
  I2C_DeInit(I2C1);
  I2C_InitStructure.I2C_Mode = I2C_Mode_I2C;
  I2C_InitStructure.I2C_DutyCycle = I2C_DUTYCYCLE;
  I2C_InitStructure.I2C_OwnAddress1 = 0;
  I2C_InitStructure.I2C_Ack = I2C_Ack_Enable;
  I2C_InitStructure.I2C_ClockSpeed = I2C_SPEED;
  I2C_InitStructure.I2C_AcknowledgedAddress = I2C_AcknowledgedAddress_7bit;
  I2C_Init(I2C1, &I2C_InitStructure);
 /* I2C ENABLE */
  I2C_Cmd(I2C1, ENABLE); 
  /* Enable Interrupt */

}
void setup_LIS302DL(void)
{
	uint8_t ctrl = 0;
  
  LIS302DL_InitTypeDef  LIS302DL_InitStruct;
  LIS302DL_InterruptConfigTypeDef LIS302DL_InterruptStruct;  
  
  /* SysTick end of count event each 10ms */
  SysTick_Config(SystemCoreClock/ 1000);
  
  /* Set configuration of LIS302DL*/
  LIS302DL_InitStruct.Power_Mode = LIS302DL_LOWPOWERMODE_ACTIVE;
  LIS302DL_InitStruct.Output_DataRate = LIS302DL_DATARATE_100;
  LIS302DL_InitStruct.Axes_Enable = LIS302DL_X_ENABLE | LIS302DL_Y_ENABLE | LIS302DL_Z_ENABLE;
  LIS302DL_InitStruct.Full_Scale = LIS302DL_FULLSCALE_2_3;
  LIS302DL_InitStruct.Self_Test = LIS302DL_SELFTEST_NORMAL;
  LIS302DL_Init(&LIS302DL_InitStruct);
    
  /* Set configuration of Internal High Pass Filter of LIS302DL*/
  LIS302DL_InterruptStruct.Latch_Request = LIS302DL_INTERRUPTREQUEST_LATCHED;
  LIS302DL_InterruptStruct.SingleClick_Axes = LIS302DL_CLICKINTERRUPT_Z_ENABLE;
  LIS302DL_InterruptStruct.DoubleClick_Axes = LIS302DL_DOUBLECLICKINTERRUPT_Z_ENABLE;
  LIS302DL_InterruptConfig(&LIS302DL_InterruptStruct);

  /* Required delay for the MEMS Accelerometre: Turn-on time = 3/Output data Rate 
                                                             = 3/100 = 30ms */
  Delay_ms(10);
  
  /* Configure Interrupt control register: enable Click interrupt1 */
  ctrl = 0x07;
  LIS302DL_Write(&ctrl, LIS302DL_CTRL_REG3_ADDR, 1);
  
  /* Enable Interrupt generation on click/double click on Z axis */
  ctrl = 0x70;
  LIS302DL_Write(&ctrl, LIS302DL_CLICK_CFG_REG_ADDR, 1);
  
  /* Configure Click Threshold on X/Y axis (10 x 0.5g) */
  ctrl = 0xAA;
  LIS302DL_Write(&ctrl, LIS302DL_CLICK_THSY_X_REG_ADDR, 1);
  
  /* Configure Click Threshold on Z axis (10 x 0.5g) */
  ctrl = 0x0A;
  LIS302DL_Write(&ctrl, LIS302DL_CLICK_THSZ_REG_ADDR, 1);
  
  /* Configure Time Limit */
  ctrl = 0x03;
  LIS302DL_Write(&ctrl, LIS302DL_CLICK_TIMELIMIT_REG_ADDR, 1);
    
  /* Configure Latency */
  ctrl = 0x7F;
  LIS302DL_Write(&ctrl, LIS302DL_CLICK_LATENCY_REG_ADDR, 1);
  
  /* Configure Click Window */
  ctrl = 0x7F;
  LIS302DL_Write(&ctrl, LIS302DL_CLICK_WINDOW_REG_ADDR, 1);

  /* TIM configuration -------------------------------------------------------*/
  LIS302DL_Read(Buffer,LIS302DL_OUT_X_ADDR,6);
}
uint32_t LIS302DL_TIMEOUT_UserCallback(void)
{
  /* MEMS Accelerometer Timeout error occured */
  while (1)
  {   
  }
}

#ifdef  USE_FULL_ASSERT
void assert_failed(uint8_t* file, uint32_t line)
{
  while (1)
  {}
}
#endif
