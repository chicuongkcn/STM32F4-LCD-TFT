#ifndef __ADC_DMA_H
#define __ADC_DMA_H
#include <stm32f4xx.h>
#include "stm32f4xx_adc.h"
#include "stm32f4xx_dma.h"
void DMA_ADC_Config(void);
void ADC_Config(void);
#endif 