#include "stm32f4xx_exti.h"
#include "stm32f4xx_it.h"
#include "main.h"
#include <stm32f4xx.h>
uint16_t ngat1=0;
uint16_t ngat2=0;
extern __IO uint16_t dataline5;
extern __IO uint16_t dataline6;
extern __IO float datapwm;
__IO  float datavs=0;
__IO  float dataVc=0;
__IO  float P=0,I=0,D=0, sume=0,dbien=0,e0=0,e1=0;
/* Private typedef -----------------------------------------------------------*/

char Prescaler = 200;
////////////////////////UART//////////////////////////////////////
#define MAX_STRLEN 12 
volatile char received_string[MAX_STRLEN+1]; 

/* Private define ------------------------------------------------------------*/
/* Private macro -------------------------------------------------------------*/
/* Private variables ---------------------------------------------------------*/
/* Private function prototypes -----------------------------------------------*/
/* Private functions ---------------------------------------------------------*/

/******************************************************************************/
/*            Cortex-M4 Processor Exceptions Handlers                         */
/******************************************************************************/

/**
  * @brief   This function handles NMI exception.
  * @param  None
  * @retval None
  */
void NMI_Handler(void)
{
}

/**
  * @brief  This function handles Hard Fault exception.
  * @param  None
  * @retval None
  */
void HardFault_Handler(void)
{
  /* Go to infinite loop when Hard Fault exception occurs */
  while (1)
  {
  }
}

/**
  * @brief  This function handles Memory Manage exception.
  * @param  None
  * @retval None
  */
void MemManage_Handler(void)
{
  /* Go to infinite loop when Memory Manage exception occurs */
  while (1)
  {
  }
}

/**
  * @brief  This function handles Bus Fault exception.
  * @param  None
  * @retval None
  */
void BusFault_Handler(void)
{
  /* Go to infinite loop when Bus Fault exception occurs */
  while (1)
  {
  }
}

/**
  * @brief  This function handles Usage Fault exception.
  * @param  None
  * @retval None
  */
void UsageFault_Handler(void)
{
  /* Go to infinite loop when Usage Fault exception occurs */
  while (1)
  {
  }
}

/**
  * @brief  This function handles SVCall exception.
  * @param  None
  * @retval None
  */
void SVC_Handler(void)
{
}

/**
  * @brief  This function handles Debug Monitor exception.
  * @param  None
  * @retval None
  */
void DebugMon_Handler(void)
{
}

/**
  * @brief  This function handles PendSVC exception.
  * @param  None
  * @retval None
  */
void PendSV_Handler(void)
{
}

/**
  * @brief  This function handles SysTick Handler.
  * @param  None
  * @retval None
  */
void SysTick_Handler(void)
{
	TimingDelay_Decrement();
		Prescaler--;
	if(Prescaler == 0)
	{
		Prescaler=200;
		GPIO_ToggleBits(GPIOD, GPIO_Pin_13);
	}
}
void TIM3_IRQHandler(void)
{
   static uint32_t time=0;
   if (TIM_GetITStatus(TIM3, TIM_IT_Update) != RESET)
   {
    if(++time>1000)
    {
       dataline5 =ngat1;
			 dataline6 =ngat2;
			 ngat1=0;
		   ngat2=0;
       time = 0;
		//	setPID();
    }
    TIM_ClearITPendingBit(TIM3, TIM_IT_Update); 
    }
}
void TIM2_IRQHandler(void)
{
   static uint32_t time1=0;
   if (TIM_GetITStatus(TIM2, TIM_IT_Update) != RESET)
   {
		 if(++time1>200)
	  {
			//setPID();
			time1=0;
		 }
    TIM_ClearITPendingBit(TIM2, TIM_IT_Update); 
   }
}
void USART1_IRQHandler(void){
	
	// check if the USART1 receive interrupt flag was set
	if( USART_GetITStatus(USART1, USART_IT_RXNE) ){
		
		static uint8_t cnt = 0; // this counter is used to determine the string length
		char t = USART1->DR; // the character from the USART1 data register is saved in t
		
		/* check if the received character is not the LF character (used to determine end of string) 
		 * or the if the maximum string length has been been reached 
		 */
		if( (t != '\n') && (cnt < MAX_STRLEN) ){ 
			received_string[cnt] = t;
			cnt++;
		}
		else{ // otherwise reset the character counter and print the received string
			cnt = 0;
			USART_puts(USART1, received_string);
		}
	}
}

/******************************************************************************/
/*                 STM32F4xx Peripherals Interrupt Handlers                   */
/*  Add here the Interrupt Handler for the used peripheral(s) (PPP), for the  */
/*  available peripheral interrupt handler's name please refer to the startup */
/*  file (startup_stm32f4xx.s).                                               */
/******************************************************************************/

/**
  * @brief  This function handles PPP interrupt request.
  * @param  None
  * @retval None
  */
/*void PPP_IRQHandler(void)
{
}*/

/**
  * @brief  This function handles External line 0 interrupt request.
  * @param  None
  * @retval None
  */
void EXTI0_IRQHandler(void)
{
  if(EXTI_GetITStatus(EXTI_Line0) != RESET)
  {
    GPIO_ToggleBits(GPIOB,GPIO_Pin_2);
    EXTI->PR = EXTI_Line0;
  }
}
void EXTI9_5_IRQHandler(void)
{
  if(EXTI_GetITStatus(EXTI_Line5) != RESET)
  {
    //GPIO_ToggleBits(GPIOB,GPIO_Pin_3);
		ngat1++;
    EXTI->PR = EXTI_Line5;
  }
  if(EXTI_GetITStatus(EXTI_Line6) != RESET)
  {
   // GPIO_ToggleBits(GPIOB,GPIO_Pin_4);
		ngat2++;
    EXTI->PR = EXTI_Line6;
  }
}

void EXTI15_10_IRQHandler(void)
{
  if(EXTI_GetITStatus(EXTI_Line12) != RESET)
  {
    /* Toggle LED4 */
	  GPIO_ToggleBits(GPIOD, GPIO_Pin_13);
	  //Convert_Pos();

    /* Clear the EXTI line 0 pending bit */
    EXTI_ClearITPendingBit(EXTI_Line12);
  }
}
/**
  * @}
  */

/**
  * @}
  */

/******************* (C) COPYRIGHT 2011 STMicroelectronics *****END OF FILE****/
