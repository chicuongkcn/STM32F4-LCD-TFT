LCD <-> STM32F4Discovery

RS    ->  PD11
WR    ->  PD5
RD    ->  PD4
CS    ->  PD7
RESET ->  PC13

DB0   ->  PD14
DB1   ->  PD15
DB2   ->  PD0
DB3   ->  PD1
DB4   ->  PE7
DB5   ->  PE8
DB6   ->  PE9
DB7   ->  PE10
DB8   ->  PE11
DB9   ->  PE12
DB10  ->  PE13
DB11  ->  PE14
DB12  ->  PE15
DB13  ->  PD8
DB14  ->  PD9
DB15  ->  PD10

BL_CNT -> PD12

TP_IRQ -> PB12
TP_SO -> PB14
TP_SI -> PB15
TP_SCK -> PB13
TP_CS -> PC6